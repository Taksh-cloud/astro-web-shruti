'use client';

import React, { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';
import FAQCategory from './FAQCategory';
import SearchBar from './SearchBar';
import LanguageToggle from './LanguageToggle';
import QuickLinks from './QuickLinks';
import ContactCTA from './ContactCTA';
import { motion } from 'framer-motion';

interface FAQ {
  id: string;
  question: string;
  questionHi: string;
  answer: string;
  answerHi: string;
  relatedQuestions?: string[];
  category: string;
}

const FAQInteractive = () => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hi'>('en');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  useEffect(() => {
    setIsHydrated(true);
    const savedLanguage = localStorage.getItem('language') as 'en' | 'hi' | null;
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  const handleLanguageChange = (lang: 'en' | 'hi') => {
    setCurrentLanguage(lang);
    if (isHydrated) {
      localStorage.setItem('language', lang);
    }
  };

  const handleRelatedClick = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setExpandedCategory(id);
    }
  };

  const faqData: FAQ[] = [
    {
      id: 'astro-1',
      category: 'About Astrology',
      question: 'What is Vedic Astrology?',
      questionHi: 'वैदिक ज्योतिष क्या है?',
      answer: 'Vedic Astrology, also known as Jyotish, is an ancient Indian system of astrology that uses the sidereal zodiac. It provides insights into your life path, personality, relationships, career, and spiritual growth based on the positions of celestial bodies at the time of your birth. Unlike Western astrology, Vedic astrology emphasizes karma and dharma, offering guidance for living in harmony with cosmic rhythms.',
      answerHi: 'वैदिक ज्योतिष, जिसे ज्योतिष के नाम से भी जाना जाता है, एक प्राचीन भारतीय ज्योतिष प्रणाली है जो साइडरियल राशि चक्र का उपयोग करती है। यह आपके जन्म के समय खगोलीय पिंडों की स्थिति के आधार पर आपके जीवन पथ, व्यक्तित्व, संबंधों, करियर और आध्यात्मिक विकास में अंतर्दृष्टि प्रदान करता है। पश्चिमी ज्योतिष के विपरीत, वैदिक ज्योतिष कर्म और धर्म पर जोर देता है।',
      relatedQuestions: ['astro-2', 'astro-3'],
    },
    {
      id: 'astro-2',
      category: 'About Astrology',
      question: 'How accurate is Vedic Astrology?',
      questionHi: 'वैदिक ज्योतिष कितना सटीक है?',
      answer: 'Vedic Astrology\'s accuracy depends on the precision of birth details (date, time, place) and the astrologer\'s expertise. With accurate information, Vedic astrology can provide remarkably precise insights into personality traits, life patterns, and timing of events. However, it\'s important to understand that astrology shows tendencies and possibilities, not fixed destinies. Your free will and actions play a crucial role in shaping outcomes.',
      answerHi: 'वैदिक ज्योतिष की सटीकता जन्म विवरण (तिथि, समय, स्थान) की सटीकता और ज्योतिषी की विशेषज्ञता पर निर्भर करती है। सटीक जानकारी के साथ, वैदिक ज्योतिष व्यक्तित्व लक्षणों, जीवन पैटर्न और घटनाओं के समय में उल्लेखनीय रूप से सटीक अंतर्दृष्टि प्रदान कर सकता है। हालांकि, यह समझना महत्वपूर्ण है कि ज्योतिष प्रवृत्तियों और संभावनाओं को दिखाता है, निश्चित भाग्य को नहीं।',
      relatedQuestions: ['astro-1', 'consult-2'],
    },
    {
      id: 'astro-3',
      category: 'About Astrology',
      question: 'What can astrology help me with?',
      questionHi: 'ज्योतिष मेरी किस चीज़ में मदद कर सकता है?',
      answer: 'Astrology can provide guidance in multiple life areas: career decisions and timing, relationship compatibility and challenges, health tendencies and preventive measures, financial planning and investment timing, spiritual growth and life purpose, understanding personality strengths and weaknesses, timing major life decisions, and navigating challenging periods with awareness. It serves as a tool for self-understanding and conscious decision-making.',
      answerHi: 'ज्योतिष कई जीवन क्षेत्रों में मार्गदर्शन प्रदान कर सकता है: करियर निर्णय और समय, संबंध संगतता और चुनौतियां, स्वास्थ्य प्रवृत्तियां और निवारक उपाय, वित्तीय योजना और निवेश समय, आध्यात्मिक विकास और जीवन उद्देश्य, व्यक्तित्व शक्तियों और कमजोरियों को समझना, प्रमुख जीवन निर्णयों का समय, और जागरूकता के साथ चुनौतीपूर्ण अवधियों को नेविगेट करना।',
      relatedQuestions: ['consult-1', 'consult-3'],
    },
    {
      id: 'consult-1',
      category: 'About Consultations',
      question: 'What information do I need for a consultation?',
      questionHi: 'परामर्श के लिए मुझे किस जानकारी की आवश्यकता है?',
      answer: 'For an accurate consultation, please provide: exact date of birth (DD/MM/YYYY), precise time of birth (as mentioned on birth certificate), place of birth (city and country), and specific questions or areas of concern you want to discuss. If birth time is unknown, we can still provide insights, though some predictions may be limited. The more accurate your birth details, the more precise the reading.',
      answerHi: 'सटीक परामर्श के लिए, कृपया प्रदान करें: जन्म की सटीक तिथि (DD/MM/YYYY), जन्म का सटीक समय (जन्म प्रमाण पत्र पर उल्लिखित), जन्म स्थान (शहर और देश), और विशिष्ट प्रश्न या चिंता के क्षेत्र जिन पर आप चर्चा करना चाहते हैं। यदि जन्म समय अज्ञात है, तो भी हम अंतर्दृष्टि प्रदान कर सकते हैं, हालांकि कुछ भविष्यवाणियां सीमित हो सकती हैं।',
      relatedQuestions: ['consult-2', 'consult-4'],
    },
    {
      id: 'consult-2',
      category: 'About Consultations',
      question: 'How long does a consultation take?',
      questionHi: 'परामर्श में कितना समय लगता है?',
      answer: 'Consultation usually takes up to one hour but it can be extended by a while(10 to 15 min) if there are any more very important questions from the client side.',
      answerHi: 'परामर्श में आमतौर पर एक घंटे तक का समय लगता है, लेकिन यदि ग्राहक की ओर से कोई और महत्वपूर्ण प्रश्न हों तो इसे कुछ समय (10 से 15 मिनट) तक बढ़ाया जा सकता है।',
      relatedQuestions: ['consult-1', 'pricing-1'],
    },
    {
      id: 'consult-3',
      category: 'About Consultations',
      question: 'Can consultations be done online?',
      questionHi: 'क्या परामर्श ऑनलाइन किया जा सकता है?',
      answer: 'Yes, all consultations are conducted online via WhatsApp video call or voice call, based on your preference. Online consultations are equally effective as in-person sessions since astrology readings depend on birth chart analysis, not physical presence. This format offers convenience, flexibility in scheduling, and the comfort of consulting from your own space. We ensure a professional and confidential consultation experience.',
      answerHi: 'हां, सभी परामर्श WhatsApp वीडियो कॉल या वॉयस कॉल के माध्यम से ऑनलाइन आयोजित किए जाते हैं, आपकी प्राथमिकता के आधार पर। ऑनलाइन परामर्श व्यक्तिगत सत्रों के समान प्रभावी हैं क्योंकि ज्योतिष रीडिंग जन्म चार्ट विश्लेषण पर निर्भर करती है, भौतिक उपस्थिति पर नहीं। यह प्रारूप सुविधा, शेड्यूलिंग में लचीलापन और अपने स्थान से परामर्श की सुविधा प्रदान करता है।',
      relatedQuestions: ['consult-4', 'tech-1'],
    },
    {
      id: 'consult-4',
      category: 'About Consultations',
      question: 'What language are consultations conducted in?',
      questionHi: 'परामर्श किस भाषा में आयोजित किए जाते हैं?',
      answer: 'Consultations are available in both Hindi and English. You can choose your preferred language when booking. Shruti is fluent in both languages and can seamlessly switch between them if needed during the session. Technical astrological terms are explained in simple language to ensure clear understanding, regardless of which language you choose.',
      answerHi: 'परामर्श हिंदी और अंग्रेजी दोनों में उपलब्ध हैं। आप बुकिंग करते समय अपनी पसंदीदा भाषा चुन सकते हैं। श्रुति दोनों भाषाओं में धाराप्रवाह हैं और यदि सत्र के दौरान आवश्यक हो तो उनके बीच सहजता से स्विच कर सकती हैं। तकनीकी ज्योतिषीय शब्दों को सरल भाषा में समझाया जाता है।',
      relatedQuestions: ['consult-1', 'consult-2'],
    },
    {
      id: 'pricing-1',
      category: 'Pricing & Booking',
      question: 'What are the consultation fees?',
      questionHi: 'परामर्श शुल्क क्या है?',
      answer: 'Consultation fees are quite simple which is ₹999 for any 2 niches of your choice and you can pick from a wide variety Life Events & Guidance, Health & Well-being, Career & Finances, Relationships & Compatibility, Personality & Self-Understanding. Package deals and follow-up consultations are available at discounted rates. All fees are transparent with no hidden charges. Payment details are shared after booking confirmation.',
      answerHi: 'परामर्श शुल्क बेहद सरल है, जिसमें आपकी पसंद के किन्हीं भी 2 विषयों के लिए ₹999 का शुल्क लगता है। आप जीवन की महत्वपूर्ण घटनाओं और मार्गदर्शन, स्वास्थ्य और कल्याण, करियर और वित्त, रिश्ते और अनुकूलता, व्यक्तित्व और आत्म-समझ जैसे विभिन्न विषयों में से चुन सकते हैं। पैकेज डील और अनुवर्ती परामर्श रियायती दरों पर उपलब्ध हैं। सभी शुल्क पारदर्शी हैं और कोई छिपे हुए शुल्क नहीं हैं। बुकिंग की पुष्टि के बाद भुगतान विवरण साझा किए जाते हैं।',
      relatedQuestions: ['pricing-2', 'pricing-3'],
    },
    {
      id: 'pricing-2',
      category: 'Pricing & Booking',
      question: 'How do I book a consultation?',
      questionHi: 'मैं परामर्श कैसे बुक करूं?',
      answer: 'Booking is simple via WhatsApp: Click the "Book Now" button on any page, send a message to +91 90799 64007, share your preferred service and available dates/times, provide your birth details, and receive confirmation with payment instructions. We typically respond within 2-4 hours during business hours. You can also visit our Contact page for alternative booking methods.',
      answerHi: 'WhatsApp के माध्यम से बुकिंग सरल है: किसी भी पृष्ठ पर "अभी बुक करें" बटन पर क्लिक करें, +91 90799 64007 पर संदेश भेजें, अपनी पसंदीदा सेवा और उपलब्ध तिथियां/समय साझा करें, अपना जन्म विवरण प्रदान करें, और भुगतान निर्देशों के साथ पुष्टि प्राप्त करें। हम आमतौर पर व्यावसायिक घंटों के दौरान 2-4 घंटे के भीतर जवाब देते हैं।',
      relatedQuestions: ['pricing-1', 'pricing-3'],
    },
    {
      id: 'pricing-3',
      category: 'Pricing & Booking',
      question: 'What is your cancellation policy?',
      questionHi: 'आपकी रद्दीकरण नीति क्या है?',
      answer: 'Cancellations made 24 hours before scheduled time receive full refund. Cancellations within 24 hours receive 50% refund. No-shows without prior notice are non-refundable. Rescheduling is free if done 12 hours in advance. We understand emergencies happen and handle each situation with compassion. Please contact us as soon as possible if you need to cancel or reschedule.',
      answerHi: 'निर्धारित समय से 24 घंटे पहले किए गए रद्दीकरण को पूर्ण धनवापसी मिलती है। 24 घंटे के भीतर रद्दीकरण को 50% धनवापसी मिलती है। बिना पूर्व सूचना के नो-शो गैर-वापसी योग्य हैं। यदि 12 घंटे पहले किया जाए तो पुनर्निर्धारण मुफ्त है। हम समझते हैं कि आपात स्थितियां होती हैं और प्रत्येक स्थिति को करुणा के साथ संभालते हैं।',
      relatedQuestions: ['pricing-2', 'consult-2'],
    },
    {
      id: 'privacy-1',
      category: 'Privacy & Confidentiality',
      question: 'Is my personal information kept confidential?',
      questionHi: 'क्या मेरी व्यक्तिगत जानकारी गोपनीय रखी जाती है?',
      answer: 'Absolutely. Your privacy is our top priority. All birth details, consultation discussions, and personal information are kept strictly confidential. We do not share, sell, or disclose your information to any third parties. Birth charts and consultation notes are stored securely and accessed only by Shruti for your readings. We follow strict data protection practices to ensure your information remains private.',
      answerHi: 'बिल्कुल। आपकी गोपनीयता हमारी सर्वोच्च प्राथमिकता है। सभी जन्म विवरण, परामर्श चर्चा और व्यक्तिगत जानकारी सख्ती से गोपनीय रखी जाती है। हम आपकी जानकारी को किसी तीसरे पक्ष के साथ साझा, बेचते या प्रकट नहीं करते हैं। जन्म चार्ट और परामर्श नोट्स सुरक्षित रूप से संग्रहीत किए जाते हैं और केवल श्रुति द्वारा आपकी रीडिंग के लिए एक्सेस किए जाते हैं।',
      relatedQuestions: ['privacy-2', 'tech-2'],
    },
    {
      id: 'privacy-2',
      category: 'Privacy & Confidentiality',
      question: 'Do you record consultation sessions?',
      questionHi: 'क्या आप परामर्श सत्र रिकॉर्ड करते हैं?',
      answer: 'We do not record consultation sessions unless you specifically request it for your personal reference. If you wish to record the session, please inform us at the beginning of the consultation. You are welcome to take notes during the session or request a written summary of key points discussed. Your comfort and privacy are paramount throughout the consultation process.',
      answerHi: 'हम परामर्श सत्रों को रिकॉर्ड नहीं करते हैं जब तक कि आप विशेष रूप से अपने व्यक्तिगत संदर्भ के लिए इसका अनुरोध न करें। यदि आप सत्र को रिकॉर्ड करना चाहते हैं, तो कृपया परामर्श की शुरुआत में हमें सूचित करें। आप सत्र के दौरान नोट्स लेने या चर्चा किए गए मुख्य बिंदुओं के लिखित सारांश का अनुरोध करने के लिए स्वागत है।',
      relatedQuestions: ['privacy-1', 'consult-3'],
    },
    {
      id: 'tech-1',
      category: 'Technical Support',
      question: 'What if I face technical issues during the consultation?',
      questionHi: 'यदि परामर्श के दौरान मुझे तकनीकी समस्याओं का सामना करना पड़े तो क्या होगा?',
      answer: 'If you experience technical difficulties during the consultation, immediately contact us via WhatsApp message or call. We will quickly switch to an alternative method (voice call if video fails, or reschedule if connection is poor). No charges apply for time lost due to technical issues. We recommend testing your internet connection and WhatsApp before the scheduled time. A stable internet connection and updated WhatsApp version ensure smooth consultations.',
      answerHi: 'यदि आप परामर्श के दौरान तकनीकी कठिनाइयों का अनुभव करते हैं, तो तुरंत WhatsApp संदेश या कॉल के माध्यम से हमसे संपर्क करें। हम जल्दी से एक वैकल्पिक विधि पर स्विच करेंगे (यदि वीडियो विफल हो जाता है तो वॉयस कॉल, या यदि कनेक्शन खराब है तो पुनर्निर्धारण)। तकनीकी समस्याओं के कारण खोए गए समय के लिए कोई शुल्क लागू नहीं होता है।',
      relatedQuestions: ['tech-2', 'consult-3'],
    },
    {
      id: 'tech-2',
      category: 'Technical Support',
      question: 'What are the technical requirements for online consultation?',
      questionHi: 'ऑनलाइन परामर्श के लिए तकनीकी आवश्यकताएं क्या हैं?',
      answer: 'You need: a smartphone or computer with WhatsApp installed, stable internet connection (minimum 2 Mbps for video calls), working camera and microphone (for video consultations), and a quiet, private space for the consultation. We recommend using headphones for better audio quality. Ensure your device is fully charged or connected to power. Test your WhatsApp video/voice call feature before the scheduled time.',
      answerHi: 'आपको चाहिए: WhatsApp इंस्टॉल किया हुआ स्मार्टफोन या कंप्यूटर, स्थिर इंटरनेट कनेक्शन (वीडियो कॉल के लिए न्यूनतम 2 Mbps), काम करने वाला कैमरा और माइक्रोफोन (वीडियो परामर्श के लिए), और परामर्श के लिए एक शांत, निजी स्थान। हम बेहतर ऑडियो गुणवत्ता के लिए हेडफ़ोन का उपयोग करने की सलाह देते हैं।',
      relatedQuestions: ['tech-1', 'consult-3'],
    },
  ];

  const categories = [
    { id: 'about-astrology', title: 'About Astrology', titleHi: 'ज्योतिष के बारे में' },
    { id: 'about-consultations', title: 'About Consultations', titleHi: 'परामर्श के बारे में' },
    { id: 'pricing-booking', title: 'Pricing & Booking', titleHi: 'मूल्य निर्धारण और बुकिंग' },
    { id: 'privacy-confidentiality', title: 'Privacy & Confidentiality', titleHi: 'गोपनीयता और गोपनीयता' },
    { id: 'technical-support', title: 'Technical Support', titleHi: 'तकनीकी सहायता' },
  ];

  const filteredFAQs = searchQuery
    ? faqData.filter(
        (faq) =>
          faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          faq.questionHi.includes(searchQuery) ||
          faq.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
          faq.answerHi.includes(searchQuery)
      )
    : faqData;

  const groupedFAQs = categories.map((category) => ({
    ...category,
    faqs: filteredFAQs.filter((faq) => faq.category === category.title),
  }));

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-12">
          <div className="animate-pulse space-y-8">
            <div className="h-12 bg-muted rounded-lg w-1/3 mx-auto" />
            <div className="h-64 bg-muted rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12 lg:py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="font-headline text-4xl lg:text-5xl font-bold text-primary mb-4">
              {currentLanguage === 'en' ?'Frequently Asked Questions' :'अक्सर पूछे जाने वाले प्रश्न'}
            </h1>
            <p className="font-body text-lg text-text-secondary max-w-2xl mx-auto">
              {currentLanguage === 'en' ?'Find answers to common questions about Vedic astrology, consultations, and our services.' :'वैदिक ज्योतिष, परामर्श और हमारी सेवाओं के बारे में सामान्य प्रश्नों के उत्तर खोजें।'}
            </p>
          </div>

          <div className="mb-8 flex justify-center">
            <LanguageToggle
              currentLanguage={currentLanguage}
              onLanguageChange={handleLanguageChange}
            />
          </div>

          <SearchBar
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            currentLanguage={currentLanguage}
          />

          {searchQuery && filteredFAQs.length === 0 && (
            <div className="text-center py-12">
              <p className="font-body text-text-secondary text-lg">
                {currentLanguage === 'en' ?'No questions found matching your search.' :'आपकी खोज से मेल खाने वाले कोई प्रश्न नहीं मिले।'}
              </p>
            </div>
          )}

          <div className="space-y-8">
            {groupedFAQs.map(
              (category) =>
                category.faqs.length > 0 && (
                  <div key={category.id} id={category.id}>
                    <FAQCategory
                      title={category.title}
                      titleHi={category.titleHi}
                      faqs={category.faqs}
                      currentLanguage={currentLanguage}
                      onRelatedClick={handleRelatedClick}
                    />
                  </div>
                )
            )}
          </div>

          <QuickLinks currentLanguage={currentLanguage} />

          <ContactCTA currentLanguage={currentLanguage} />
        </div>
      </div>

      {/* Floating WhatsApp Button */}
      <motion.a
        href="https://wa.me/919079964007"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 w-14 h-14 bg-whatsapp text-whatsapp-foreground rounded-full shadow-elevated hover:shadow-elevated-hover flex items-center justify-center transition-all duration-300 hover:scale-110 z-50"
        aria-label="Chat on WhatsApp"
        whileHover={{ scale: 1.15, rotate: 5 }}
        whileTap={{ scale: 0.9 }}
        animate={{ 
          scale: [1, 1.1, 1],
        }}
        transition={{ 
          scale: { repeat: Infinity, duration: 2, ease: "easeInOut" },
          hover: { type: "spring", stiffness: 400, damping: 17 }
        }}
      >
        <Icon name="ChatBubbleLeftRightIcon" size={28} />
      </motion.a>
    </div>
  );
};

export default FAQInteractive;
