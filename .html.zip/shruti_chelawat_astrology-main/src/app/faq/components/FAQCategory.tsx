'use client';

import React, { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface FAQ {
  id: string;
  question: string;
  questionHi: string;
  answer: string;
  answerHi: string;
  relatedQuestions?: string[];
}

interface FAQCategoryProps {
  title: string;
  titleHi: string;
  faqs: FAQ[];
  currentLanguage: 'en' | 'hi';
  onRelatedClick: (id: string) => void;
}

const FAQCategory = ({ title, titleHi, faqs, currentLanguage, onRelatedClick }: FAQCategoryProps) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleFAQ = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="mb-8">
      <h2 className="font-headline text-2xl lg:text-3xl font-semibold text-primary mb-6">
        {currentLanguage === 'en' ? title : titleHi}
      </h2>
      <div className="space-y-4">
        {faqs.map((faq) => (
          <div
            key={faq.id}
            className="bg-card rounded-lg shadow-soft overflow-hidden transition-all duration-300 hover:shadow-elevated"
          >
            <button
              onClick={() => toggleFAQ(faq.id)}
              className="w-full px-6 py-4 flex items-center justify-between text-left transition-colors duration-300 hover:bg-muted"
              aria-expanded={expandedId === faq.id}
            >
              <span className="font-body font-medium text-text-primary pr-4">
                {currentLanguage === 'en' ? faq.question : faq.questionHi}
              </span>
              <Icon
                name="ChevronDownIcon"
                size={20}
                className={`text-primary flex-shrink-0 transition-transform duration-300 ${
                  expandedId === faq.id ? 'rotate-180' : ''
                }`}
              />
            </button>
            <div
              className={`overflow-hidden transition-all duration-300 ${
                expandedId === faq.id ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
              }`}
            >
              <div className="px-6 pb-6 pt-2">
                <p className="font-body text-text-secondary leading-relaxed mb-4">
                  {currentLanguage === 'en' ? faq.answer : faq.answerHi}
                </p>
                {faq.relatedQuestions && faq.relatedQuestions.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="font-body text-sm font-medium text-text-primary mb-2">
                      {currentLanguage === 'en' ? 'Related Questions:' : 'संबंधित प्रश्न:'}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {faq.relatedQuestions.map((relatedId) => (
                        <button
                          key={relatedId}
                          onClick={() => onRelatedClick(relatedId)}
                          className="text-sm font-body text-primary hover:text-secondary transition-colors duration-300 underline"
                        >
                          {currentLanguage === 'en' ? 'View related' : 'देखें'}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQCategory;