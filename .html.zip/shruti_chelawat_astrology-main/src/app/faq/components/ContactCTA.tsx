'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import { motion } from 'framer-motion';

interface ContactCTAProps {
  currentLanguage: 'en' | 'hi';
}

const ContactCTA = ({ currentLanguage }: ContactCTAProps) => {
  return (
    <div className="mt-16 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl p-8 lg:p-12 text-center">
      <Icon
        name="QuestionMarkCircleIcon"
        size={48}
        className="text-primary mx-auto mb-4"
      />
      <h3 className="font-headline text-2xl lg:text-3xl font-semibold text-primary mb-4">
        {currentLanguage === 'en' ?'Still Have Questions?' :'अभी भी प्रश्न हैं?'}
      </h3>
      <p className="font-body text-text-secondary mb-6 max-w-2xl mx-auto">
        {currentLanguage === 'en' ? "Can't find the answer you're looking for? Feel free to reach out directly for personalized assistance."
          : 'आपको जो उत्तर चाहिए वह नहीं मिल रहा? व्यक्तिगत सहायता के लिए सीधे संपर्क करें।'}
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
        <motion.a
          href="https://wa.me/919079964007"
          target="_blank"
          rel="noopener noreferrer"
          className="px-8 py-3 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 flex items-center space-x-2 shadow-soft hover:shadow-elevated"
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          transition={{ type: "spring", stiffness: 400, damping: 17 }}
        >
          <Icon name="ChatBubbleLeftRightIcon" size={20} />
          <span>
            {currentLanguage === 'en' ? 'Chat on WhatsApp' : 'WhatsApp पर चैट करें'}
          </span>
        </motion.a>
        <a
          href="/contact"
          className="px-8 py-3 bg-card text-primary border-2 border-primary font-cta font-semibold rounded-lg hover:bg-primary hover:text-primary-foreground transition-all duration-300 shadow-soft hover:shadow-elevated"
        >
          {currentLanguage === 'en' ? 'Contact Page' : 'संपर्क पृष्ठ'}
        </a>
      </div>
    </div>
  );
};

export default ContactCTA;