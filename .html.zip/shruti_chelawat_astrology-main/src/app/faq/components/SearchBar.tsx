'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  currentLanguage: 'en' | 'hi';
}

const SearchBar = ({ searchQuery, onSearchChange, currentLanguage }: SearchBarProps) => {
  return (
    <div className="relative max-w-2xl mx-auto mb-12">
      <div className="relative">
        <Icon
          name="MagnifyingGlassIcon"
          size={20}
          className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary"
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={
            currentLanguage === 'en' ?'Search your question...' :'अपना प्रश्न खोजें...'
          }
          className="w-full pl-12 pr-4 py-4 bg-card border-2 border-border rounded-lg font-body text-text-primary placeholder:text-text-secondary focus:outline-none focus:border-primary transition-colors duration-300"
        />
      </div>
      {searchQuery && (
        <button
          onClick={() => onSearchChange('')}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-text-secondary hover:text-primary transition-colors duration-300"
          aria-label="Clear search"
        >
          <Icon name="XMarkIcon" size={20} />
        </button>
      )}
    </div>
  );
};

export default SearchBar;