'use client';

import React from 'react';

interface LanguageToggleProps {
  currentLanguage: 'en' | 'hi';
  onLanguageChange: (lang: 'en' | 'hi') => void;
}

const LanguageToggle = ({ currentLanguage, onLanguageChange }: LanguageToggleProps) => {
  return (
    <div className="flex items-center justify-center space-x-2 bg-muted rounded-lg p-1">
      <button
        onClick={() => onLanguageChange('en')}
        className={`px-6 py-2 rounded-md font-body font-medium transition-all duration-300 ${
          currentLanguage === 'en' ?'bg-primary text-primary-foreground shadow-soft' :'text-text-secondary hover:text-text-primary'
        }`}
      >
        English
      </button>
      <button
        onClick={() => onLanguageChange('hi')}
        className={`px-6 py-2 rounded-md font-body font-medium transition-all duration-300 ${
          currentLanguage === 'hi' ?'bg-primary text-primary-foreground shadow-soft' :'text-text-secondary hover:text-text-primary'
        }`}
      >
        हिंदी
      </button>
    </div>
  );
};

export default LanguageToggle;