'use client';

import React from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

interface QuickLink {
  title: string;
  titleHi: string;
  href: string;
  icon: string;
}

interface QuickLinksProps {
  currentLanguage: 'en' | 'hi';
}

const QuickLinks = ({ currentLanguage }: QuickLinksProps) => {
  const links: QuickLink[] = [
    {
      title: 'View Services',
      titleHi: 'सेवाएं देखें',
      href: '/services',
      icon: 'SparklesIcon',
    },
    {
      title: 'Our Approach',
      titleHi: 'हमारा दृष्टिकोण',
      href: '/astrology-approach',
      icon: 'BookOpenIcon',
    },
    {
      title: 'About Shruti',
      titleHi: 'श्रुति के बारे में',
      href: '/about',
      icon: 'UserIcon',
    },
    {
      title: 'Book Consultation',
      titleHi: 'परामर्श बुक करें',
      href: '/contact',
      icon: 'CalendarIcon',
    },
  ];

  return (
    <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {links.map((link) => (
        <Link
          key={link.href}
          href={link.href}
          className="flex items-center space-x-3 p-4 bg-card rounded-lg border-2 border-border hover:border-primary hover:shadow-soft transition-all duration-300 group"
        >
          <Icon
            name={link.icon as any}
            size={24}
            className="text-primary group-hover:scale-110 transition-transform duration-300"
          />
          <span className="font-body font-medium text-text-primary group-hover:text-primary transition-colors duration-300">
            {currentLanguage === 'en' ? link.title : link.titleHi}
          </span>
        </Link>
      ))}
    </div>
  );
};

export default QuickLinks;