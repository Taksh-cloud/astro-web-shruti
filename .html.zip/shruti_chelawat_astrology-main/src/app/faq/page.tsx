import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import FAQInteractive from './components/FAQInteractive';

export const metadata: Metadata = {
  title: 'FAQ - Shruti Chelawat Astrology',
  description: 'Find answers to frequently asked questions about Vedic astrology consultations, pricing, booking process, privacy policies, and technical requirements for online sessions with Shruti Chelawat.',
};

export default function FAQPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <div className="pt-16 lg:pt-20">
        <FAQInteractive />
      </div>
    </main>
  );
}