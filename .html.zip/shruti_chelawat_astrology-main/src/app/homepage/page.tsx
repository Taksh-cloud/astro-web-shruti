import type { Metadata } from 'next';
import HomepageInteractive from './components/HomepageInteractive';

export const metadata: Metadata = {
  title: 'Home - Shruti Chelawat Astrology',
  description: 'Discover clarity through authentic Vedic astrology guidance. Experience personalized consultations that blend ancient wisdom with contemporary understanding for life\'s important decisions.',
};

export default function Homepage() {
  return <HomepageInteractive />;
}