'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import Link from 'next/link';
import { motion } from 'framer-motion';

interface ApproachPoint {
  id: number;
  icon: string;
  title: string;
  description: string;
}

interface ApproachHighlightProps {
  currentLanguage: 'en' | 'hi';
}

const ApproachHighlight = ({ currentLanguage }: ApproachHighlightProps) => {
  const content = {
    en: {
      sectionTitle: "My Approach to Astrology",
      sectionSubtitle: "Clarity without fear, truth with compassion",
      learnMore: "Learn More About My Approach",
      nakshatraSubtext: "Rooted in the ancient science of 27 Nakshatras",
      approaches: [
        {
          id: 1,
          icon: "ShieldCheckIcon",
          title: "Honest & Transparent",
          description: "No sugar-coating or fear-mongering. I provide realistic insights that empower you to make informed decisions."
        },
        {
          id: 2,
          icon: "BookOpenIcon",
          title: "Traditional Vedic Wisdom",
          description: "Rooted in authentic Vedic astrology principles passed down through generations of practitioners."
        },
        {
          id: 3,
          icon: "LightBulbIcon",
          title: "Practical Guidance",
          description: "Astrological insights translated into actionable advice for modern life challenges and opportunities."
        },
        {
          id: 4,
          icon: "LockClosedIcon",
          title: "Complete Confidentiality",
          description: "Your personal information and consultation details remain strictly private and secure."
        }
      ]
    },
    hi: {
      sectionTitle: "ज्योतिष के प्रति मेरा दृष्टिकोण",
      sectionSubtitle: "भय के बिना स्पष्टता, करुणा के साथ सत्य",
      learnMore: "मेरे दृष्टिकोण के बारे में और जानें",
      approaches: [
        {
          id: 1,
          icon: "ShieldCheckIcon",
          title: "ईमानदार और पारदर्शी",
          description: "कोई मीठी बातें या डराना नहीं। मैं यथार्थवादी अंतर्दृष्टि प्रदान करती हूं जो आपको सूचित निर्णय लेने के लिए सशक्त बनाती है।"
        },
        {
          id: 2,
          icon: "BookOpenIcon",
          title: "पारंपरिक वैदिक ज्ञान",
          description: "पीढ़ियों से चले आ रहे प्रामाणिक वैदिक ज्योतिष सिद्धांतों में निहित।"
        },
        {
          id: 3,
          icon: "LightBulbIcon",
          title: "व्यावहारिक मार्गदर्शन",
          description: "आधुनिक जीवन की चुनौतियों और अवसरों के लिए कार्रवाई योग्य सलाह में अनुवादित ज्योतिषीय अंतर्दृष्टि।"
        },
        {
          id: 4,
          icon: "LockClosedIcon",
          title: "पूर्ण गोपनीयता",
          description: "आपकी व्यक्तिगत जानकारी और परामर्श विवरण पूरी तरह से निजी और सुरक्षित रहते हैं।"
        }
      ]
    }
  };

  const text = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-muted">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-text-primary mb-4">
            {text.sectionTitle}
          </h2>
          <p className="font-headline text-lg lg:text-xl text-text-secondary max-w-2xl mx-auto">
            {text.sectionSubtitle}
          </p>
          <p className="font-body text-sm text-accent italic mt-2">
            {text.nakshatraSubtext}
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mb-12">
          {text.approaches.map((approach) => (
            <div
              key={approach.id}
              className="bg-card rounded-lg p-6 text-center shadow-soft hover:shadow-elevated transition-all duration-300"
            >
              <div className="w-16 h-16 bg-accent bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name={approach.icon as any} size={32} className="text-accent" variant="solid" />
              </div>

              <h3 className="font-headline text-xl font-semibold text-text-primary mb-3">
                {approach.title}
              </h3>

              <p className="font-body text-text-secondary leading-relaxed">
                {approach.description}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link
            href="/astrology-approach"
            className="inline-flex items-center space-x-2 px-8 py-3 bg-secondary text-secondary-foreground font-cta font-semibold rounded-lg hover:bg-primary transition-all duration-300 shadow-soft hover:shadow-elevated"
          >
            <motion.span
              className="inline-flex items-center space-x-2"
              whileHover={{ scale: 1.05, x: 5 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >
              <span>{text.learnMore}</span>
              <Icon name="ArrowRightIcon" size={20} />
            </motion.span>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ApproachHighlight;