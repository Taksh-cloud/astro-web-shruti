'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

interface FooterProps {
  currentLanguage: 'en' | 'hi';
}

const Footer = ({ currentLanguage }: FooterProps) => {
  const [currentYear, setCurrentYear] = useState<number | null>(null);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
    setCurrentYear(new Date().getFullYear());
  }, []);

  const content = {
    en: {
      quickLinks: "Quick Links",
      services: "Services",
      contact: "Contact",
      copyright: "All rights reserved.",
      tagline: "Traditional Wisdom, Modern Delivery",
      nakshatraFooter: "Nakshatra-based Vedic Astrology",
      links: {
        home: "Home",
        about: "About",
        services: "Services",
        approach: "Approach",
        faq: "FAQ",
        contact: "Contact"
      },
      contactInfo: {
        phone: "+91 90799 64007",
        email: "shruti@astrology.com",
        whatsapp: "WhatsApp Consultation"
      }
    },
    hi: {
      quickLinks: "त्वरित लिंक",
      services: "सेवाएं",
      contact: "संपर्क",
      copyright: "सर्वाधिकार सुरक्षित।",
      tagline: "पारंपरिक ज्ञान, आधुनिक सेवा",
      nakshatraFooter: "नक्षत्र आधारित वैदिक ज्योतिष",
      links: {
        home: "होम",
        about: "परिचय",
        services: "सेवाएं",
        approach: "दृष्टिकोण",
        faq: "सामान्य प्रश्न",
        contact: "संपर्क"
      },
      contactInfo: {
        phone: "+91 90799 64007",
        email: "shruti@astrology.com",
        whatsapp: "व्हाट्सएप परामर्श"
      }
    }
  };

  const text = content[currentLanguage];

  const handleWhatsApp = () => {
    if (!isHydrated) return;

    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const whatsappUrl = isMobile ?
    'https://wa.me/919079964007' :
    'https://web.whatsapp.com/send?phone=919079964007';

    window.open(whatsappUrl, '_blank');
  };

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-12 lg:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12 mb-12">
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="relative w-10 h-10">
                <svg
                  viewBox="0 0 48 48"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-full h-full">

                  <circle cx="24" cy="24" r="22" fill="var(--color-accent)" opacity="0.2" />
                  <path
                    d="M24 8C15.163 8 8 15.163 8 24s7.163 16 16 16 16-7.163 16-16S32.837 8 24 8zm0 28c-6.627 0-12-5.373-12-12S17.373 12 24 12s12 5.373 12 12-5.373 12-12 12z"
                    fill="var(--color-accent)" />

                  <circle cx="24" cy="24" r="4" fill="var(--color-primary-foreground)" />
                  <path
                    d="M24 16v-4M24 36v-4M32 24h4M12 24h-4M30.828 17.172l2.829-2.829M14.343 32.657l2.829-2.829M30.828 30.828l2.829 2.829M14.343 15.343l2.829 2.829"
                    stroke="var(--color-accent)"
                    strokeWidth="2"
                    strokeLinecap="round" />

                </svg>
              </div>
              <div>
                <h3 className="font-headline text-xl font-semibold">Shruti Chelawat</h3>
                <p className="font-body text-sm opacity-80">{text.tagline}</p>
                <p className="font-body text-xs text-accent italic mt-1">{text.nakshatraFooter}</p>
              </div>
            </div>
            <p className="font-body text-sm opacity-80 leading-relaxed">
              {currentLanguage === 'en' ? 'Authentic Vedic astrology consultations combining traditional wisdom with modern understanding.' : 'पारंपरिक ज्ञान को आधुनिक समझ के साथ जोड़ने वाले प्रामाणिक वैदिक ज्योतिष परामर्श।'}
            </p>
          </div>

          <div>
            <h4 className="font-headline text-lg font-semibold mb-4">{text.quickLinks}</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/homepage" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                  {text.links.home}
                </Link>
              </li>
              <li>
                <Link href="/about" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                  {text.links.about}
                </Link>
              </li>
              <li>
                <Link href="/services" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                  {text.links.services}
                </Link>
              </li>
              <li>
                <Link href="/astrology-approach" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                  {text.links.approach}
                </Link>
              </li>
              <li>
                <Link href="/faq" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                  {text.links.faq}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-headline text-lg font-semibold mb-4">{text.contact}</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <Icon name="PhoneIcon" size={18} className="mt-0.5 flex-shrink-0" />
                <a href="tel:+919079964007" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                  {text.contactInfo.phone}
                </a>
              </li>
              <li className="flex items-start space-x-2">
                <Icon name="EnvelopeIcon" size={18} className="mt-0.5 flex-shrink-0" />
                <a href="mailto:shruti@astrology.com" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                  {text.contactInfo.email}
                </a>
              </li>
              <li>
                <button
                  onClick={handleWhatsApp}
                  disabled={!isHydrated}
                  className="flex items-center space-x-2 px-4 py-2 bg-whatsapp text-whatsapp-foreground font-body text-sm font-medium rounded-lg hover:bg-opacity-90 transition-all duration-300 disabled:opacity-50">

                  <Icon name="ChatBubbleLeftRightIcon" size={18} />
                  <span>{text.contactInfo.whatsapp}</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground border-opacity-20 pt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
            <p className="font-body text-sm opacity-80 text-center sm:text-left">
              © {isHydrated && currentYear ? currentYear : '2026'} Shruti Chelawat Astrology. {text.copyright}
            </p>
            <div className="flex items-center space-x-6">
              <Link href="/faq" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                {currentLanguage === 'en' ? 'Privacy Policy' : 'गोपनीयता नीति'}
              </Link>
              <Link href="/faq" className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300">
                {currentLanguage === 'en' ? 'Terms of Service' : 'सेवा की शर्तें'}
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>);

};

export default Footer;