'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import Link from 'next/link';
import { motion } from 'framer-motion';

interface Service {
  id: number;
  icon: string;
  title: string;
  description: string;
  features: string[];
}

interface ServicesOverviewProps {
  currentLanguage: 'en' | 'hi';
}

const ServicesOverview = ({ currentLanguage }: ServicesOverviewProps) => {
  const content = {
    en: {
      sectionTitle: "Astrological Services",
      sectionSubtitle: "Comprehensive guidance for every aspect of your life",
      viewAll: "View All Services",
      services: [
        {
          id: 1,
          icon: "UserGroupIcon",
          title: "Birth Chart Analysis",
          description: "Deep dive into your natal chart to understand your life path, strengths, and challenges",
          features: ["Planetary positions", "House analysis", "Dasha predictions"]
        },
        {
          id: 2,
          icon: "HeartIcon",
          title: "Relationship Compatibility",
          description: "Understand relationship dynamics through Vedic compatibility analysis",
          features: ["Kundali matching", "Compatibility score", "Remedial solutions"]
        },
        {
          id: 3,
          icon: "BriefcaseIcon",
          title: "Career Guidance",
          description: "Navigate your professional journey with astrological insights",
          features: ["Career timing", "Business prospects", "Job changes"]
        },
        {
          id: 4,
          icon: "CalendarDaysIcon",
          title: "Muhurat Selection",
          description: "Choose auspicious timings for important life events",
          features: ["Wedding dates", "Business launch", "Property purchase"]
        }
      ]
    },
    hi: {
      sectionTitle: "ज्योतिषीय सेवाएं",
      sectionSubtitle: "आपके जीवन के हर पहलू के लिए व्यापक मार्गदर्शन",
      viewAll: "सभी सेवाएं देखें",
      services: [
        {
          id: 1,
          icon: "UserGroupIcon",
          title: "जन्म कुंडली विश्लेषण",
          description: "अपने जीवन पथ, शक्तियों और चुनौतियों को समझने के लिए जन्म कुंडली का गहन अध्ययन",
          features: ["ग्रह स्थिति", "भाव विश्लेषण", "दशा भविष्यवाणी"]
        },
        {
          id: 2,
          icon: "HeartIcon",
          title: "संबंध अनुकूलता",
          description: "वैदिक अनुकूलता विश्लेषण के माध्यम से संबंध गतिशीलता को समझें",
          features: ["कुंडली मिलान", "अनुकूलता स्कोर", "उपचारात्मक समाधान"]
        },
        {
          id: 3,
          icon: "BriefcaseIcon",
          title: "करियर मार्गदर्शन",
          description: "ज्योतिषीय अंतर्दृष्टि के साथ अपनी व्यावसायिक यात्रा को नेविगेट करें",
          features: ["करियर समय", "व्यवसाय संभावनाएं", "नौकरी परिवर्तन"]
        },
        {
          id: 4,
          icon: "CalendarDaysIcon",
          title: "मुहूर्त चयन",
          description: "महत्वपूर्ण जीवन घटनाओं के लिए शुभ समय चुनें",
          features: ["विवाह तिथियां", "व्यवसाय शुरुआत", "संपत्ति खरीद"]
        }
      ]
    }
  };

  const text = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-text-primary mb-4">
            {text.sectionTitle}
          </h2>
          <p className="font-body text-lg lg:text-xl text-text-secondary max-w-2xl mx-auto">
            {text.sectionSubtitle}
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 mb-12">
          {text.services.map((service) => (
            <div
              key={service.id}
              className="bg-card rounded-lg p-6 shadow-soft hover:shadow-elevated transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary group-hover:bg-opacity-100 transition-all duration-300">
                <Icon
                  name={service.icon as any}
                  size={28}
                  className="text-primary group-hover:text-primary-foreground transition-colors duration-300"
                />
              </div>

              <h3 className="font-headline text-xl font-semibold text-text-primary mb-3">
                {service.title}
              </h3>

              <p className="font-body text-text-secondary mb-4 leading-relaxed">
                {service.description}
              </p>

              <ul className="space-y-2">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <Icon name="CheckCircleIcon" size={18} className="text-success mt-0.5 flex-shrink-0" variant="solid" />
                    <span className="font-body text-sm text-text-secondary">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link
            href="/services"
            className="inline-flex items-center space-x-2 px-8 py-3 bg-primary text-primary-foreground font-cta font-semibold rounded-lg hover:bg-secondary transition-all duration-300 shadow-soft hover:shadow-elevated"
          >
            <motion.span
              className="inline-flex items-center space-x-2"
              whileHover={{ scale: 1.05, x: 5 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >
              <span>{text.viewAll}</span>
              <Icon name="ArrowRightIcon" size={20} />
            </motion.span>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ServicesOverview;