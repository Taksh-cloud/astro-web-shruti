'use client';

import React, { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface CTASectionProps {
  currentLanguage: 'en' | 'hi';
}

const CTASection = ({ currentLanguage }: CTASectionProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const content = {
    en: {
      title: "Ready to Discover Your Cosmic Path?",
      description: "Book your personalized astrology consultation today and gain clarity for life's important decisions. Available in both Hindi and English.",
      primaryCTA: "Book Consultation Now",
      secondaryCTA: "View Services"
    },
    hi: {
      title: "अपने ब्रह्मांडीय पथ की खोज के लिए तैयार हैं?",
      description: "आज ही अपना व्यक्तिगत ज्योतिष परामर्श बुक करें और जीवन के महत्वपूर्ण निर्णयों के लिए स्पष्टता प्राप्त करें। हिंदी और अंग्रेजी दोनों में उपलब्ध।",
      primaryCTA: "अभी परामर्श बुक करें",
      secondaryCTA: "सेवाएं देखें"
    }
  };

  const text = content[currentLanguage];

  const handleBooking = () => {
    if (!isHydrated) return;
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const whatsappUrl = isMobile 
      ? 'https://wa.me/919079964007?text=Hello%2C%20I%20would%20like%20to%20book%20a%20consultation'
      : 'https://web.whatsapp.com/send?phone=919079964007&text=Hello%2C%20I%20would%20like%20to%20book%20a%20consultation';
    window.open(whatsappUrl, '_blank');
  };

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-primary to-secondary relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-accent rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-primary-foreground mb-6">
            {text.title}
          </h2>
          <p className="font-body text-lg lg:text-xl text-primary-foreground opacity-90 mb-8 max-w-2xl mx-auto">
            {text.description}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <button
              onClick={handleBooking}
              disabled={!isHydrated}
              className="w-full sm:w-auto px-10 py-4 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 flex items-center justify-center space-x-3 shadow-elevated hover:shadow-soft disabled:opacity-50"
            >
              <Icon name="ChatBubbleLeftRightIcon" size={24} />
              <span>{text.primaryCTA}</span>
            </button>
            <a
              href="/services"
              className="w-full sm:w-auto px-10 py-4 bg-card text-text-primary font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 flex items-center justify-center space-x-3 shadow-soft hover:shadow-elevated"
            >
              <span>{text.secondaryCTA}</span>
              <Icon name="ArrowRightIcon" size={20} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;