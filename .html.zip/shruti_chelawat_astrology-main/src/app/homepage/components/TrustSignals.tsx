'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface TrustSignal {
  id: number;
  icon: string;
  value: string;
  label: string;
}

interface TrustSignalsProps {
  currentLanguage: 'en' | 'hi';
}

const TrustSignals = ({ currentLanguage }: TrustSignalsProps) => {
  const content = {
    en: {
      sectionTitle: "Why Choose Shruti Chelawat",
      certificateTitle: "Certified Vedic Astrologer",
      certificateDescription: "Trained in traditional Vedic astrology with comprehensive knowledge of planetary systems, birth chart analysis, and predictive techniques.",
      signals: [
      {
        id: 1,
        icon: "AcademicCapIcon",
        value: "4+ Years",
        label: "Professional Experience"
      },
      {
        id: 2,
        icon: "UserGroupIcon",
        value: "500+",
        label: "Consultations Completed"
      },
      {
        id: 3,
        icon: "StarIcon",
        value: "100%",
        label: "Confidentiality Assured"
      },
      {
        id: 4,
        icon: "LanguageIcon",
        value: "Bilingual",
        label: "Hindi & English"
      }]

    },
    hi: {
      sectionTitle: "श्रुति चेलावत को क्यों चुनें",
      certificateTitle: "प्रमाणित वैदिक ज्योतिषी",
      certificateDescription: "ग्रह प्रणालियों, जन्म कुंडली विश्लेषण और भविष्यवाणी तकनीकों के व्यापक ज्ञान के साथ पारंपरिक वैदिक ज्योतिष में प्रशिक्षित।",
      signals: [
      {
        id: 1,
        icon: "AcademicCapIcon",
        value: "4+ वर्ष",
        label: "व्यावसायिक अनुभव"
      },
      {
        id: 2,
        icon: "UserGroupIcon",
        value: "500+",
        label: "परामर्श पूर्ण"
      },
      {
        id: 3,
        icon: "StarIcon",
        value: "100%",
        label: "गोपनीयता सुनिश्चित"
      },
      {
        id: 4,
        icon: "LanguageIcon",
        value: "द्विभाषी",
        label: "हिंदी और अंग्रेजी"
      }]

    }
  };

  const text = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-muted">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-text-primary mb-4">
            {text.sectionTitle}
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
          <div className="relative max-w-md mx-auto lg:max-w-none">
            <div className="absolute inset-0 bg-primary opacity-10 rounded-lg blur-2xl"></div>
            <div className="relative bg-card rounded-lg p-6 shadow-elevated">
              <div className="aspect-[4/3] rounded-lg overflow-hidden mb-4">
                <AppImage
                  src="/assets/images/shruti_cert_for_web-1767302410804.jpeg"
                  alt={text.certificateTitle}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Icon name="DocumentCheckIcon" size={24} className="text-primary" variant="solid" />
                  <span className="font-body font-medium text-text-primary">
                    {currentLanguage === 'en' ? 'Verified Certificate' : 'सत्यापित प्रमाणपत्र'}
                  </span>
                </div>
                <Icon name="ShieldCheckIcon" size={28} className="text-success" variant="solid" />
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-headline text-2xl lg:text-3xl font-bold text-text-primary mb-4">
              {text.certificateTitle}
            </h3>
            <p className="font-body text-lg text-text-secondary mb-8 leading-relaxed">
              {text.certificateDescription}
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              {text.signals.map((signal) => (
                <div
                  key={signal.id}
                  className="bg-card rounded-lg p-6 shadow-soft hover:shadow-elevated transition-shadow duration-300"
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-primary bg-opacity-20 rounded-full flex items-center justify-center mb-4">
                      <Icon name={signal.icon} size={24} className="text-primary" variant="solid" />
                    </div>
                    <p className="font-cta text-2xl font-bold text-text-primary mb-1">
                      {signal.value}
                    </p>
                    <p className="font-body text-sm text-text-secondary">
                      {signal.label}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustSignals;