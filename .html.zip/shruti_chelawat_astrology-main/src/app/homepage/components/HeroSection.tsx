'use client';

import React, { useState, useEffect } from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

interface HeroSectionProps {
  currentLanguage: 'en' | 'hi';
}

const HeroSection = ({ currentLanguage }: HeroSectionProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const content = {
    en: {
      headline: "Traditional Wisdom, Modern Delivery",
      subheadline: "Discover clarity through authentic Vedic astrology guidance",
      description: "Experience personalized astrological consultations that blend ancient wisdom with contemporary understanding. Get honest, compassionate insights for life's important decisions.",
      experience: "4+ Years of Practice",
      cta: "Book Consultation",
      trustBadge: "Certified Vedic Astrologer",
      nakshatraHint: "Guided by the 27 Nakshatras of Vedic wisdom"
    },
    hi: {
      headline: "पारंपरिक ज्ञान, आधुनिक सेवा",
      subheadline: "प्रामाणिक वैदिक ज्योतिष मार्गदर्शन के माध्यम से स्पष्टता प्राप्त करें",
      description: "व्यक्तिगत ज्योतिषीय परामर्श का अनुभव करें जो प्राचीन ज्ञान को समकालीन समझ के साथ जोड़ता है। जीवन के महत्वपूर्ण निर्णयों के लिए ईमानदार, करुणामय अंतर्दृष्टि प्राप्त करें।",
      experience: "4+ वर्षों का अनुभव",
      cta: "परामर्श बुक करें",
      trustBadge: "प्रमाणित वैदिक ज्योतिषी",
      nakshatraHint: "27 नक्षत्रों के वैदिक ज्ञान द्वारा निर्देशित"
    }
  };

  const text = content[currentLanguage];

  const handleBooking = () => {
    if (!isHydrated) return;
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const whatsappUrl = isMobile ?
    'https://wa.me/919079964007?text=Hello%2C%20I%20would%20like%20to%20book%20a%20consultation' :
    'https://web.whatsapp.com/send?phone=919079964007&text=Hello%2C%20I%20would%20like%20to%20book%20a%20consultation';
    window.open(whatsappUrl, '_blank');
  };

  return (
    <section className="relative bg-gradient-to-br from-primary via-primary to-secondary overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-2 h-2 bg-accent rounded-full animate-pulse"></div>
        <div className="absolute top-20 right-20 w-1 h-1 bg-accent rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 left-1/4 w-1.5 h-1.5 bg-accent rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-accent rounded-full animate-pulse" style={{ animationDelay: '1.5s' }}></div>
        <div className="absolute bottom-1/4 right-1/4 w-2 h-2 bg-accent rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
      </div>
      <div className="container mx-auto px-4 py-16 lg:py-24 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left space-y-6">
            <div className="inline-flex items-center space-x-2 bg-accent bg-opacity-20 px-4 py-2 rounded-full">
              <Icon name="SparklesIcon" size={20} className="text-accent" />
              <span className="font-body text-sm font-medium text-primary-foreground">{text.trustBadge}</span>
            </div>
            <h1 className="font-headline text-4xl lg:text-5xl xl:text-6xl font-bold text-primary-foreground leading-tight">
              {text.headline}
            </h1>
            <p className="font-headline text-xl lg:text-2xl text-primary-foreground opacity-90">
              {text.subheadline}
            </p>
            <p className="font-body text-base lg:text-lg text-primary-foreground opacity-80 max-w-xl mx-auto lg:mx-0">
              {text.description}
            </p>
            <p className="font-body text-sm lg:text-base text-accent italic opacity-90 max-w-xl mx-auto lg:mx-0">
              {text.nakshatraHint}
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-6 pt-4">
              <button
                onClick={handleBooking}
                disabled={!isHydrated}
                className="w-full sm:w-auto px-8 py-4 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 flex items-center justify-center space-x-3 shadow-elevated hover:shadow-soft disabled:opacity-50">
                <Icon name="ChatBubbleLeftRightIcon" size={24} />
                <span>{text.cta}</span>
              </button>
              <div className="flex items-center space-x-3 text-primary-foreground">
                <div className="w-12 h-12 bg-accent bg-opacity-20 rounded-full flex items-center justify-center">
                  <Icon name="StarIcon" size={24} className="text-accent" variant="solid" />
                </div>
                <div>
                  <p className="font-body text-sm opacity-80">{currentLanguage === 'en' ? 'Experience' : 'अनुभव'}</p>
                  <p className="font-cta font-semibold">{text.experience}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="relative w-full max-w-md mx-auto lg:max-w-none">
              <div className="absolute inset-0 bg-accent opacity-20 rounded-full blur-3xl"></div>
              <div className="relative aspect-square rounded-full overflow-hidden border-8 border-primary-foreground border-opacity-20 shadow-elevated">
                <AppImage
                  src="/assets/images/purple-planets-and-universe-aynwazgjgtjk0tw8-1767304169514.jpg"
                  alt="Professional portrait of Shruti Chelawat in elegant purple saree with traditional jewelry, smiling warmly against neutral background"
                  className="w-full h-full object-cover"
                  priority />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-card px-6 py-4 rounded-lg shadow-elevated">
                <div className="flex items-center space-x-3">
                  <Icon name="CheckBadgeIcon" size={32} className="text-success" variant="solid" />
                  <div>
                    <p className="font-cta font-semibold text-text-primary">{currentLanguage === 'en' ? 'Verified' : 'सत्यापित'}</p>
                    <p className="font-body text-sm text-text-secondary">{currentLanguage === 'en' ? 'Astrologer' : 'ज्योतिषी'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;