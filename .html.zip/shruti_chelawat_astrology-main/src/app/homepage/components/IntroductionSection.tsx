'use client';

import React from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';
import { motion } from 'framer-motion';

interface IntroductionSectionProps {
  currentLanguage: 'en' | 'hi';
}

const IntroductionSection: React.FC<IntroductionSectionProps> = ({ currentLanguage }) => {
  const content = {
    en: {
      heading: 'Meet Shruti Chelawat',
      description: 'A passionate Vedic astrologer dedicated to helping individuals find clarity and direction in their lives. With deep knowledge of ancient astrological wisdom and a compassionate approach, Shruti provides personalized guidance for life\'s most important decisions. Her consultations blend traditional Vedic principles with contemporary understanding, offering insights into career, relationships, health, and personal growth.',
      buttonText: 'Learn More About Shruti',
      nakshatraTagline: 'Precision through Nakshatra-based readings'
    },
    hi: {
      heading: 'श्रुति चेलावत से मिलें',
      description: 'एक समर्पित वैदिक ज्योतिषी जो व्यक्तियों को उनके जीवन में स्पष्टता और दिशा खोजने में मदद करती हैं। प्राचीन ज्योतिषीय ज्ञान और करुणामय दृष्टिकोण के साथ, श्रुति जीवन के सबसे महत्वपूर्ण निर्णयों के लिए व्यक्तिगत मार्गदर्शन प्रदान करती हैं। उनके परामर्श पारंपरिक वैदिक सिद्धांतों को समकालीन समझ के साथ मिलाते हैं, करियर, रिश्ते, स्वास्थ्य और व्यक्तिगत विकास में अंतर्दृष्टि प्रदान करते हैं।',
      buttonText: 'श्रुति के बारे में और जानें',
      nakshatraTagline: 'नक्षत्र-आधारित रीडिंग के माध्यम से सटीकता'
    }
  };

  const currentContent = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Image Column */}
            <div className="order-2 md:order-1">
              <div className="relative rounded-2xl overflow-hidden shadow-elevated hover:shadow-soft transition-shadow duration-300">
                <AppImage
                  src="https://img.rocket.new/generatedImages/rocket_gen_img_186207b23-1767929898042.png"
                  alt="Shruti Chelawat in purple saree receiving an award"
                  className="w-full h-auto object-cover"
                  width={600}
                  height={800} />

              </div>
            </div>

            {/* Content Column */}
            <div className="order-1 md:order-2 space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground">
                {currentContent.heading}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                {currentContent.description}
              </p>
              <p className="text-base text-accent italic font-medium">
                {currentContent.nakshatraTagline}
              </p>
              <Link href="/about">
                <motion.button
                  className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors duration-200 text-sm font-medium shadow-sm hover:shadow-md"
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}>

                  {currentContent.buttonText}
                </motion.button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>);

};

export default IntroductionSection;