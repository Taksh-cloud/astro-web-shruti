'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/common/Header';
import HeroSection from './HeroSection';
import IntroductionSection from './IntroductionSection';
import ServicesOverview from './ServicesOverview';
import ApproachHighlight from './ApproachHighlight';
import CTASection from './CTASection';
import Footer from './Footer';
import FAQChatbot from '@/components/chatbot/FAQChatbot';
import Icon from '@/components/ui/AppIcon';

const HomepageInteractive = () => {
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hi'>('en');
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
    
    const savedLanguage = localStorage.getItem('preferredLanguage') as 'en' | 'hi' | null;
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }

    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleLanguage = () => {
    const newLanguage = currentLanguage === 'en' ? 'hi' : 'en';
    setCurrentLanguage(newLanguage);
    if (isHydrated) {
      localStorage.setItem('preferredLanguage', newLanguage);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWhatsApp = () => {
    if (!isHydrated) return;
    
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const whatsappUrl = isMobile 
      ? 'https://wa.me/919079964007?text=Hello%2C%20I%20would%20like%20to%20book%20a%20consultation'
      : 'https://web.whatsapp.com/send?phone=919079964007&text=Hello%2C%20I%20would%20like%20to%20book%20a%20consultation';
    
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <button
        onClick={toggleLanguage}
        className="fixed top-24 right-4 z-40 w-12 h-12 bg-card shadow-elevated rounded-full flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all duration-300"
        aria-label="Toggle language"
      >
        <Icon name="LanguageIcon" size={24} />
      </button>

      <button
        onClick={handleWhatsApp}
        disabled={!isHydrated}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-whatsapp text-whatsapp-foreground rounded-full flex items-center justify-center shadow-elevated hover:shadow-soft transition-all duration-300 disabled:opacity-50"
        aria-label="WhatsApp consultation"
      >
        <Icon name="ChatBubbleLeftRightIcon" size={28} />
      </button>

      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-24 right-6 z-40 w-12 h-12 bg-secondary text-secondary-foreground rounded-full flex items-center justify-center shadow-elevated hover:shadow-soft transition-all duration-300"
          aria-label="Scroll to top"
        >
          <Icon name="ArrowUpIcon" size={24} />
        </button>
      )}

      <main className="pt-16 lg:pt-20">
        <HeroSection currentLanguage={currentLanguage} />
        <IntroductionSection currentLanguage={currentLanguage} />
        <ServicesOverview currentLanguage={currentLanguage} />
        <ApproachHighlight currentLanguage={currentLanguage} />
        <CTASection currentLanguage={currentLanguage} />
      </main>

      <Footer currentLanguage={currentLanguage} />
      <FAQChatbot />
    </div>
  );
};

export default HomepageInteractive;