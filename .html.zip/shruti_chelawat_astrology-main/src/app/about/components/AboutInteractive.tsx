'use client';

import React, { useState, useEffect } from 'react';
import HeroSection from './HeroSection';
import JourneySection from './JourneySection';
import CredentialsSection from './CredentialsSection';
import PhilosophySection from './PhilosophySection';
import CTASection from './CTASection';
import Icon from '@/components/ui/AppIcon';

const AboutInteractive = () => {
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hi'>('en');
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
    const savedLanguage = localStorage.getItem('preferredLanguage') as 'en' | 'hi' | null;
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  const handleLanguageToggle = () => {
    const newLanguage = currentLanguage === 'en' ? 'hi' : 'en';
    setCurrentLanguage(newLanguage);
    if (isHydrated) {
      localStorage.setItem('preferredLanguage', newLanguage);
    }
  };

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background">
        <div className="h-16 lg:h-20"></div>
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-6xl mx-auto">
            <div className="animate-pulse space-y-8">
              <div className="h-64 bg-muted rounded-lg"></div>
              <div className="h-96 bg-muted rounded-lg"></div>
              <div className="h-96 bg-muted rounded-lg"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="h-16 lg:h-20"></div>

      <button
        onClick={handleLanguageToggle}
        className="fixed top-20 right-4 lg:top-24 lg:right-8 z-40 bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow-elevated hover:bg-opacity-90 transition-all duration-300 flex items-center space-x-2"
        aria-label="Toggle language"
      >
        <Icon name="LanguageIcon" size={20} />
        <span className="font-cta font-semibold text-sm">
          {currentLanguage === 'en' ? 'हिंदी' : 'English'}
        </span>
      </button>

      <HeroSection currentLanguage={currentLanguage} />
      <JourneySection currentLanguage={currentLanguage} />
      <CredentialsSection currentLanguage={currentLanguage} />
      <PhilosophySection currentLanguage={currentLanguage} />
      <CTASection currentLanguage={currentLanguage} />
    </div>
  );
};

export default AboutInteractive;