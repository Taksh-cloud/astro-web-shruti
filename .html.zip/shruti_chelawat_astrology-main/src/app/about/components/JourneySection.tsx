import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface JourneySectionProps {
  currentLanguage: 'en' | 'hi';
}

interface JourneyMilestone {
  year: string;
  title: string;
  description: string;
  icon: string;
}

const JourneySection = ({ currentLanguage }: JourneySectionProps) => {
  const content = {
    en: {
      heading: "My Astrological Journey",
      subheading: "From Curiosity to Calling",
      milestones: [
        {
          year: "2019",
          title: "The Awakening",
          description: "My journey began with a personal life challenge that led me to seek answers in Vedic astrology. What started as curiosity transformed into a profound calling.",
          icon: "SparklesIcon"
        },
        {
          year: "2020",
          title: "Formal Training",
          description: "Enrolled in comprehensive Vedic astrology courses, studying under renowned practitioners. Learned the intricate science of birth charts, planetary movements, and cosmic influences.",
          icon: "AcademicCapIcon"
        },
        {
          year: "2021",
          title: "Practice & Refinement",
          description: "Began offering consultations to friends and family, refining my interpretation skills and developing my unique approach of combining traditional wisdom with practical guidance.",
          icon: "LightBulbIcon"
        },
        {
          year: "2022-Present",
          title: "Professional Practice",
          description: "Established my professional practice, helping hundreds of clients find clarity in relationships, career, health, and life decisions through authentic Vedic astrology guidance.",
          icon: "StarIcon"
        }
      ]
    },
    hi: {
      heading: "मेरी ज्योतिषीय यात्रा",
      subheading: "जिज्ञासा से बुलावे तक",
      milestones: [
        {
          year: "2019",
          title: "जागृति",
          description: "मेरी यात्रा एक व्यक्तिगत जीवन चुनौती के साथ शुरू हुई जिसने मुझे वैदिक ज्योतिष में उत्तर खोजने के लिए प्रेरित किया। जो जिज्ञासा के रूप में शुरू हुआ वह एक गहन बुलावे में बदल गया।",
          icon: "SparklesIcon"
        },
        {
          year: "2020",
          title: "औपचारिक प्रशिक्षण",
          description: "व्यापक वैदिक ज्योतिष पाठ्यक्रमों में नामांकित, प्रसिद्ध चिकित्सकों के तहत अध्ययन किया। जन्म कुंडली, ग्रहों की गति और ब्रह्मांडीय प्रभावों के जटिल विज्ञान को सीखा।",
          icon: "AcademicCapIcon"
        },
        {
          year: "2021",
          title: "अभ्यास और परिशोधन",
          description: "दोस्तों और परिवार को परामर्श देना शुरू किया, अपनी व्याख्या कौशल को परिष्कृत किया और पारंपरिक ज्ञान को व्यावहारिक मार्गदर्शन के साथ जोड़ने का अपना अनूठा दृष्टिकोण विकसित किया।",
          icon: "LightBulbIcon"
        },
        {
          year: "2022-वर्तमान",
          title: "पेशेवर अभ्यास",
          description: "अपनी पेशेवर प्रैक्टिस स्थापित की, सैकड़ों ग्राहकों को प्रामाणिक वैदिक ज्योतिष मार्गदर्शन के माध्यम से संबंधों, करियर, स्वास्थ्य और जीवन के निर्णयों में स्पष्टता खोजने में मदद की।",
          icon: "StarIcon"
        }
      ]
    }
  };

  const text = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-semibold text-primary mb-4">
              {text.heading}
            </h2>
            <p className="font-body text-lg lg:text-xl text-text-secondary">
              {text.subheading}
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border hidden lg:block"></div>
            
            <div className="space-y-8 lg:space-y-12">
              {text.milestones.map((milestone: JourneyMilestone, index: number) => (
                <div key={index} className="relative">
                  <div className="lg:pl-20">
                    <div className="bg-card rounded-lg p-6 lg:p-8 shadow-soft hover:shadow-elevated transition-shadow duration-300">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 lg:w-14 lg:h-14 bg-primary rounded-full flex items-center justify-center">
                            <Icon name={milestone.icon as any} size={24} className="text-primary-foreground" />
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <span className="font-cta text-sm lg:text-base font-semibold text-accent bg-accent bg-opacity-10 px-3 py-1 rounded-full">
                              {milestone.year}
                            </span>
                          </div>
                          <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-3">
                            {milestone.title}
                          </h3>
                          <p className="font-body text-base text-text-secondary leading-relaxed">
                            {milestone.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="absolute left-8 top-6 w-4 h-4 bg-accent rounded-full border-4 border-background hidden lg:block transform -translate-x-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JourneySection;