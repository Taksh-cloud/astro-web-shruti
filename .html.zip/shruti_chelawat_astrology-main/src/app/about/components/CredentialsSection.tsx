import React from 'react';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

interface CredentialsSectionProps {
  currentLanguage: 'en' | 'hi';
}

interface Credential {
  title: string;
  institution: string;
  year: string;
  description: string;
}

const CredentialsSection = ({ currentLanguage }: CredentialsSectionProps) => {
  const content = {
    en: {
      heading: "Credentials & Training",
      subheading: "Formal Education in Vedic Sciences",
      credentials: [
      {
        title: "Advanced Vedic Astrology Certification",
        institution: "Institute of Vedic Astrology",
        year: "2020",
        description: "Comprehensive training in birth chart analysis, planetary transits, dashas, and predictive techniques"
      },
      {
        title: "Specialized Training in Relationship Astrology",
        institution: "Jyotish Academy",
        year: "2021",
        description: "In-depth study of compatibility analysis, marriage timing, and relationship dynamics through astrological principles"
      },
      {
        title: "Career & Financial Astrology",
        institution: "Vedic Sciences Institute",
        year: "2022",
        description: "Focused training on career guidance, business timing, and financial prosperity indicators in birth charts"
      }],

      experienceTitle: "Professional Experience",
      experienceYears: "4+ Years",
      experienceDescription: "Over 500 successful consultations helping clients navigate life decisions with clarity and confidence",
      certificateAlt: "Certificate of Completion for Basic Astrology and Zodiac Reiki workshop completed by Shruti Chelawat on 22nd Jan, 2021, certified by Daksha Nichani"
    },
    hi: {
      heading: "प्रमाण पत्र और प्रशिक्षण",
      subheading: "वैदिक विज्ञान में औपचारिक शिक्षा",
      credentials: [
      {
        title: "उन्नत वैदिक ज्योतिष प्रमाणन",
        institution: "वैदिक ज्योतिष संस्थान",
        year: "2020",
        description: "जन्म कुंडली विश्लेषण, ग्रह संक्रमण, दशाओं और भविष्यवाणी तकनीकों में व्यापक प्रशिक्षण"
      },
      {
        title: "संबंध ज्योतिष में विशेष प्रशिक्षण",
        institution: "ज्योतिष अकादमी",
        year: "2021",
        description: "ज्योतिषीय सिद्धांतों के माध्यम से अनुकूलता विश्लेषण, विवाह समय और संबंध गतिशीलता का गहन अध्ययन"
      },
      {
        title: "करियर और वित्तीय ज्योतिष",
        institution: "वैदिक विज्ञान संस्थान",
        year: "2022",
        description: "जन्म कुंडली में करियर मार्गदर्शन, व्यवसाय समय और वित्तीय समृद्धि संकेतकों पर केंद्रित प्रशिक्षण"
      }],

      experienceTitle: "पेशेवर अनुभव",
      experienceYears: "4+ वर्ष",
      experienceDescription: "500 से अधिक सफल परामर्श ग्राहकों को स्पष्टता और आत्मविश्वास के साथ जीवन के निर्णयों को नेविगेट करने में मदद करते हैं",
      certificateAlt: "श्रुति चेलावत द्वारा 22 जनवरी, 2021 को पूर्ण किए गए बेसिक एस्ट्रोलॉजी और राशि रेकी कार्यशाला के लिए पूर्णता प्रमाणपत्र, दक्षा निचानी द्वारा प्रमाणित"
    }
  };

  const text = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-text-primary mb-4">
            {text.heading}
          </h2>
          <p className="font-body text-lg text-text-secondary max-w-2xl mx-auto">
            {text.subheading}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
          <div>
            <div className="space-y-6">
              {text.credentials.map((credential, index) => (
                <div
                  key={index}
                  className="bg-card rounded-lg p-6 shadow-elevated hover:shadow-hover transition-shadow duration-300"
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-primary bg-opacity-20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon name="AcademicCapIcon" size={24} className="text-primary" variant="solid" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-headline text-xl font-semibold text-text-primary mb-1">
                        {credential.title}
                      </h3>
                      <p className="font-body text-sm text-text-secondary mb-2">
                        {credential.institution} • {credential.year}
                      </p>
                      <p className="font-body text-text-secondary leading-relaxed">
                        {credential.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 bg-muted rounded-lg p-6">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-success bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon name="BriefcaseIcon" size={32} className="text-success" variant="solid" />
                </div>
                <div>
                  <h3 className="font-headline text-2xl font-bold text-text-primary mb-1">
                    {text.experienceTitle}
                  </h3>
                  <p className="font-cta text-lg font-semibold text-primary mb-2">
                    {text.experienceYears}
                  </p>
                  <p className="font-body text-text-secondary">
                    {text.experienceDescription}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <div className="relative max-w-md mx-auto lg:max-w-none">
              <div className="absolute inset-0 bg-primary opacity-10 rounded-lg blur-2xl"></div>
              <div className="relative bg-card rounded-lg p-6 shadow-elevated">
                <div className="aspect-[4/3] rounded-lg overflow-hidden mb-4">
                  <AppImage
                    src="/assets/images/shruti_cert_for_web-1767302410804.jpeg"
                    alt={text.certificateAlt}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Icon name="DocumentCheckIcon" size={24} className="text-primary" variant="solid" />
                    <span className="font-body font-medium text-text-primary">
                      {currentLanguage === 'en' ? 'Verified Certificate' : 'सत्यापित प्रमाणपत्र'}
                    </span>
                  </div>
                  <Icon name="ShieldCheckIcon" size={28} className="text-success" variant="solid" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CredentialsSection;