import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface CTASectionProps {
  currentLanguage: 'en' | 'hi';
}

const CTASection = ({ currentLanguage }: CTASectionProps) => {
  const content = {
    en: {
      heading: "Ready to Begin Your Journey?",
      description: "Let\'s explore your cosmic blueprint together and find the clarity you seek. Book your personalized consultation today.",
      buttonText: "Book Consultation",
      features: [
      "Personalized birth chart analysis",
      "Honest, compassionate guidance",
      "Practical life solutions"]

    },
    hi: {
      heading: "अपनी यात्रा शुरू करने के लिए तैयार हैं?",
      description: "आइए एक साथ अपनी ब्रह्मांडीय योजना का पता लगाएं और वह स्पष्टता पाएं जिसकी आप तलाश कर रहे हैं। आज ही अपना व्यक्तिगत परामर्श बुक करें।",
      buttonText: "परामर्श बुक करें",
      features: [
      "व्यक्तिगत जन्म कुंडली विश्लेषण",
      "ईमानदार, दयालु मार्गदर्शन",
      "व्यावहारिक जीवन समाधान"]

    }
  };

  const text = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-primary via-primary to-secondary relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-64 h-64 bg-accent rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-accent rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-semibold text-primary-foreground mb-6">
            {text.heading}
          </h2>
          <p className="font-body text-lg lg:text-xl text-primary-foreground opacity-90 mb-8 leading-relaxed">
            {text.description}
          </p>

          <a
            href="https://wa.me/919079964007"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-3 px-8 py-4 bg-whatsapp text-whatsapp-foreground font-cta font-semibold text-lg rounded-lg hover:bg-opacity-90 transition-all duration-300 shadow-elevated hover:shadow-soft hover:scale-105">
            <Icon name="ChatBubbleLeftRightIcon" size={24} />
            <span>{text.buttonText}</span>
          </a>
        </div>
      </div>
    </section>);

};

export default CTASection;