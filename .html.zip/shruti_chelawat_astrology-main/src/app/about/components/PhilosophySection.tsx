import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface PhilosophySectionProps {
  currentLanguage: 'en' | 'hi';
}

interface PhilosophyPrinciple {
  icon: string;
  title: string;
  description: string;
}

const PhilosophySection = ({ currentLanguage }: PhilosophySectionProps) => {
  const content = {
    en: {
      heading: "My Philosophy & Approach",
      subheading: "Guiding Principles That Shape My Practice",
      intro: "My approach to Vedic astrology is rooted in authenticity, compassion, and empowerment. I believe astrology should illuminate your path, not create fear or dependency.",
      principles: [
        {
          icon: "HeartIcon",
          title: "Truth with Compassion",
          description: "I provide honest insights while maintaining sensitivity to your emotional state. Astrology should empower, not overwhelm."
        },
        {
          icon: "ShieldCheckIcon",
          title: "No Fear-Based Predictions",
          description: "I reject superstitious interpretations and fear-mongering. Every challenge in your chart is an opportunity for growth and understanding."
        },
        {
          icon: "LightBulbIcon",
          title: "Practical Wisdom",
          description: "Ancient knowledge meets modern life. I translate cosmic patterns into actionable insights you can apply to real-world decisions."
        },
        {
          icon: "UserGroupIcon",
          title: "Personalized Guidance",
          description: "Your birth chart is unique. I provide customized interpretations that honor your individual journey and circumstances."
        },
        {
          icon: "LockClosedIcon",
          title: "Complete Confidentiality",
          description: "Your personal information and consultation details remain strictly private. Trust is the foundation of our relationship."
        },
        {
          icon: "AcademicCapIcon",
          title: "Continuous Learning",
          description: "I stay updated with traditional texts and modern interpretations, ensuring you receive well-rounded, informed guidance."
        }
      ]
    },
    hi: {
      heading: "मेरा दर्शन और दृष्टिकोण",
      subheading: "मार्गदर्शक सिद्धांत जो मेरे अभ्यास को आकार देते हैं",
      intro: "वैदिक ज्योतिष के प्रति मेरा दृष्टिकोण प्रामाणिकता, करुणा और सशक्तिकरण में निहित है। मेरा मानना है कि ज्योतिष को आपके मार्ग को रोशन करना चाहिए, न कि भय या निर्भरता पैदा करनी चाहिए।",
      principles: [
        {
          icon: "HeartIcon",
          title: "करुणा के साथ सत्य",
          description: "मैं आपकी भावनात्मक स्थिति के प्रति संवेदनशीलता बनाए रखते हुए ईमानदार अंतर्दृष्टि प्रदान करती हूं। ज्योतिष को सशक्त बनाना चाहिए, अभिभूत नहीं करना चाहिए।"
        },
        {
          icon: "ShieldCheckIcon",
          title: "कोई भय-आधारित भविष्यवाणी नहीं",
          description: "मैं अंधविश्वासी व्याख्याओं और भय फैलाने को अस्वीकार करती हूं। आपकी कुंडली में हर चुनौती विकास और समझ का अवसर है।"
        },
        {
          icon: "LightBulbIcon",
          title: "व्यावहारिक ज्ञान",
          description: "प्राचीन ज्ञान आधुनिक जीवन से मिलता है। मैं ब्रह्मांडीय पैटर्न को कार्रवाई योग्य अंतर्दृष्टि में अनुवाद करती हूं जिसे आप वास्तविक दुनिया के निर्णयों पर लागू कर सकते हैं।"
        },
        {
          icon: "UserGroupIcon",
          title: "व्यक्तिगत मार्गदर्शन",
          description: "आपकी जन्म कुंडली अद्वितीय है। मैं अनुकूलित व्याख्याएं प्रदान करती हूं जो आपकी व्यक्तिगत यात्रा और परिस्थितियों का सम्मान करती हैं।"
        },
        {
          icon: "LockClosedIcon",
          title: "पूर्ण गोपनीयता",
          description: "आपकी व्यक्तिगत जानकारी और परामर्श विवरण सख्ती से निजी रहते हैं। विश्वास हमारे संबंध की नींव है।"
        },
        {
          icon: "AcademicCapIcon",
          title: "निरंतर सीखना",
          description: "मैं पारंपरिक ग्रंथों और आधुनिक व्याख्याओं के साथ अपडेट रहती हूं, यह सुनिश्चित करते हुए कि आपको सर्वांगीण, सूचित मार्गदर्शन मिले।"
        }
      ]
    }
  };

  const text = content[currentLanguage];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-semibold text-primary mb-4">
              {text.heading}
            </h2>
            <p className="font-body text-lg lg:text-xl text-text-secondary mb-6">
              {text.subheading}
            </p>
            <p className="font-body text-base lg:text-lg text-text-primary max-w-3xl mx-auto leading-relaxed">
              {text.intro}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {text.principles.map((principle: PhilosophyPrinciple, index: number) => (
              <div key={index} className="bg-card rounded-lg p-6 shadow-soft hover:shadow-elevated transition-all duration-300 hover:-translate-y-1">
                <div className="w-14 h-14 bg-primary rounded-full flex items-center justify-center mb-4">
                  <Icon name={principle.icon as any} size={28} className="text-primary-foreground" />
                </div>
                <h3 className="font-headline text-xl font-semibold text-text-primary mb-3">
                  {principle.title}
                </h3>
                <p className="font-body text-sm text-text-secondary leading-relaxed">
                  {principle.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PhilosophySection;