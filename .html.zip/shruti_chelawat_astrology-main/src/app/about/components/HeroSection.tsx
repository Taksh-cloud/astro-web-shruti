import React from 'react';
import AppImage from '@/components/ui/AppImage';

interface HeroSectionProps {
  currentLanguage: 'en' | 'hi';
}

const HeroSection = ({ currentLanguage }: HeroSectionProps) => {
  const content = {
    en: {
      title: "Meet Shruti Chelawat",
      subtitle: "Your Guide to Cosmic Clarity",
      description: "With over 4 years of dedicated practice in Vedic astrology, I bridge ancient wisdom with modern understanding to help you navigate life's journey with confidence and clarity.",
      nakshatraTagline: "Specializing in Nakshatra-based astrological insights"
    },
    hi: {
      title: "श्रुति चेलावत से मिलें",
      subtitle: "आपकी कॉस्मिक स्पष्टता की मार्गदर्शिका",
      description: "वैदिक ज्योतिष में 4 से अधिक वर्षों के समर्पित अभ्यास के साथ, मैं प्राचीन ज्ञान को आधुनिक समझ से जोड़ती हूं ताकि आप आत्मविश्वास और स्पष्टता के साथ जीवन की यात्रा को नेविगेट कर सकें।",
      nakshatraTagline: "नक्षत्र-आधारित ज्योतिषीय अंतर्दृष्टि में विशेषज्ञता"
    }
  };

  const text = content[currentLanguage];

  return (
    <section className="relative bg-gradient-to-br from-primary via-primary to-secondary py-16 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 bg-accent rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-accent rounded-full blur-3xl"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="order-2 lg:order-1 text-center lg:text-left">
              <h1 className="font-headline text-4xl lg:text-5xl xl:text-6xl font-semibold text-primary-foreground mb-4 leading-tight">
                {text.title}
              </h1>
              <p className="font-cta text-xl lg:text-2xl text-accent mb-6">
                {text.subtitle}
              </p>
              <p className="font-body text-base lg:text-lg text-primary-foreground opacity-90 leading-relaxed">
                {text.description}
              </p>
              <p className="font-body text-sm lg:text-base text-accent italic opacity-95 mt-3">
                {text.nakshatraTagline}
              </p>
            </div>
            
            <div className="order-1 lg:order-2 flex justify-center">
              <div className="relative w-64 h-64 lg:w-80 lg:h-80 xl:w-96 xl:h-96">
                <div className="absolute inset-0 bg-accent rounded-full opacity-20 blur-2xl"></div>
                <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-accent shadow-elevated">
                  <AppImage
                    src="/assets/images/shruti_pfp_for_web-1767303714640.jpeg"
                    alt="Shruti Chelawat in traditional purple saree with warm smile, professional astrology consultation portrait"
                    className="w-full h-full object-cover" />

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>);

};

export default HeroSection;