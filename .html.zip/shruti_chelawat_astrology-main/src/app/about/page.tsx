import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import AboutInteractive from './components/AboutInteractive';

export const metadata: Metadata = {
  title: 'About Shruti Chelawat - Shruti Chelawat Astrology',
  description: 'Discover Shruti Chelawat\'s journey in Vedic astrology, credentials, philosophy, and approach. Over 4 years of experience providing authentic, compassionate astrological guidance combining traditional wisdom with modern understanding.',
};

export default function AboutPage() {
  return (
    <>
      <Header />
      <AboutInteractive />
    </>
  );
}