import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import ServicesInteractive from './components/ServicesInteractive';

export const metadata: Metadata = {
  title: 'Services - Shruti Chelawat Astrology',
  description: 'Explore comprehensive Vedic astrology consultation services including birth chart analysis, career guidance, relationship insights, and personalized remedies with transparent pricing and authentic guidance.',
};

export default function ServicesPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <div className="pt-16 lg:pt-20">
        <ServicesInteractive />
      </div>
    </main>
  );
}