import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface ComparisonFeature {
  feature: string;
  featureHindi: string;
  basic: boolean;
  detailed: boolean;
  premium: boolean;
}

interface ComparisonTableProps {
  features: ComparisonFeature[];
  currentLanguage: string;
}

const ComparisonTable = ({ features, currentLanguage }: ComparisonTableProps) => {
  const renderCheckmark = (included: boolean) => {
    return included ? (
      <Icon name="CheckIcon" size={24} className="text-success" />
    ) : (
      <Icon name="XMarkIcon" size={24} className="text-text-secondary opacity-30" />
    );
  };

  return (
    <div className="bg-card rounded-xl shadow-soft overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-primary text-primary-foreground">
              <th className="px-6 py-4 text-left font-cta font-semibold">
                {currentLanguage === 'hindi' ? 'सुविधाएं' : 'Features'}
              </th>
              <th className="px-6 py-4 text-center font-cta font-semibold">
                {currentLanguage === 'hindi' ? 'बेसिक' : 'Basic'}
              </th>
              <th className="px-6 py-4 text-center font-cta font-semibold">
                {currentLanguage === 'hindi' ? 'विस्तृत' : 'Detailed'}
              </th>
              <th className="px-6 py-4 text-center font-cta font-semibold">
                {currentLanguage === 'hindi' ? 'प्रीमियम' : 'Premium'}
              </th>
            </tr>
          </thead>
          <tbody>
            {features.map((item, index) => (
              <tr key={index} className={index % 2 === 0 ? 'bg-muted bg-opacity-30' : 'bg-card'}>
                <td className="px-6 py-4 font-body text-text-primary">
                  {currentLanguage === 'hindi' ? item.featureHindi : item.feature}
                </td>
                <td className="px-6 py-4 text-center">
                  {renderCheckmark(item.basic)}
                </td>
                <td className="px-6 py-4 text-center">
                  {renderCheckmark(item.detailed)}
                </td>
                <td className="px-6 py-4 text-center">
                  {renderCheckmark(item.premium)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ComparisonTable;