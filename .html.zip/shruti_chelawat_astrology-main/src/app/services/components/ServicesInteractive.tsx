'use client';

import React, { useState, useEffect } from 'react';

import ServiceCard from './ServiceCard';
import PreparationGuide from './PreparationGuide';

import ServiceFAQ from './ServiceFAQ';
import { motion } from 'framer-motion';

interface Service {
  id: number;
  title: string;
  titleHindi: string;
  description: string;
  descriptionHindi: string;
  duration?: string;
  durationHindi?: string;
  price?: string;
  features: string[];
  featuresHindi: string[];
  icon: string;
  isPopular: boolean;
  category: string;
  categoryHindi: string;
}

interface PreparationStep {
  title: string;
  titleHindi: string;
  description: string;
  descriptionHindi: string;
  icon: string;
}

interface ComparisonFeature {
  feature: string;
  featureHindi: string;
  basic: boolean;
  detailed: boolean;
  premium: boolean;
}

interface FAQItem {
  question: string;
  questionHindi: string;
  answer: string;
  answerHindi: string;
}

const ServicesInteractive = () => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('english');

  useEffect(() => {
    setIsHydrated(true);
    const savedLanguage = localStorage.getItem('preferredLanguage') || 'english';
    setCurrentLanguage(savedLanguage);
  }, []);

  const handleLanguageToggle = () => {
    const newLanguage = currentLanguage === 'english' ? 'hindi' : 'english';
    setCurrentLanguage(newLanguage);
    if (isHydrated) {
      localStorage.setItem('preferredLanguage', newLanguage);
    }
  };

  const nakshatraTaglines = {
    english: "Precise readings through the 27 Nakshatras of Vedic tradition",
    hindi: "वैदिक परंपरा के 27 नक्षत्रों के माध्यम से सटीक रीडिंग"
  };

  const services: Service[] = [
  {
    id: 1,
    title: "Life Events & Guidance",
    titleHindi: "जीवन घटनाएं और मार्गदर्शन",
    description: "Comprehensive predictions of future possibilities, significant life events, opportunities, and challenging periods based on planetary transits and Dasha systems, along with insights into spiritual path and remedial measures.",
    descriptionHindi: "ग्रह संक्रमण और दशा प्रणालियों के आधार पर भविष्य की संभावनाओं, महत्वपूर्ण जीवन घटनाओं, अवसरों और चुनौतीपूर्ण अवधियों की व्यापक भविष्यवाणियां, आध्यात्मिक पथ और उपचारात्मक उपायों की अंतर्दृष्टि के साथ।",
    duration: "1 hour per live consultation",
    durationHindi: "प्रति लाइव परामर्श 1 घंटा",
    price: "₹999 for any two niches",
    features: [
      "Future Trends: Prediction of future possibilities and significant life events",
      "Opportunities and challenging periods based on planetary transits",
      "Dasha (planetary periods) systems analysis",
      "Spiritual Path: Insights into spiritual inclinations and higher learning",
      "Luck and purpose in life guidance",
      "Remedial Measures: Mantras, gemstones, and lifestyle changes",
      "Suggestions to mitigate negative planetary influences and balance energies"
    ],
    featuresHindi: [
      "भविष्य के रुझान: भविष्य की संभावनाओं और महत्वपूर्ण जीवन घटनाओं की भविष्यवाणी",
      "ग्रह संक्रमण के आधार पर अवसर और चुनौतीपूर्ण अवधियां",
      "दशा (ग्रह अवधि) प्रणाली विश्लेषण",
      "आध्यात्मिक पथ: आध्यात्मिक झुकाव और उच्च शिक्षा की अंतर्दृष्टि",
      "भाग्य और जीवन में उद्देश्य मार्गदर्शन",
      "उपचारात्मक उपाय: मंत्र, रत्न और जीवनशैली परिवर्तन",
      "नकारात्मक ग्रह प्रभावों को कम करने और ऊर्जा को संतुलित करने के सुझाव"
    ],
    icon: "SparklesIcon",
    isPopular: false,
    category: "Specialized",
    categoryHindi: "विशेष"
  },
  {
    id: 2,
    title: "Health & Well-being",
    titleHindi: "स्वास्थ्य और कल्याण",
    description: "Identification of potential health issues, strengths, weaknesses, and general vitality, along with analysis of specific astrological challenges or doshas that may indicate obstacles or ongoing problems in life.",
    descriptionHindi: "संभावित स्वास्थ्य समस्याओं, शक्तियों, कमजोरियों और सामान्य जीवन शक्ति की पहचान, विशिष्ट ज्योतिषीय चुनौतियों या दोषों के विश्लेषण के साथ जो जीवन में बाधाओं या चल रही समस्याओं का संकेत दे सकते हैं।",
    duration: "1 hour per live consultation",
    durationHindi: "प्रति लाइव परामर्श 1 घंटा",
    price: "₹999 for any two niches",
    features: [
      "Physical Health: Identification of potential health issues",
      "Analysis of strengths, weaknesses, and general vitality",
      "Body constitution and health tendencies",
      "Challenges & Doshas: Identification of specific astrological challenges",
      "Manglik Dosha analysis and remedies",
      "Kaal Sarp Dosha identification and solutions",
      "Pitra Dosha assessment and corrective measures"
    ],
    featuresHindi: [
      "शारीरिक स्वास्थ्य: संभावित स्वास्थ्य समस्याओं की पहचान",
      "शक्तियों, कमजोरियों और सामान्य जीवन शक्ति का विश्लेषण",
      "शरीर संरचना और स्वास्थ्य प्रवृत्तियां",
      "चुनौतियां और दोष: विशिष्ट ज्योतिषीय चुनौतियों की पहचान",
      "मांगलिक दोष विश्लेषण और उपाय",
      "काल सर्प दोष पहचान और समाधान",
      "पितृ दोष मूल्यांकन और सुधारात्मक उपाय"
    ],
    icon: "HeartIcon",
    isPopular: false,
    category: "Specialized",
    categoryHindi: "विशेष"
  },
  {
    id: 3,
    title: "Career & Finances",
    titleHindi: "करियर और वित्त",
    description: "Comprehensive guidance on suitable professions, career potential, leadership roles, financial stability, earning potential, wealth accumulation, and insights into business partnerships and professional ventures.",
    descriptionHindi: "उपयुक्त व्यवसायों, करियर क्षमता, नेतृत्व भूमिकाओं, वित्तीय स्थिरता, कमाई की क्षमता, धन संचय और व्यावसायिक साझेदारी और पेशेवर उद्यमों की अंतर्दृष्टि पर व्यापक मार्गदर्शन।",
    duration: "1 hour per live consultation",
    durationHindi: "प्रति लाइव परामर्श 1 घंटा",
    price: "₹999 for any two niches",
    features: [
      "Career Path: Guidance on suitable professions and career potential",
      "Leadership roles and opportunities for success and recognition",
      "Analysis of 10th and 6th houses for career insights",
      "Financial Stability: Indications of earning potential and wealth accumulation",
      "Savings potential and financial gains or losses predictions",
      "Business & Ventures: Insights into favorability of business partnerships",
      "Investment guidance and professional venture analysis"
    ],
    featuresHindi: [
      "करियर पथ: उपयुक्त व्यवसायों और करियर क्षमता पर मार्गदर्शन",
      "नेतृत्व भूमिकाएं और सफलता और मान्यता के अवसर",
      "करियर अंतर्दृष्टि के लिए 10वें और 6वें घरों का विश्लेषण",
      "वित्तीय स्थिरता: कमाई की क्षमता और धन संचय के संकेत",
      "बचत क्षमता और वित्तीय लाभ या हानि की भविष्यवाणियां",
      "व्यवसाय और उद्यम: व्यावसायिक साझेदारी की अनुकूलता की अंतर्दृष्टि",
      "निवेश मार्गदर्शन और पेशेवर उद्यम विश्लेषण"
    ],
    icon: "BriefcaseIcon",
    isPopular: false,
    category: "Specialized",
    categoryHindi: "विशेष"
  },
  {
    id: 4,
    title: "Relationships & Compatibility",
    titleHindi: "रिश्ते और अनुकूलता",
    description: "Detailed predictions regarding marital life, nature of spouse, potential for harmony or conflict, timing of marriage, compatibility assessment using Guna Milan system, and insights into matters concerning children and parenting.",
    descriptionHindi: "वैवाहिक जीवन, जीवनसाथी की प्रकृति, सामंजस्य या संघर्ष की संभावना, विवाह का समय, गुण मिलान प्रणाली का उपयोग करके अनुकूलता मूल्यांकन, और बच्चों और पालन-पोषण से संबंधित मामलों की अंतर्दृष्टि के बारे में विस्तृत भविष्यवाणियां।",
    duration: "1 hour per live consultation",
    durationHindi: "प्रति लाइव परामर्श 1 घंटा",
    price: "₹999 for any two niches",
    features: [
      "Marriage & Spouse: Predictions regarding marital life and nature of spouse",
      "Potential for harmony or conflict in relationships",
      "Timing of marriage and favorable periods",
      "Compatibility Analysis: Assessment using Guna Milan system",
      "Quality of relationships with family and friends",
      "Children: Insights into matters concerning children and parenting style",
      "Potential issues related to progeny using Saptamsa divisional chart"
    ],
    featuresHindi: [
      "विवाह और जीवनसाथी: वैवाहिक जीवन और जीवनसाथी की प्रकृति के बारे में भविष्यवाणियां",
      "रिश्तों में सामंजस्य या संघर्ष की संभावना",
      "विवाह का समय और अनुकूल अवधियां",
      "अनुकूलता विश्लेषण: गुण मिलान प्रणाली का उपयोग करके मूल्यांकन",
      "परिवार और दोस्तों के साथ रिश्तों की गुणवत्ता",
      "बच्चे: बच्चों और पालन-पोषण शैली से संबंधित मामलों की अंतर्दृष्टि",
      "सप्तमांश विभागीय चार्ट का उपयोग करके संतान से संबंधित संभावित मुद्दे"
    ],
    icon: "HeartIcon",
    isPopular: false,
    category: "Specialized",
    categoryHindi: "विशेष"
  },
  {
    id: 5,
    title: "Personality & Self-Understanding",
    titleHindi: "व्यक्तित्व और आत्म-समझ",
    description: "Deep insights into fundamental nature, strengths, weaknesses, behavior, physical appearance, emotional makeup, mental peace, subconscious patterns, and revelation of hidden talents and creative abilities.",
    descriptionHindi: "मौलिक प्रकृति, शक्तियों, कमजोरियों, व्यवहार, शारीरिक उपस्थिति, भावनात्मक संरचना, मानसिक शांति, अवचेतन पैटर्न और छिपी प्रतिभाओं और रचनात्मक क्षमताओं के प्रकटीकरण में गहरी अंतर्दृष्टि।",
    duration: "1 hour per live consultation",
    durationHindi: "प्रति लाइव परामर्श 1 घंटा",
    price: "₹999 for any two niches",
    features: [
      "Core Traits: Insights into fundamental nature and strengths",
      "Weaknesses, behavior patterns, and physical appearance",
      "Personality characteristics and temperament",
      "Emotional Makeup: Understanding emotional responses and mental peace",
      "Subconscious patterns derived from Moon Kundali",
      "Inner Potential: Revelation of hidden talents and creative abilities",
      "Intelligence, intellectual pursuits, and self-development guidance"
    ],
    featuresHindi: [
      "मुख्य लक्षण: मौलिक प्रकृति और शक्तियों की अंतर्दृष्टि",
      "कमजोरियां, व्यवहार पैटर्न और शारीरिक उपस्थिति",
      "व्यक्तित्व विशेषताएं और स्वभाव",
      "भावनात्मक संरचना: भावनात्मक प्रतिक्रियाओं और मानसिक शांति को समझना",
      "चंद्र कुंडली से प्राप्त अवचेतन पैटर्न",
      "आंतरिक क्षमता: छिपी प्रतिभाओं और रचनात्मक क्षमताओं का प्रकटीकरण",
      "बुद्धि, बौद्धिक गतिविधियां और आत्म-विकास मार्गदर्शन"
    ],
    icon: "UserIcon",
    isPopular: false,
    category: "Specialized",
    categoryHindi: "विशेष"
  }
];


  const preparationSteps: PreparationStep[] = [
  {
    title: "Birth Details",
    titleHindi: "जन्म विवरण",
    description: "Have your exact birth date, time, and place ready. Accurate birth time is crucial for precise predictions.",
    descriptionHindi: "अपनी सटीक जन्म तिथि, समय और स्थान तैयार रखें। सटीक भविष्यवाणियों के लिए सटीक जन्म समय महत्वपूर्ण है।",
    icon: "ClockIcon"
  },
  {
    title: "Specific Questions",
    titleHindi: "विशिष्ट प्रश्न",
    description: "Prepare a list of specific questions or areas you want guidance on to make the most of your consultation time.",
    descriptionHindi: "अपने परामर्श समय का अधिकतम लाभ उठाने के लिए विशिष्ट प्रश्नों या क्षेत्रों की सूची तैयार करें जिन पर आप मार्गदर्शन चाहते हैं।",
    icon: "DocumentTextIcon"
  },
  {
    title: "Quiet Environment",
    titleHindi: "शांत वातावरण",
    description: "Choose a quiet, private space for the consultation where you can focus without interruptions.",
    descriptionHindi: "परामर्श के लिए एक शांत, निजी स्थान चुनें जहां आप बिना किसी रुकावट के ध्यान केंद्रित कर सकें।",
    icon: "HomeIcon"
  },
  {
    title: "Note-Taking Materials",
    titleHindi: "नोट लेने की सामग्री",
    description: "Keep a notebook or device ready to take notes during the consultation for future reference.",
    descriptionHindi: "भविष्य के संदर्भ के लिए परामर्श के दौरान नोट्स लेने के लिए एक नोटबुक या डिवाइस तैयार रखें।",
    icon: "PencilIcon"
  }];


  const comparisonFeatures: ComparisonFeature[] = [
  {
    feature: "Birth Chart Analysis",
    featureHindi: "जन्म कुंडली विश्लेषण",
    basic: true,
    detailed: true,
    premium: true
  },
  {
    feature: "Career Guidance",
    featureHindi: "करियर मार्गदर्शन",
    basic: true,
    detailed: true,
    premium: true
  },
  {
    feature: "Relationship Insights",
    featureHindi: "रिश्ते की जानकारी",
    basic: true,
    detailed: true,
    premium: true
  },
  {
    feature: "Detailed Predictions",
    featureHindi: "विस्तृत भविष्यवाणियां",
    basic: false,
    detailed: true,
    premium: true
  },
  {
    feature: "Personalized Remedies",
    featureHindi: "व्यक्तिगत उपाय",
    basic: false,
    detailed: true,
    premium: true
  },
  {
    feature: "Written Report",
    featureHindi: "लिखित रिपोर्ट",
    basic: false,
    detailed: false,
    premium: true
  },
  {
    feature: "Follow-up Support",
    featureHindi: "अनुवर्ती समर्थन",
    basic: false,
    detailed: false,
    premium: true
  },
  {
    feature: "Priority Access",
    featureHindi: "प्राथमिकता पहुंच",
    basic: false,
    detailed: false,
    premium: true
  },
  {
    feature: "Gemstone Recommendations",
    featureHindi: "रत्न सिफारिशें",
    basic: false,
    detailed: false,
    premium: true
  },
  {
    feature: "Annual Forecast",
    featureHindi: "वार्षिक पूर्वानुमान",
    basic: false,
    detailed: false,
    premium: true
  }];


  const serviceFAQs: FAQItem[] = [
  {
    question: "How do I book a consultation?",
    questionHindi: "मैं परामर्श कैसे बुक करूं?",
    answer: "Click the 'Book Now' button on any service card to connect via WhatsApp. Share your birth details and preferred consultation time, and I will confirm your appointment.",
    answerHindi: "व्हाट्सएप के माध्यम से जुड़ने के लिए किसी भी सेवा कार्ड पर 'अभी बुक करें' बटन पर क्लिक करें। अपने जन्म विवरण और पसंदीदा परामर्श समय साझा करें, और मैं आपकी नियुक्ति की पुष्टि करूंगी।"
  },
  {
    question: "What if I don't know my exact birth time?",
    questionHindi: "यदि मुझे अपना सटीक जन्म समय नहीं पता है तो क्या होगा?",
    answer: "Birth time is important for accurate predictions. If you don't have the exact time, we can't work with an approximate time. I can guide you on how to obtain your birth certificate for accurate details.",
    answerHindi: "सटीक भविष्यवाणी के लिए जन्म का समय महत्वपूर्ण है। यदि आपके पास सटीक समय नहीं है, तो हम अनुमानित समय नहीं बता सकते। सटीक जानकारी के लिए जन्म प्रमाण पत्र प्राप्त करने में मैं आपकी मदद कर सकता हूँ।।"
  },
  {
    question: "How long does a consultation take?",
    questionHindi: "परामर्श में कितना समय लगता है?",
    answer: "Consultation usually takes up to one hour but it can be extended by a while(10 to 15 min) if there are any more very important questions from the client side.",
    answerHindi: "परामर्श में आमतौर पर एक घंटे तक का समय लगता है, लेकिन यदि ग्राहक की ओर से कोई और महत्वपूर्ण प्रश्न हों तो इसे कुछ समय (10 से 15 मिनट) तक बढ़ाया जा सकता है।"
  },
  {
    question: "Can I get a consultation in Hindi?",
    questionHindi: "क्या मुझे हिंदी में परामर्श मिल सकता है?",
    answer: "Yes, absolutely! I conduct consultations in both Hindi and English. Please specify your preferred language when booking, and I will ensure comfortable communication throughout the session.",
    answerHindi: "हां, बिल्कुल! मैं हिंदी और अंग्रेजी दोनों में परामर्श करती हूं। कृपया बुकिंग करते समय अपनी पसंदीदा भाषा निर्दिष्ट करें, और मैं पूरे सत्र में आरामदायक संचार सुनिश्चित करूंगी।"
  },
  {
    question: "What payment methods do you accept?",
    questionHindi: "आप कौन से भुगतान तरीके स्वीकार करते हैं?",
    answer: "I accept payments via UPI, bank transfer, and digital wallets. Payment details will be shared after booking confirmation. Full payment is required before the consultation.",
    answerHindi: "मैं यूपीआई, बैंक ट्रांसफर और डिजिटल वॉलेट के माध्यम से भुगतान स्वीकार करती हूं। बुकिंग पुष्टि के बाद भुगतान विवरण साझा किया जाएगा। परामर्श से पहले पूर्ण भुगतान आवश्यक है।"
  },
  {
    question: "Do you provide written reports?",
    questionHindi: "क्या आप लिखित रिपोर्ट प्रदान करते हैं?",
    answer: "Written reports are included only in the Premium Package. For other services, you can take notes during the consultation or request a recording (additional charges may apply).",
    answerHindi: "लिखित रिपोर्ट केवल प्रीमियम पैकेज में शामिल हैं। अन्य सेवाओं के लिए, आप परामर्श के दौरान नोट्स ले सकते हैं या रिकॉर्डिंग का अनुरोध कर सकते हैं (अतिरिक्त शुल्क लागू हो सकते हैं)।"
  }];


  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-8">
            <div className="h-12 bg-muted rounded w-3/4 mx-auto"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) =>
              <div key={i} className="h-96 bg-muted rounded-xl"></div>
              )}
            </div>
          </div>
        </div>
      </div>);

  }

  return (
    <div className="min-h-screen bg-background">
      <div className="fixed top-20 right-4 z-40">
        <button
          onClick={handleLanguageToggle}
          className="px-4 py-2 bg-primary text-primary-foreground font-cta font-semibold rounded-lg shadow-elevated hover:bg-opacity-90 transition-all duration-300">

          {currentLanguage === 'english' ? 'हिंदी' : 'English'}
        </button>
      </div>

      <section className="bg-gradient-to-br from-primary to-secondary text-primary-foreground py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="font-headline text-4xl lg:text-5xl xl:text-6xl font-bold mb-6">
              {currentLanguage === 'hindi' ? 'हमारी सेवाएं' : 'Our Services'}
            </h1>
            <p className="font-body text-lg lg:text-xl text-primary-foreground opacity-90 leading-relaxed">
              {currentLanguage === 'hindi' ? 'वैदिक ज्योतिष के माध्यम से व्यक्तिगत मार्गदर्शन। पारदर्शी मूल्य निर्धारण, स्पष्ट प्रक्रिया और प्रामाणिक अंतर्दृष्टि के साथ अपने जीवन पथ को समझें।' : 'Personalized guidance through Vedic astrology. Understand your life path with transparent pricing, clear processes, and authentic insights.'}
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {services.map((service) =>
            <ServiceCard
              key={service.id}
              title={service.title}
              titleHindi={service.titleHindi}
              description={service.description}
              descriptionHindi={service.descriptionHindi}
              duration={service.duration}
              durationHindi={service.durationHindi}
              price={service.price}
              features={service.features}
              featuresHindi={service.featuresHindi}
              icon={service.icon}
              isPopular={service.isPopular}
              currentLanguage={currentLanguage} />

            )}
          </div>
        </div>
      </section>

      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <p className="font-body text-sm lg:text-base text-accent italic">
                {nakshatraTaglines[currentLanguage]}
              </p>
            </div>
            <PreparationGuide steps={preparationSteps} currentLanguage={currentLanguage} />
          </div>
        </div>
      </section>

      <section className="py-12 lg:py-16 bg-muted bg-opacity-30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <ServiceFAQ faqs={serviceFAQs} currentLanguage={currentLanguage} />
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-24 bg-gradient-to-br from-primary to-secondary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-headline text-3xl lg:text-4xl font-bold mb-6">
              {currentLanguage === 'hindi' ? 'अपना परामर्श बुक करें' : 'Book Your Consultation'}
            </h2>
            <p className="font-body text-lg mb-8 opacity-90">
              {currentLanguage === 'hindi' ? 'अपनी जीवन यात्रा में स्पष्टता और मार्गदर्शन की दिशा में पहला कदम उठाएं। मैं यहां आपकी मदद के लिए हूं।' : 'Take the first step towards clarity and guidance in your life journey. I am here to help you.'}
            </p>
            <motion.a
              href="https://wa.me/919079964007"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-3 px-8 py-4 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 shadow-elevated hover:shadow-soft"
              whileHover={{ scale: 1.05, y: -3 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >

              <span className="text-lg">
                {currentLanguage === 'hindi' ? 'व्हाट्सएप पर संपर्क करें' : 'Connect on WhatsApp'}
              </span>
            </motion.a>
          </div>
        </div>
      </section>
    </div>);

};

export default ServicesInteractive;
