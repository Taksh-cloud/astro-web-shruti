import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface PreparationStep {
  title: string;
  titleHindi: string;
  description: string;
  descriptionHindi: string;
  icon: string;
}

interface PreparationGuideProps {
  steps: PreparationStep[];
  currentLanguage: string;
}

const PreparationGuide = ({ steps, currentLanguage }: PreparationGuideProps) => {
  return (
    <div className="bg-muted rounded-xl p-6 lg:p-8">
      <div className="flex items-center space-x-3 mb-6">
        <Icon name="LightBulbIcon" size={28} className="text-accent" />
        <h3 className="font-headline text-2xl lg:text-3xl font-semibold text-text-primary">
          {currentLanguage === 'hindi' ? 'परामर्श की तैयारी' : 'Consultation Preparation'}
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {steps.map((step, index) => (
          <div key={index} className="bg-card rounded-lg p-6 shadow-soft">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon name={step.icon as any} size={20} className="text-primary" />
              </div>
              <div className="flex-1">
                <h4 className="font-cta font-semibold text-text-primary mb-2">
                  {currentLanguage === 'hindi' ? step.titleHindi : step.title}
                </h4>
                <p className="font-body text-sm text-text-secondary leading-relaxed">
                  {currentLanguage === 'hindi' ? step.descriptionHindi : step.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PreparationGuide;