'use client';

import React, { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface FAQItem {
  question: string;
  questionHindi: string;
  answer: string;
  answerHindi: string;
}

interface ServiceFAQProps {
  faqs: FAQItem[];
  currentLanguage: string;
}

const ServiceFAQ = ({ faqs, currentLanguage }: ServiceFAQProps) => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="bg-card rounded-xl shadow-soft p-6 lg:p-8">
      <div className="flex items-center space-x-3 mb-6">
        <Icon name="QuestionMarkCircleIcon" size={28} className="text-accent" />
        <h3 className="font-headline text-2xl lg:text-3xl font-semibold text-text-primary">
          {currentLanguage === 'hindi' ? 'सेवा संबंधी प्रश्न' : 'Service FAQs'}
        </h3>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <div key={index} className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => toggleFAQ(index)}
              className="w-full px-6 py-4 flex items-center justify-between bg-muted hover:bg-opacity-70 transition-colors duration-300"
            >
              <span className="font-cta font-semibold text-text-primary text-left">
                {currentLanguage === 'hindi' ? faq.questionHindi : faq.question}
              </span>
              <Icon
                name="ChevronDownIcon"
                size={20}
                className={`text-primary transition-transform duration-300 flex-shrink-0 ml-4 ${
                  openIndex === index ? 'rotate-180' : ''
                }`}
              />
            </button>
            {openIndex === index && (
              <div className="px-6 py-4 bg-card">
                <p className="font-body text-text-secondary leading-relaxed">
                  {currentLanguage === 'hindi' ? faq.answerHindi : faq.answer}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServiceFAQ;