'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import { motion } from 'framer-motion';

interface ServiceCardProps {
  title: string;
  titleHindi: string;
  description: string;
  descriptionHindi: string;
  duration?: string;
  durationHindi?: string;
  price?: string;
  features: string[];
  featuresHindi: string[];
  icon: string;
  isPopular?: boolean;
  currentLanguage: string;
}

const ServiceCard = ({
  title,
  titleHindi,
  description,
  descriptionHindi,
  duration,
  durationHindi,
  price,
  features,
  featuresHindi,
  icon,
  isPopular = false,
  currentLanguage
}: ServiceCardProps) => {
  const displayTitle = currentLanguage === 'hindi' ? titleHindi : title;
  const displayDescription = currentLanguage === 'hindi' ? descriptionHindi : description;
  const displayDuration = currentLanguage === 'hindi' ? durationHindi : duration;
  const displayFeatures = currentLanguage === 'hindi' ? featuresHindi : features;

  return (
    <div className={`relative bg-card rounded-xl shadow-soft hover:shadow-elevated transition-all duration-300 overflow-hidden ${isPopular ? 'border-2 border-primary' : 'border border-border'}`}>
      {isPopular &&
      <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-4 py-1 text-sm font-cta font-semibold rounded-bl-lg">
          {currentLanguage === 'hindi' ? 'सबसे लोकप्रिय' : 'Most Popular'}
        </div>
      }
      
      <div className="p-6 lg:p-8">
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
            <Icon name={icon as any} size={24} className="text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary">
              {displayTitle}
            </h3>
          </div>
        </div>

        <p className="font-body text-text-secondary mb-4 leading-relaxed">
          {displayDescription}
        </p>

        {(duration || price) && (
          <div className="mb-4 p-4 bg-muted rounded-lg space-y-2">
            {price && (
              <div className="flex items-center space-x-2">
                <Icon name="CurrencyRupeeIcon" size={20} className="text-primary flex-shrink-0" />
                <span className="font-cta text-lg font-semibold text-primary">{price}</span>
              </div>
            )}
            {displayDuration && (
              <div className="flex items-center space-x-2">
                <Icon name="ClockIcon" size={20} className="text-text-secondary flex-shrink-0" />
                <span className="font-body text-sm text-text-secondary">{displayDuration}</span>
              </div>
            )}
          </div>
        )}

        <div className={`space-y-3 ${duration || price ? 'mb-6' : 'mb-6 pb-6'}`}>
          {displayFeatures.map((feature, index) =>
          <div key={index} className="flex items-start space-x-3">
              <Icon name="CheckCircleIcon" size={20} className="text-success flex-shrink-0 mt-0.5" />
              <span className="font-body text-text-primary text-sm leading-relaxed">
                {feature}
              </span>
            </div>
          )}
        </div>

        {/* Book Now Button */}
        <motion.a
          href="https://wa.me/919079964007"
          target="_blank"
          rel="noopener noreferrer"
          className="block w-full px-6 py-3 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 text-center shadow-soft hover:shadow-elevated"
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          transition={{ type: "spring", stiffness: 400, damping: 17 }}
        >

          <div className="flex items-center justify-center space-x-2">
            <Icon name="ChatBubbleLeftRightIcon" size={20} />
            <span>{currentLanguage === 'hindi' ? 'अभी बुक करें' : 'Book Now'}</span>
          </div>
        </motion.a>
      </div>
    </div>);

};

export default ServiceCard;