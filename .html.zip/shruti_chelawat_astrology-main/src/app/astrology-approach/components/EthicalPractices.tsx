import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface EthicalPracticesProps {
  currentLanguage: string;
}

const EthicalPractices = ({ currentLanguage }: EthicalPracticesProps) => {
  const content = {
    en: {
      title: "Ethical Practices & Confidentiality",
      subtitle: "My Commitment to You",
      practices: [
        {
          icon: "LockClosedIcon",
          title: "Complete Confidentiality",
          description: "Your birth details, personal information, and consultation discussions remain strictly confidential. I never share client information with anyone."
        },
        {
          icon: "HeartIcon",
          title: "No Fear-Based Predictions",
          description: "I don't use fear tactics or create anxiety about planetary positions. Astrology is a tool for empowerment, not intimidation."
        },
        {
          icon: "CurrencyRupeeIcon",
          title: "Transparent Pricing",
          description: "All consultation fees are clearly stated upfront. No hidden charges, no pressure for expensive remedies or repeated sessions."
        },
        {
          icon: "HandRaisedIcon",
          title: "Honest Limitations",
          description: "I acknowledge what astrology can and cannot predict. I don't claim to solve all problems or guarantee specific outcomes."
        },
        {
          icon: "UserGroupIcon",
          title: "Respectful Guidance",
          description: "I honor your free will and decision-making capacity. My role is to provide insights, not dictate life choices."
        },
        {
          icon: "AcademicCapIcon",
          title: "Continuous Learning",
          description: "I stay updated with traditional texts and modern astrological research to provide the most accurate and relevant guidance."
        }
      ]
    },
    hi: {
      title: "नैतिक प्रथाएं और गोपनीयता",
      subtitle: "आपके प्रति मेरी प्रतिबद्धता",
      practices: [
        {
          icon: "LockClosedIcon",
          title: "पूर्ण गोपनीयता",
          description: "आपके जन्म विवरण, व्यक्तिगत जानकारी और परामर्श चर्चाएं पूरी तरह से गोपनीय रहती हैं। मैं कभी भी किसी के साथ ग्राहक जानकारी साझा नहीं करती।"
        },
        {
          icon: "HeartIcon",
          title: "कोई भय-आधारित भविष्यवाणियां नहीं",
          description: "मैं भय रणनीति का उपयोग नहीं करती या ग्रह स्थितियों के बारे में चिंता नहीं बनाती। ज्योतिष सशक्तिकरण का एक उपकरण है, धमकी का नहीं।"
        },
        {
          icon: "CurrencyRupeeIcon",
          title: "पारदर्शी मूल्य निर्धारण",
          description: "सभी परामर्श शुल्क स्पष्ट रूप से पहले से बताए गए हैं। कोई छिपे हुए शुल्क नहीं, महंगे उपायों या बार-बार सत्रों के लिए कोई दबाव नहीं।"
        },
        {
          icon: "HandRaisedIcon",
          title: "ईमानदार सीमाएं",
          description: "मैं स्वीकार करती हूं कि ज्योतिष क्या भविष्यवाणी कर सकता है और क्या नहीं। मैं सभी समस्याओं को हल करने या विशिष्ट परिणामों की गारंटी देने का दावा नहीं करती।"
        },
        {
          icon: "UserGroupIcon",
          title: "सम्मानजनक मार्गदर्शन",
          description: "मैं आपकी स्वतंत्र इच्छा और निर्णय लेने की क्षमता का सम्मान करती हूं। मेरी भूमिका अंतर्दृष्टि प्रदान करना है, जीवन विकल्पों को निर्देशित करना नहीं।"
        },
        {
          icon: "AcademicCapIcon",
          title: "निरंतर सीखना",
          description: "मैं सबसे सटीक और प्रासंगिक मार्गदर्शन प्रदान करने के लिए पारंपरिक ग्रंथों और आधुनिक ज्योतिषीय अनुसंधान के साथ अद्यतन रहती हूं।"
        }
      ]
    }
  };

  const lang = currentLanguage === 'hi' ? 'hi' : 'en';

  return (
    <section className="py-16 lg:py-24 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-primary mb-4">
              {content[lang].title}
            </h2>
            <p className="font-body text-lg lg:text-xl text-text-secondary">
              {content[lang].subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {content[lang].practices.map((practice, index) => (
              <div
                key={index}
                className="bg-card p-6 rounded-lg shadow-soft hover:shadow-elevated transition-shadow duration-300"
              >
                <div className="w-14 h-14 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                  <Icon name={practice.icon as any} size={28} className="text-primary" />
                </div>
                <h3 className="font-headline text-xl font-semibold text-text-primary mb-3">
                  {practice.title}
                </h3>
                <p className="font-body text-base text-text-secondary leading-relaxed">
                  {practice.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EthicalPractices;