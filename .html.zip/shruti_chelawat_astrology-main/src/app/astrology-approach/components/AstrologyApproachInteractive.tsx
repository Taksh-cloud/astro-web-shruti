'use client';

import React, { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';
import ApproachHero from './ApproachHero';
import VedicFoundations from './VedicFoundations';
import MyMethodology from './MyMethodology';
import ConsultationProcess from './ConsultationProcess';
import EthicalPractices from './EthicalPractices';
import WhyChooseMe from './WhyChooseMe';
import Footer from './Footer';

const AstrologyApproachInteractive = () => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [showWhatsAppButton, setShowWhatsAppButton] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
    const savedLanguage = localStorage.getItem('preferredLanguage');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }

    const handleScroll = () => {
      setShowWhatsAppButton(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLanguageToggle = () => {
    if (!isHydrated) return;
    const newLanguage = currentLanguage === 'en' ? 'hi' : 'en';
    setCurrentLanguage(newLanguage);
    localStorage.setItem('preferredLanguage', newLanguage);
  };

  return (
    <>
      <div className="fixed top-20 right-4 z-40">
        <button
          onClick={handleLanguageToggle}
          className="bg-card shadow-elevated rounded-lg px-4 py-2 flex items-center space-x-2 hover:bg-muted transition-colors duration-300"
          aria-label="Toggle language"
        >
          <Icon name="LanguageIcon" size={20} className="text-primary" />
          <span className="font-body font-medium text-text-primary">
            {isHydrated ? (currentLanguage === 'en' ? 'हिंदी' : 'English') : 'हिंदी'}
          </span>
        </button>
      </div>

      {isHydrated && showWhatsAppButton && (
        <a
          href="https://wa.me/919079964007"
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-whatsapp text-whatsapp-foreground rounded-full flex items-center justify-center shadow-elevated hover:scale-110 transition-transform duration-300"
          aria-label="Contact via WhatsApp"
        >
          <Icon name="ChatBubbleLeftRightIcon" size={28} />
        </a>
      )}

      <ApproachHero currentLanguage={currentLanguage} />
      <VedicFoundations currentLanguage={currentLanguage} />
      <MyMethodology currentLanguage={currentLanguage} />
      <ConsultationProcess currentLanguage={currentLanguage} />
      <EthicalPractices currentLanguage={currentLanguage} />
      <WhyChooseMe currentLanguage={currentLanguage} />
      <Footer currentLanguage={currentLanguage} />
    </>
  );
};

export default AstrologyApproachInteractive;