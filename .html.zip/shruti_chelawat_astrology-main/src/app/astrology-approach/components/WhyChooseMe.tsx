'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import { motion } from 'framer-motion';

interface WhyChooseMeProps {
  currentLanguage: string;
}

const WhyChooseMe = ({ currentLanguage }: WhyChooseMeProps) => {
  const content = {
    en: {
      title: "Why Choose My Approach",
      differentiators: [
        {
          icon: "CheckBadgeIcon",
          title: "Authentic Vedic Knowledge",
          description: "Trained in traditional Vedic astrology with deep understanding of classical texts and principles."
        },
        {
          icon: "ChatBubbleBottomCenterTextIcon",
          title: "Modern Communication",
          description: "Complex astrological concepts explained in simple, relatable language for today's world."
        },
        {
          icon: "ShieldCheckIcon",
          title: "No Exploitation",
          description: "Ethical practice with transparent pricing and no pressure for expensive remedies or rituals."
        },
        {
          icon: "SparklesIcon",
          title: "Empowerment Focus",
          description: "Guidance aimed at helping you make informed decisions, not creating dependency."
        }
      ],
      cta: {
        title: "Ready to Gain Clarity?",
        description: "Book your consultation today and discover what the stars reveal about your life's journey.",
        button: "Book Consultation"
      }
    },
    hi: {
      title: "मेरा दृष्टिकोण क्यों चुनें",
      differentiators: [
        {
          icon: "CheckBadgeIcon",
          title: "प्रामाणिक वैदिक ज्ञान",
          description: "शास्त्रीय ग्रंथों और सिद्धांतों की गहरी समझ के साथ पारंपरिक वैदिक ज्योतिष में प्रशिक्षित।"
        },
        {
          icon: "ChatBubbleBottomCenterTextIcon",
          title: "आधुनिक संचार",
          description: "आज की दुनिया के लिए सरल, संबंधित भाषा में जटिल ज्योतिषीय अवधारणाओं की व्याख्या।"
        },
        {
          icon: "ShieldCheckIcon",
          title: "कोई शोषण नहीं",
          description: "पारदर्शी मूल्य निर्धारण के साथ नैतिक अभ्यास और महंगे उपायों या अनुष्ठानों के लिए कोई दबाव नहीं।"
        },
        {
          icon: "SparklesIcon",
          title: "सशक्तिकरण फोकस",
          description: "मार्गदर्शन का उद्देश्य आपको सूचित निर्णय लेने में मदद करना है, निर्भरता बनाना नहीं।"
        }
      ],
      cta: {
        title: "स्पष्टता प्राप्त करने के लिए तैयार हैं?",
        description: "आज ही अपना परामर्श बुक करें और जानें कि सितारे आपके जीवन की यात्रा के बारे में क्या प्रकट करते हैं।",
        button: "परामर्श बुक करें"
      }
    }
  };

  const lang = currentLanguage === 'hi' ? 'hi' : 'en';

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-primary mb-8">
              {content[lang].title}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mb-12 lg:mb-16">
            {content[lang].differentiators.map((item, index) => (
              <div
                key={index}
                className="flex items-start space-x-4 bg-card p-6 rounded-lg shadow-soft"
              >
                <div className="flex-shrink-0 w-12 h-12 bg-accent bg-opacity-20 rounded-lg flex items-center justify-center">
                  <Icon name={item.icon as any} size={24} className="text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="font-headline text-xl font-semibold text-text-primary mb-2">
                    {item.title}
                  </h3>
                  <p className="font-body text-base text-text-secondary leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-br from-primary to-secondary p-8 lg:p-12 rounded-2xl shadow-elevated text-center">
            <h3 className="font-headline text-2xl lg:text-3xl font-bold text-primary-foreground mb-4">
              {content[lang].cta.title}
            </h3>
            <p className="font-body text-base lg:text-lg text-primary-foreground opacity-90 mb-8 max-w-2xl mx-auto">
              {content[lang].cta.description}
            </p>
            {/* CTA Button */}
            <div className="text-center">
              <motion.a
                href="https://wa.me/919079964007"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-3 px-8 py-4 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 shadow-soft hover:shadow-elevated"
                whileHover={{ scale: 1.05, y: -3 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                <Icon name="ChatBubbleLeftRightIcon" size={24} />
                <span>{content[lang].cta.button}</span>
              </motion.a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseMe;