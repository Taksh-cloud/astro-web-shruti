'use client';

import React, { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface MyMethodologyProps {
  currentLanguage: string;
}

const MyMethodology = ({ currentLanguage }: MyMethodologyProps) => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const content = {
    en: {
      title: "My Unique Methodology",
      subtitle: "What Makes My Approach Different",
      methods: [
        {
          title: "Holistic Chart Reading",
          summary: "I analyze your complete birth chart, not just sun signs or single planets.",
          details: "My readings consider all nine planets (Navagraha), twelve houses (Bhavas), and their intricate relationships. I examine planetary strengths (Shadbala), aspects (Drishti), and yogas (planetary combinations) to provide comprehensive insights into your life patterns, strengths, and growth areas."
        },
        {
          title: "Compassionate Truth-Telling",
          summary: "I believe in honest guidance without fear-mongering or sugar-coating.",
          details: "While I respect traditional astrological principles, I present insights in a way that empowers rather than frightens. Challenging planetary positions are discussed as growth opportunities, not doom. I focus on actionable guidance and practical remedies that align with modern life while honoring Vedic wisdom."
        },
        {
          title: "Context-Aware Interpretation",
          summary: "Your chart is read within the context of your current life circumstances and goals.",
          details: "I don't provide generic predictions. Before analysis, I understand your specific questions, life stage, and aspirations. This allows me to highlight the most relevant planetary influences and timing for your unique situation, making the guidance practical and immediately applicable."
        },
        {
          title: "Ethical Remedial Measures",
          summary: "I recommend simple, accessible remedies—no expensive rituals or fear-based solutions.",
          details: "My remedial suggestions include practical lifestyle adjustments, gemstone recommendations (when truly beneficial), simple mantras, and charitable activities. I never prescribe costly pujas or create dependency. The focus is on self-empowerment through understanding and conscious action."
        }
      ]
    },
    hi: {
      title: "मेरी अनूठी पद्धति",
      subtitle: "मेरा दृष्टिकोण क्या अलग बनाता है",
      methods: [
        {
          title: "समग्र कुंडली पठन",
          summary: "मैं आपकी पूरी जन्म कुंडली का विश्लेषण करती हूं, न कि केवल सूर्य राशि या एकल ग्रहों का।",
          details: "मेरे पठन में सभी नौ ग्रहों (नवग्रह), बारह भावों और उनके जटिल संबंधों पर विचार किया जाता है। मैं ग्रहों की शक्तियों (षड्बल), दृष्टि और योगों (ग्रह संयोजन) की जांच करती हूं ताकि आपके जीवन पैटर्न, शक्तियों और विकास क्षेत्रों में व्यापक अंतर्दृष्टि प्रदान की जा सके।"
        },
        {
          title: "करुणामय सत्य-कथन",
          summary: "मैं भय-प्रसार या मीठी बातों के बिना ईमानदार मार्गदर्शन में विश्वास करती हूं।",
          details: "जबकि मैं पारंपरिक ज्योतिषीय सिद्धांतों का सम्मान करती हूं, मैं अंतर्दृष्टि को इस तरह प्रस्तुत करती हूं जो डराने के बजाय सशक्त बनाती है। चुनौतीपूर्ण ग्रह स्थितियों को विकास के अवसरों के रूप में चर्चा की जाती है, न कि विनाश के रूप में। मैं कार्रवाई योग्य मार्गदर्शन और व्यावहारिक उपायों पर ध्यान केंद्रित करती हूं जो आधुनिक जीवन के साथ संरेखित होते हैं जबकि वैदिक ज्ञान का सम्मान करते हैं।"
        },
        {
          title: "संदर्भ-जागरूक व्याख्या",
          summary: "आपकी कुंडली आपकी वर्तमान जीवन परिस्थितियों और लक्ष्यों के संदर्भ में पढ़ी जाती है।",
          details: "मैं सामान्य भविष्यवाणियां नहीं देती। विश्लेषण से पहले, मैं आपके विशिष्ट प्रश्नों, जीवन चरण और आकांक्षाओं को समझती हूं। यह मुझे आपकी अनूठी स्थिति के लिए सबसे प्रासंगिक ग्रह प्रभावों और समय को उजागर करने की अनुमति देता है, जिससे मार्गदर्शन व्यावहारिक और तुरंत लागू होता है।"
        },
        {
          title: "नैतिक उपचारात्मक उपाय",
          summary: "मैं सरल, सुलभ उपायों की सिफारिश करती हूं—कोई महंगे अनुष्ठान या भय-आधारित समाधान नहीं।",
          details: "मेरे उपचारात्मक सुझावों में व्यावहारिक जीवनशैली समायोजन, रत्न सिफारिशें (जब वास्तव में लाभकारी हों), सरल मंत्र और धर्मार्थ गतिविधियां शामिल हैं। मैं कभी भी महंगे पूजा निर्धारित नहीं करती या निर्भरता नहीं बनाती। ध्यान समझ और सचेत कार्रवाई के माध्यम से आत्म-सशक्तिकरण पर है।"
        }
      ]
    }
  };

  const lang = currentLanguage === 'hi' ? 'hi' : 'en';

  const handleToggle = (index: number) => {
    if (!isHydrated) return;
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <section className="py-16 lg:py-24 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-primary mb-4">
              {content[lang].title}
            </h2>
            <p className="font-body text-lg lg:text-xl text-text-secondary">
              {content[lang].subtitle}
            </p>
          </div>

          <div className="space-y-4">
            {content[lang].methods.map((method, index) => (
              <div
                key={index}
                className="bg-card rounded-lg shadow-soft overflow-hidden"
              >
                <button
                  onClick={() => handleToggle(index)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-muted transition-colors duration-300"
                  aria-expanded={isHydrated && expandedIndex === index}
                >
                  <div className="flex-1 pr-4">
                    <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-2">
                      {method.title}
                    </h3>
                    <p className="font-body text-base text-text-secondary">
                      {method.summary}
                    </p>
                  </div>
                  <Icon
                    name="ChevronDownIcon"
                    size={24}
                    className={`text-primary flex-shrink-0 transition-transform duration-300 ${
                      isHydrated && expandedIndex === index ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isHydrated && expandedIndex === index && (
                  <div className="px-6 pb-5 pt-2">
                    <p className="font-body text-base text-text-secondary leading-relaxed">
                      {method.details}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MyMethodology;