'use client';

import React, { useState, useEffect } from 'react';


interface ApproachHeroProps {
  currentLanguage: string;
}

const ApproachHero = ({ currentLanguage }: ApproachHeroProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const content = {
    en: {
      title: "My Approach to Vedic Astrology",
      subtitle: "Traditional Wisdom, Modern Clarity",
      description: "Understanding your cosmic blueprint through authentic Vedic principles, delivered with compassion and transparency. No fear, no superstition—just honest guidance for your life's journey."
    },
    hi: {
      title: "वैदिक ज्योतिष के प्रति मेरा दृष्टिकोण",
      subtitle: "पारंपरिक ज्ञान, आधुनिक स्पष्टता",
      description: "प्रामाणिक वैदिक सिद्धांतों के माध्यम से आपके ब्रह्मांडीय खाके को समझना, करुणा और पारदर्शिता के साथ प्रस्तुत किया गया। कोई भय नहीं, कोई अंधविश्वास नहीं—केवल आपके जीवन की यात्रा के लिए ईमानदार मार्गदर्शन।"
    }
  };

  const lang = currentLanguage === 'hi' ? 'hi' : 'en';

  if (!isHydrated) {
    return (
      <section className="relative bg-gradient-to-br from-primary via-primary to-secondary py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-2 h-2 bg-accent rounded-full"></div>
          <div className="absolute top-20 right-20 w-1 h-1 bg-accent rounded-full"></div>
          <div className="absolute bottom-20 left-1/4 w-1.5 h-1.5 bg-accent rounded-full"></div>
          <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-accent rounded-full"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="font-headline text-4xl lg:text-5xl xl:text-6xl font-bold text-primary-foreground mb-6">
              {content[lang].title}
            </h1>
            <p className="font-cta text-xl lg:text-2xl text-accent mb-6">
              {content[lang].subtitle}
            </p>
            <p className="font-body text-base lg:text-lg text-primary-foreground opacity-90 leading-relaxed">
              {content[lang].description}
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative bg-gradient-to-br from-primary via-primary to-secondary py-20 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-2 h-2 bg-accent rounded-full animate-pulse"></div>
        <div className="absolute top-20 right-20 w-1 h-1 bg-accent rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute bottom-20 left-1/4 w-1.5 h-1.5 bg-accent rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-accent rounded-full animate-pulse" style={{ animationDelay: '1.5s' }}></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="font-headline text-4xl lg:text-5xl xl:text-6xl font-bold text-primary-foreground mb-6">
            {content[lang].title}
          </h1>
          <p className="font-cta text-xl lg:text-2xl text-accent mb-6">
            {content[lang].subtitle}
          </p>
          <p className="font-body text-base lg:text-lg text-primary-foreground opacity-90 leading-relaxed">
            {content[lang].description}
          </p>
        </div>
      </div>
    </section>
  );
};

export default ApproachHero;