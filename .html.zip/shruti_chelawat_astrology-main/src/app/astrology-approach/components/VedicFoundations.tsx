import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface VedicFoundationsProps {
  currentLanguage: string;
}

const VedicFoundations = ({ currentLanguage }: VedicFoundationsProps) => {
  const content = {
    en: {
      title: "Vedic Astrology Fundamentals",
      subtitle: "Ancient Wisdom for Modern Life",
      principles: [
        {
          icon: "SparklesIcon",
          title: "Birth Chart Analysis",
          description: "Your Janam Kundali is a cosmic snapshot of planetary positions at your birth moment, revealing your inherent strengths, challenges, and life patterns."
        },
        {
          icon: "ClockIcon",
          title: "Dasha System",
          description: "Understanding planetary periods (Mahadasha and Antardasha) that influence different phases of your life, helping you navigate timing and opportunities."
        },
        {
          icon: "StarIcon",
          title: "Nakshatras",
          description: "The 27 lunar mansions provide deeper insights into your personality, emotional patterns, and karmic influences beyond sun signs."
        },
        {
          icon: "ArrowPathIcon",
          title: "Transits & Progressions",
          description: "Current planetary movements and their impact on your natal chart, offering guidance for present circumstances and future planning."
        }
      ]
    },
    hi: {
      title: "वैदिक ज्योतिष के मूल सिद्धांत",
      subtitle: "आधुनिक जीवन के लिए प्राचीन ज्ञान",
      principles: [
        {
          icon: "SparklesIcon",
          title: "जन्म कुंडली विश्लेषण",
          description: "आपकी जन्म कुंडली आपके जन्म के समय ग्रहों की स्थिति का एक ब्रह्मांडीय चित्र है, जो आपकी अंतर्निहित शक्तियों, चुनौतियों और जीवन पैटर्न को प्रकट करती है।"
        },
        {
          icon: "ClockIcon",
          title: "दशा प्रणाली",
          description: "ग्रहों की अवधि (महादशा और अंतर्दशा) को समझना जो आपके जीवन के विभिन्न चरणों को प्रभावित करती हैं, समय और अवसरों को नेविगेट करने में मदद करती हैं।"
        },
        {
          icon: "StarIcon",
          title: "नक्षत्र",
          description: "27 चंद्र मंजिलें सूर्य राशियों से परे आपके व्यक्तित्व, भावनात्मक पैटर्न और कर्म प्रभावों में गहरी अंतर्दृष्टि प्रदान करती हैं।"
        },
        {
          icon: "ArrowPathIcon",
          title: "गोचर और प्रगति",
          description: "वर्तमान ग्रहों की गति और आपकी जन्म कुंडली पर उनका प्रभाव, वर्तमान परिस्थितियों और भविष्य की योजना के लिए मार्गदर्शन प्रदान करता है।"
        }
      ]
    }
  };

  const lang = currentLanguage === 'hi' ? 'hi' : 'en';

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-primary mb-4">
              {content[lang].title}
            </h2>
            <p className="font-body text-lg lg:text-xl text-text-secondary">
              {content[lang].subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
            {content[lang].principles.map((principle, index) => (
              <div
                key={index}
                className="bg-card p-6 lg:p-8 rounded-lg shadow-soft hover:shadow-elevated transition-shadow duration-300"
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Icon name={principle.icon as any} size={24} className="text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-3">
                      {principle.title}
                    </h3>
                    <p className="font-body text-base text-text-secondary leading-relaxed">
                      {principle.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default VedicFoundations;