'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

interface FooterProps {
  currentLanguage: string;
}

const Footer = ({ currentLanguage }: FooterProps) => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [currentYear, setCurrentYear] = useState('2026');

  useEffect(() => {
    setIsHydrated(true);
    setCurrentYear(new Date().getFullYear().toString());
  }, []);

  const content = {
    en: {
      tagline: "Clarity Through Cosmic Wisdom",
      quickLinks: "Quick Links",
      contact: "Contact",
      phone: "Phone",
      email: "Email",
      whatsapp: "WhatsApp",
      copyright: `© ${currentYear} Shruti Chelawat Astrology. All rights reserved.`,
      privacy: "Your privacy and confidentiality are my top priorities."
    },
    hi: {
      tagline: "ब्रह्मांडीय ज्ञान के माध्यम से स्पष्टता",
      quickLinks: "त्वरित लिंक",
      contact: "संपर्क",
      phone: "फोन",
      email: "ईमेल",
      whatsapp: "व्हाट्सएप",
      copyright: `© ${currentYear} श्रुति चेलावत ज्योतिष। सर्वाधिकार सुरक्षित।`,
      privacy: "आपकी गोपनीयता और गोपनीयता मेरी शीर्ष प्राथमिकताएं हैं।"
    }
  };

  const links = [
    { label: currentLanguage === 'hi' ? 'होम' : 'Home', href: '/homepage' },
    { label: currentLanguage === 'hi' ? 'के बारे में' : 'About', href: '/about' },
    { label: currentLanguage === 'hi' ? 'सेवाएं' : 'Services', href: '/services' },
    { label: currentLanguage === 'hi' ? 'दृष्टिकोण' : 'Approach', href: '/astrology-approach' },
    { label: currentLanguage === 'hi' ? 'संपर्क' : 'Contact', href: '/contact' },
    { label: currentLanguage === 'hi' ? 'FAQ' : 'FAQ', href: '/faq' },
  ];

  const lang = currentLanguage === 'hi' ? 'hi' : 'en';

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-8">
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="relative w-10 h-10">
                <svg
                  viewBox="0 0 48 48"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-full h-full"
                >
                  <circle cx="24" cy="24" r="22" fill="white" opacity="0.1" />
                  <path
                    d="M24 8C15.163 8 8 15.163 8 24s7.163 16 16 16 16-7.163 16-16S32.837 8 24 8zm0 28c-6.627 0-12-5.373-12-12S17.373 12 24 12s12 5.373 12 12-5.373 12-12 12z"
                    fill="white"
                  />
                  <circle cx="24" cy="24" r="4" fill="var(--color-accent)" />
                  <path
                    d="M24 16v-4M24 36v-4M32 24h4M12 24h-4M30.828 17.172l2.829-2.829M14.343 32.657l2.829-2.829M30.828 30.828l2.829 2.829M14.343 15.343l2.829 2.829"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
              <div>
                <h3 className="font-headline text-xl font-bold">Shruti Chelawat</h3>
                <p className="font-body text-sm opacity-80">{currentLanguage === 'hi' ? 'ज्योतिष' : 'Astrology'}</p>
              </div>
            </div>
            <p className="font-body text-base opacity-90 mb-4">
              {content[lang].tagline}
            </p>
            <p className="font-body text-sm opacity-75">
              {content[lang].privacy}
            </p>
          </div>

          <div>
            <h4 className="font-headline text-lg font-semibold mb-4">{content[lang].quickLinks}</h4>
            <ul className="space-y-2">
              {links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="font-body text-base opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300 inline-block"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-headline text-lg font-semibold mb-4">{content[lang].contact}</h4>
            <ul className="space-y-3">
              <li className="flex items-center space-x-3">
                <Icon name="PhoneIcon" size={20} className="opacity-80" />
                <a
                  href="tel:+919079964007"
                  className="font-body text-base opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300"
                >
                  +91 90799 64007
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Icon name="EnvelopeIcon" size={20} className="opacity-80" />
                <a
                  href="mailto:shruti@astrology.com"
                  className="font-body text-base opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300"
                >
                  shruti@astrology.com
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Icon name="ChatBubbleLeftRightIcon" size={20} className="opacity-80" />
                <a
                  href="https://wa.me/919079964007"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-body text-base opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300"
                >
                  {content[lang].whatsapp}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground border-opacity-20 pt-8">
          <p className="font-body text-sm text-center opacity-75">
            {isHydrated ? content[lang].copyright : `© 2026 Shruti Chelawat Astrology. All rights reserved.`}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;