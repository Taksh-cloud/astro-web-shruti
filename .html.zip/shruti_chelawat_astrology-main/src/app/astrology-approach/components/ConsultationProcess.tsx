import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface ConsultationProcessProps {
  currentLanguage: string;
}

const ConsultationProcess = ({ currentLanguage }: ConsultationProcessProps) => {
  const content = {
    en: {
      title: "Consultation Process",
      subtitle: "What to Expect During Your Session",
      steps: [
        {
          number: "01",
          icon: "ChatBubbleLeftRightIcon",
          title: "Initial Contact",
          description: "Reach out via WhatsApp with your birth details (date, time, place) and specific questions or areas of concern you'd like to explore."
        },
        {
          number: "02",
          icon: "DocumentTextIcon",
          title: "Chart Preparation",
          description: "I prepare your detailed birth chart (Janam Kundali) and conduct preliminary analysis of planetary positions, dashas, and relevant yogas."
        },
        {
          number: "03",
          icon: "VideoCameraIcon",
          title: "Live Consultation",
          description: "We connect via video/audio call where I explain your chart, answer your questions, and provide guidance on timing and remedies (45-60 minutes)."
        },
        {
          number: "04",
          icon: "DocumentChartBarIcon",
          title: "Follow-up Support",
          description: "You receive a summary of key insights and recommended remedies. I'm available for clarification questions within 7 days of consultation."
        }
      ],
      note: "All consultations are conducted in a confidential, judgment-free environment. Your privacy is my priority."
    },
    hi: {
      title: "परामर्श प्रक्रिया",
      subtitle: "आपके सत्र के दौरान क्या अपेक्षा करें",
      steps: [
        {
          number: "01",
          icon: "ChatBubbleLeftRightIcon",
          title: "प्रारंभिक संपर्क",
          description: "अपने जन्म विवरण (तिथि, समय, स्थान) और विशिष्ट प्रश्नों या चिंता के क्षेत्रों के साथ व्हाट्सएप के माध्यम से संपर्क करें जिन्हें आप तलाशना चाहते हैं।"
        },
        {
          number: "02",
          icon: "DocumentTextIcon",
          title: "कुंडली तैयारी",
          description: "मैं आपकी विस्तृत जन्म कुंडली तैयार करती हूं और ग्रह स्थितियों, दशाओं और प्रासंगिक योगों का प्रारंभिक विश्लेषण करती हूं।"
        },
        {
          number: "03",
          icon: "VideoCameraIcon",
          title: "लाइव परामर्श",
          description: "हम वीडियो/ऑडियो कॉल के माध्यम से जुड़ते हैं जहां मैं आपकी कुंडली की व्याख्या करती हूं, आपके प्रश्नों का उत्तर देती हूं, और समय और उपायों पर मार्गदर्शन प्रदान करती हूं (45-60 मिनट)।"
        },
        {
          number: "04",
          icon: "DocumentChartBarIcon",
          title: "अनुवर्ती सहायता",
          description: "आपको प्रमुख अंतर्दृष्टि और अनुशंसित उपायों का सारांश प्राप्त होता है। मैं परामर्श के 7 दिनों के भीतर स्पष्टीकरण प्रश्नों के लिए उपलब्ध हूं।"
        }
      ],
      note: "सभी परामर्श गोपनीय, निर्णय-मुक्त वातावरण में आयोजित किए जाते हैं। आपकी गोपनीयता मेरी प्राथमिकता है।"
    }
  };

  const lang = currentLanguage === 'hi' ? 'hi' : 'en';

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl xl:text-5xl font-bold text-primary mb-4">
              {content[lang].title}
            </h2>
            <p className="font-body text-lg lg:text-xl text-text-secondary">
              {content[lang].subtitle}
            </p>
          </div>

          <div className="relative">
            <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-primary bg-opacity-20 transform -translate-x-1/2"></div>

            <div className="space-y-12 lg:space-y-16">
              {content[lang].steps.map((step, index) => (
                <div
                  key={index}
                  className={`flex flex-col lg:flex-row items-center gap-6 ${
                    index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  }`}
                >
                  <div className="flex-1 w-full">
                    <div className={`bg-card p-6 lg:p-8 rounded-lg shadow-soft ${
                      index % 2 === 0 ? 'lg:text-right' : 'lg:text-left'
                    }`}>
                      <div className={`flex items-center gap-4 mb-4 ${
                        index % 2 === 0 ? 'lg:flex-row-reverse lg:justify-end' : 'lg:justify-start'
                      }`}>
                        <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Icon name={step.icon as any} size={24} className="text-primary" />
                        </div>
                        <span className="font-headline text-4xl font-bold text-accent opacity-50">
                          {step.number}
                        </span>
                      </div>
                      <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-3">
                        {step.title}
                      </h3>
                      <p className="font-body text-base text-text-secondary leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </div>

                  <div className="hidden lg:flex w-16 h-16 bg-primary rounded-full items-center justify-center flex-shrink-0 relative z-10 shadow-soft">
                    <span className="font-headline text-xl font-bold text-primary-foreground">
                      {index + 1}
                    </span>
                  </div>

                  <div className="flex-1 w-full lg:block hidden"></div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-12 lg:mt-16 bg-accent bg-opacity-10 border-l-4 border-accent p-6 rounded-lg">
            <div className="flex items-start space-x-4">
              <Icon name="ShieldCheckIcon" size={24} className="text-accent flex-shrink-0 mt-1" />
              <p className="font-body text-base text-text-primary leading-relaxed">
                {content[lang].note}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ConsultationProcess;