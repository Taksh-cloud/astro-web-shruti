import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import AstrologyApproachInteractive from './components/AstrologyApproachInteractive';

export const metadata: Metadata = {
  title: 'Astrology Approach - Shruti Chelawat Astrology',
  description: 'Discover my unique approach to Vedic astrology combining traditional wisdom with modern clarity. Learn about my methodology, consultation process, and ethical practices that prioritize your empowerment and confidentiality.',
};

export default function AstrologyApproachPage() {
  return (
    <>
      <Header />
      <main className="pt-16 lg:pt-20">
        <AstrologyApproachInteractive />
      </main>
    </>
  );
}