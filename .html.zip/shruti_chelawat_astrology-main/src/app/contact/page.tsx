import type { Metadata } from 'next';
import ContactInteractive from './components/ContactInteractive';

export const metadata: Metadata = {
  title: 'Contact - Shruti Chelawat Astrology',
  description: 'Book your personalized Vedic astrology consultation with Shruti Chelawat. Connect via WhatsApp, phone, or email for authentic guidance in English or Hindi. Confidential consultations with flexible scheduling.',
};

export default function ContactPage() {
  return <ContactInteractive />;
}