'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/common/Header';
import ContactHero from './ContactHero';
import ContactMethods from './ContactMethods';
import ConsultationPreparation from './ConsultationPreparation';
import AvailabilityInfo from './AvailabilityInfo';
import PrivacyAssurance from './PrivacyAssurance';
import BookingCTA from './BookingCTA';
import Footer from './Footer';
import Icon from '@/components/ui/AppIcon';
import { motion } from 'framer-motion';

const ContactInteractive = () => {
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hi'>('en');
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
    const savedLanguage = localStorage.getItem('preferredLanguage') as 'en' | 'hi' | null;
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  const toggleLanguage = () => {
    const newLanguage = currentLanguage === 'en' ? 'hi' : 'en';
    setCurrentLanguage(newLanguage);
    if (isHydrated) {
      localStorage.setItem('preferredLanguage', newLanguage);
    }
  };

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16 lg:pt-20" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <button
        onClick={toggleLanguage}
        className="fixed top-24 right-4 lg:top-28 lg:right-8 z-40 bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow-elevated hover:bg-opacity-90 transition-all duration-300 flex items-center space-x-2"
        aria-label="Toggle language"
      >
        <Icon name="LanguageIcon" size={20} />
        <span className="font-cta font-semibold text-sm">{currentLanguage === 'en' ? 'हिंदी' : 'English'}</span>
      </button>

      <main className="pt-16 lg:pt-20">
        <ContactHero currentLanguage={currentLanguage} />
        <ContactMethods currentLanguage={currentLanguage} />
        <ConsultationPreparation currentLanguage={currentLanguage} />
        <AvailabilityInfo currentLanguage={currentLanguage} />
        <PrivacyAssurance currentLanguage={currentLanguage} />
        <BookingCTA currentLanguage={currentLanguage} />
      </main>

      <Footer currentLanguage={currentLanguage} />

      {/* Floating WhatsApp Button */}
      <motion.a
        href="https://wa.me/919079964007"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 lg:bottom-8 lg:right-8 z-50 bg-whatsapp text-whatsapp-foreground p-4 rounded-full shadow-elevated hover:shadow-elevated transition-all duration-300 hover:scale-110"
        aria-label="Contact on WhatsApp"
        whileHover={{ scale: 1.15, rotate: 5 }}
        whileTap={{ scale: 0.9 }}
        animate={{ 
          scale: [1, 1.1, 1],
        }}
        transition={{ 
          scale: { repeat: Infinity, duration: 2, ease: "easeInOut" },
          hover: { type: "spring", stiffness: 400, damping: 17 }
        }}
      >
        <Icon name="ChatBubbleLeftRightIcon" size={28} />
      </motion.a>
    </div>
  );
};

export default ContactInteractive;