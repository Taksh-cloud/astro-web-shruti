import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface ContactHeroProps {
  currentLanguage: 'en' | 'hi';
}

const ContactHero = ({ currentLanguage }: ContactHeroProps) => {
  const content = {
    en: {
      title: 'Begin Your Journey to Clarity',
      subtitle: 'Connect with Shruti Chelawat for personalized Vedic astrology guidance',
      description: 'Book your consultation through WhatsApp for a seamless, confidential experience. Available in both English and Hindi.',
    },
    hi: {
      title: 'स्पष्टता की यात्रा शुरू करें',
      subtitle: 'व्यक्तिगत वैदिक ज्योतिष मार्गदर्शन के लिए श्रुति चेलावत से जुड़ें',
      description: 'सहज, गोपनीय अनुभव के लिए व्हाट्सएप के माध्यम से अपना परामर्श बुक करें। अंग्रेजी और हिंदी दोनों में उपलब्ध।',
    },
  };

  const text = content[currentLanguage];

  return (
    <section className="relative bg-gradient-to-br from-primary via-primary to-secondary py-16 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 border-2 border-accent rounded-full" />
        <div className="absolute bottom-20 right-20 w-24 h-24 border-2 border-accent rounded-full" />
        <div className="absolute top-1/2 left-1/4 w-16 h-16 border-2 border-accent rounded-full" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 lg:w-20 lg:h-20 bg-accent rounded-full mb-6 lg:mb-8">
            <Icon name="ChatBubbleLeftRightIcon" size={32} className="text-accent-foreground" />
          </div>

          <h1 className="font-headline text-3xl lg:text-5xl font-semibold text-primary-foreground mb-4 lg:mb-6">
            {text.title}
          </h1>

          <p className="font-body text-lg lg:text-xl text-primary-foreground opacity-90 mb-4">
            {text.subtitle}
          </p>

          <p className="font-body text-base lg:text-lg text-primary-foreground opacity-80 max-w-2xl mx-auto">
            {text.description}
          </p>
        </div>
      </div>
    </section>
  );
};

export default ContactHero;