'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import { motion } from 'framer-motion';

interface BookingCTAProps {
  currentLanguage: 'en' | 'hi';
}

const BookingCTA = ({ currentLanguage }: BookingCTAProps) => {
  const content = {
    en: {
      heading: 'Ready to Begin?',
      description: 'Take the first step towards clarity and cosmic understanding. Book your personalized consultation now.',
      buttonText: 'Book Consultation on WhatsApp',
      features: [
        'Instant booking confirmation',
        'Flexible scheduling options',
        'Available in English & Hindi',
        'Secure & confidential',
      ],
    },
    hi: {
      heading: 'शुरू करने के लिए तैयार हैं?',
      description: 'स्पष्टता और ब्रह्मांडीय समझ की दिशा में पहला कदम उठाएं। अभी अपना व्यक्तिगत परामर्श बुक करें।',
      buttonText: 'व्हाट्सएप पर परामर्श बुक करें',
      features: [
        'तत्काल बुकिंग पुष्टि',
        'लचीले शेड्यूलिंग विकल्प',
        'अंग्रेजी और हिंदी में उपलब्ध',
        'सुरक्षित और गोपनीय',
      ],
    },
  };

  const text = content[currentLanguage];

  return (
    <section className="py-12 lg:py-20 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-primary via-primary to-secondary rounded-2xl p-8 lg:p-12 shadow-elevated text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-accent rounded-full mb-6">
              <Icon name="SparklesIcon" size={32} className="text-accent-foreground" />
            </div>

            <h2 className="font-headline text-3xl lg:text-4xl font-semibold text-primary-foreground mb-4">
              {text.heading}
            </h2>

            <p className="font-body text-lg text-primary-foreground opacity-90 mb-8 max-w-2xl mx-auto">
              {text.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 max-w-2xl mx-auto">
              {text.features.map((feature, index) => (
                <div key={index} className="flex items-center justify-center space-x-2 text-primary-foreground">
                  <Icon name="CheckCircleIcon" size={20} className="text-accent flex-shrink-0" />
                  <span className="font-body text-sm lg:text-base">{feature}</span>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <motion.a
              href="https://wa.me/919079964007"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center space-x-3 px-8 py-4 bg-whatsapp text-whatsapp-foreground font-cta font-semibold text-lg rounded-lg hover:bg-opacity-90 transition-all duration-300 shadow-elevated hover:shadow-elevated"
              whileHover={{ scale: 1.05, y: -3 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >
              <Icon name="ChatBubbleLeftRightIcon" size={24} />
              <span>{text.buttonText}</span>
            </motion.a>

            <p className="font-body text-sm text-primary-foreground opacity-75 mt-6">
              {currentLanguage === 'en' ?'Click to open WhatsApp and start your journey' :'व्हाट्सएप खोलने और अपनी यात्रा शुरू करने के लिए क्लिक करें'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookingCTA;