'use client';

import React from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';
import { motion } from 'framer-motion';

interface FooterProps {
  currentLanguage: 'en' | 'hi';
}

const Footer = ({ currentLanguage }: FooterProps) => {
  const currentYear = new Date().getFullYear();

  const content = {
    en: {
      tagline: 'Clarity Through Cosmic Wisdom',
      quickLinks: 'Quick Links',
      contact: 'Contact',
      followUs: 'Follow Us',
      copyright: `© ${currentYear} Shruti Chelawat Astrology. All rights reserved.`,
      links: [
        { label: 'Home', href: '/homepage' },
        { label: 'About', href: '/about' },
        { label: 'Services', href: '/services' },
        { label: 'Approach', href: '/astrology-approach' },
        { label: 'FAQ', href: '/faq' },
      ],
    },
    hi: {
      tagline: 'ब्रह्मांडीय ज्ञान के माध्यम से स्पष्टता',
      quickLinks: 'त्वरित लिंक',
      contact: 'संपर्क',
      followUs: 'हमें फॉलो करें',
      copyright: `© ${currentYear} श्रुति चेलावत ज्योतिष। सर्वाधिकार सुरक्षित।`,
      links: [
        { label: 'होम', href: '/homepage' },
        { label: 'परिचय', href: '/about' },
        { label: 'सेवाएं', href: '/services' },
        { label: 'दृष्टिकोण', href: '/astrology-approach' },
        { label: 'FAQ', href: '/faq' },
      ],
    },
  };

  const text = content[currentLanguage];

  return (
    <footer className="bg-primary text-primary-foreground py-12 lg:py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-8">
          <div className="lg:col-span-1">
            <Link href="/homepage" className="flex items-center space-x-3 mb-4 group">
              <div className="relative w-10 h-10">
                <svg
                  viewBox="0 0 48 48"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-full h-full transition-transform duration-300 group-hover:scale-105"
                >
                  <circle cx="24" cy="24" r="22" fill="white" opacity="0.1" />
                  <path
                    d="M24 8C15.163 8 8 15.163 8 24s7.163 16 16 16 16-7.163 16-16S32.837 8 24 8zm0 28c-6.627 0-12-5.373-12-12S17.373 12 24 12s12 5.373 12 12-5.373 12-12 12z"
                    fill="white"
                  />
                  <circle cx="24" cy="24" r="4" fill="var(--color-accent)" />
                  <path
                    d="M24 16v-4M24 36v-4M32 24h4M12 24h-4M30.828 17.172l2.829-2.829M14.343 32.657l2.829-2.829M30.828 30.828l2.829 2.829M14.343 15.343l2.829 2.829"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
              <div className="flex flex-col">
                <span className="font-headline text-lg font-semibold leading-tight">Shruti Chelawat</span>
                <span className="font-body text-sm opacity-80 leading-tight">Astrology</span>
              </div>
            </Link>
            <p className="font-body text-sm opacity-80">{text.tagline}</p>
          </div>

          <div>
            <h3 className="font-headline text-lg font-semibold mb-4">{text.quickLinks}</h3>
            <ul className="space-y-2">
              {text.links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-headline text-lg font-semibold mb-4">{text.contact}</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <Icon name="PhoneIcon" size={18} className="mt-0.5 flex-shrink-0" />
                <a
                  href="tel:+919079964007"
                  className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300"
                >
                  +91 90799 64007
                </a>
              </li>
              <li className="flex items-start space-x-2">
                <Icon name="EnvelopeIcon" size={18} className="mt-0.5 flex-shrink-0" />
                <a
                  href="mailto:shruti.chelawat@astrology.com"
                  className="font-body text-sm opacity-80 hover:opacity-100 hover:text-accent transition-all duration-300 break-all"
                >
                  shruti.chelawat@astrology.com
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-headline text-lg font-semibold mb-4">{text.followUs}</h3>
            {/* Social Links */}
            <div className="flex space-x-4">
              <motion.a
                href="https://wa.me/919079964007"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center w-10 h-10 bg-whatsapp rounded-full hover:bg-opacity-90 transition-all duration-300"
                aria-label="WhatsApp"
                whileHover={{ scale: 1.15, rotate: 5 }}
                whileTap={{ scale: 0.9 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
              >
                <Icon name="ChatBubbleLeftRightIcon" size={20} className="text-whatsapp-foreground" />
              </motion.a>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground border-opacity-20 pt-8">
          <p className="font-body text-sm text-center opacity-80">{text.copyright}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;