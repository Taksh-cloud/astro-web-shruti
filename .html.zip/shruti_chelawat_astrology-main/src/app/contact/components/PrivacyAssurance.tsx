import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface PrivacyPoint {
  id: string;
  icon: string;
  title: string;
  description: string;
}

interface PrivacyAssuranceProps {
  currentLanguage: 'en' | 'hi';
}

const PrivacyAssurance = ({ currentLanguage }: PrivacyAssuranceProps) => {
  const content = {
    en: {
      heading: 'Your Privacy is Sacred',
      subheading: 'Complete confidentiality guaranteed for all consultations',
      points: [
        {
          id: 'confidential',
          icon: 'LockClosedIcon',
          title: '100% Confidential',
          description: 'All personal information and consultation details remain strictly private',
        },
        {
          id: 'secure',
          icon: 'ShieldCheckIcon',
          title: 'Secure Communication',
          description: 'End-to-end encrypted WhatsApp ensures your data stays protected',
        },
        {
          id: 'no-sharing',
          icon: 'NoSymbolIcon',
          title: 'No Third-Party Sharing',
          description: 'Your information is never shared, sold, or disclosed to anyone',
        },
        {
          id: 'professional',
          icon: 'UserCircleIcon',
          title: 'Professional Ethics',
          description: 'Bound by traditional astrological ethics and modern privacy standards',
        },
      ] as PrivacyPoint[],
      note: 'Your trust is the foundation of our relationship. Every consultation is treated with the utmost respect and confidentiality.',
    },
    hi: {
      heading: 'आपकी गोपनीयता पवित्र है',
      subheading: 'सभी परामर्शों के लिए पूर्ण गोपनीयता की गारंटी',
      points: [
        {
          id: 'confidential',
          icon: 'LockClosedIcon',
          title: '100% गोपनीय',
          description: 'सभी व्यक्तिगत जानकारी और परामर्श विवरण पूरी तरह से निजी रहते हैं',
        },
        {
          id: 'secure',
          icon: 'ShieldCheckIcon',
          title: 'सुरक्षित संचार',
          description: 'एंड-टू-एंड एन्क्रिप्टेड व्हाट्सएप सुनिश्चित करता है कि आपका डेटा सुरक्षित रहे',
        },
        {
          id: 'no-sharing',
          icon: 'NoSymbolIcon',
          title: 'कोई तृतीय-पक्ष साझाकरण नहीं',
          description: 'आपकी जानकारी कभी भी किसी के साथ साझा, बेची या प्रकट नहीं की जाती है',
        },
        {
          id: 'professional',
          icon: 'UserCircleIcon',
          title: 'पेशेवर नैतिकता',
          description: 'पारंपरिक ज्योतिषीय नैतिकता और आधुनिक गोपनीयता मानकों से बंधे',
        },
      ] as PrivacyPoint[],
      note: 'आपका विश्वास हमारे रिश्ते की नींव है। प्रत्येक परामर्श को अत्यधिक सम्मान और गोपनीयता के साथ माना जाता है।',
    },
  };

  const text = content[currentLanguage];

  return (
    <section className="py-12 lg:py-20 bg-gradient-to-br from-primary via-primary to-secondary">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl font-semibold text-primary-foreground mb-4">
              {text.heading}
            </h2>
            <p className="font-body text-lg text-primary-foreground opacity-90 max-w-2xl mx-auto">
              {text.subheading}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mb-12">
            {text.points.map((point) => (
              <div
                key={point.id}
                className="bg-card bg-opacity-95 rounded-xl p-6 lg:p-8 shadow-elevated hover:shadow-elevated transition-all duration-300"
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="inline-flex items-center justify-center w-12 h-12 bg-primary rounded-full">
                      <Icon name={point.icon as any} size={24} className="text-primary-foreground" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-2">
                      {point.title}
                    </h3>
                    <p className="font-body text-text-secondary">{point.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-card bg-opacity-95 rounded-xl p-6 lg:p-8 shadow-elevated text-center">
            <Icon name="HeartIcon" size={32} className="text-accent mx-auto mb-4" />
            <p className="font-body text-lg text-text-primary max-w-3xl mx-auto">{text.note}</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PrivacyAssurance;