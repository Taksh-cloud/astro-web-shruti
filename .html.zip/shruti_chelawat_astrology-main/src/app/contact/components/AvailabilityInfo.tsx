import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface AvailabilityInfoProps {
  currentLanguage: 'en' | 'hi';
}

const AvailabilityInfo = ({ currentLanguage }: AvailabilityInfoProps) => {
  const content = {
    en: {
      heading: 'Availability & Response Times',
      consultationHours: {
        title: 'Consultation Hours',
        schedule: 'Monday - Saturday: 10:00 AM - 7:00 PM IST',
        closed: 'Sunday: Closed for spiritual practice',
      },
      responseTime: {
        title: 'Response Time',
        whatsapp: 'WhatsApp: Within 2-4 hours during business hours',
        email: 'Email: Within 24 hours',
        emergency: 'For urgent matters, WhatsApp is recommended',
      },
      timezone: {
        title: 'Timezone',
        info: 'All times are in Indian Standard Time (IST)',
        note: 'International clients: Please convert to your local timezone',
      },
    },
    hi: {
      heading: 'उपलब्धता और प्रतिक्रिया समय',
      consultationHours: {
        title: 'परामर्श घंटे',
        schedule: 'सोमवार - शनिवार: सुबह 10:00 बजे - शाम 7:00 बजे IST',
        closed: 'रविवार: आध्यात्मिक अभ्यास के लिए बंद',
      },
      responseTime: {
        title: 'प्रतिक्रिया समय',
        whatsapp: 'व्हाट्सएप: व्यावसायिक घंटों के दौरान 2-4 घंटे के भीतर',
        email: 'ईमेल: 24 घंटे के भीतर',
        emergency: 'तत्काल मामलों के लिए, व्हाट्सएप की सिफारिश की जाती है',
      },
      timezone: {
        title: 'समय क्षेत्र',
        info: 'सभी समय भारतीय मानक समय (IST) में हैं',
        note: 'अंतर्राष्ट्रीय ग्राहक: कृपया अपने स्थानीय समय क्षेत्र में परिवर्तित करें',
      },
    },
  };

  const text = content[currentLanguage];

  return (
    <section className="py-12 lg:py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-headline text-3xl lg:text-4xl font-semibold text-primary text-center mb-12 lg:mb-16">
            {text.heading}
          </h2>

          <div className="space-y-8">
            <div className="bg-card rounded-xl p-6 lg:p-8 shadow-soft">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-primary rounded-full">
                    <Icon name="ClockIcon" size={24} className="text-primary-foreground" />
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-3">
                    {text.consultationHours.title}
                  </h3>
                  <p className="font-body text-text-primary mb-2">{text.consultationHours.schedule}</p>
                  <p className="font-body text-text-secondary italic">{text.consultationHours.closed}</p>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-xl p-6 lg:p-8 shadow-soft">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-accent rounded-full">
                    <Icon name="BoltIcon" size={24} className="text-accent-foreground" />
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-3">
                    {text.responseTime.title}
                  </h3>
                  <ul className="space-y-2">
                    <li className="font-body text-text-primary flex items-start">
                      <Icon name="CheckCircleIcon" size={20} className="text-success mr-2 mt-0.5 flex-shrink-0" />
                      <span>{text.responseTime.whatsapp}</span>
                    </li>
                    <li className="font-body text-text-primary flex items-start">
                      <Icon name="CheckCircleIcon" size={20} className="text-success mr-2 mt-0.5 flex-shrink-0" />
                      <span>{text.responseTime.email}</span>
                    </li>
                    <li className="font-body text-text-secondary italic flex items-start">
                      <Icon name="InformationCircleIcon" size={20} className="text-primary mr-2 mt-0.5 flex-shrink-0" />
                      <span>{text.responseTime.emergency}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-xl p-6 lg:p-8 shadow-soft">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-secondary rounded-full">
                    <Icon name="GlobeAltIcon" size={24} className="text-secondary-foreground" />
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-3">
                    {text.timezone.title}
                  </h3>
                  <p className="font-body text-text-primary mb-2">{text.timezone.info}</p>
                  <p className="font-body text-text-secondary italic">{text.timezone.note}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AvailabilityInfo;