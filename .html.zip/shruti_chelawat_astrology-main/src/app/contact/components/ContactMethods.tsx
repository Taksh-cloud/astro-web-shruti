'use client';

import React from 'react';
import Icon from '@/components/ui/AppIcon';
import { motion } from 'framer-motion';

interface ContactMethod {
  id: string;
  icon: string;
  title: string;
  description: string;
  value: string;
  action: string;
  actionUrl: string;
  isPrimary: boolean;
}

interface ContactMethodsProps {
  currentLanguage: 'en' | 'hi';
}

const ContactMethods = ({ currentLanguage }: ContactMethodsProps) => {
  const content = {
    en: {
      heading: 'Multiple Ways to Connect',
      subheading: 'Choose your preferred method of communication',
      methods: [
        {
          id: 'whatsapp',
          icon: 'ChatBubbleLeftRightIcon',
          title: 'WhatsApp Consultation',
          description: 'Instant booking and quick responses. Our primary consultation channel for seamless communication.',
          value: '+91 90799 64007',
          action: 'Start WhatsApp Chat',
          actionUrl: 'https://wa.me/919079964007',
          isPrimary: true,
        },
        {
          id: 'phone',
          icon: 'PhoneIcon',
          title: 'Phone Call',
          description: 'Direct voice consultation for detailed discussions. Available during business hours.',
          value: '+91 90799 64007',
          action: 'Call Now',
          actionUrl: 'tel:+919079964007',
          isPrimary: false,
        },
        {
          id: 'email',
          icon: 'EnvelopeIcon',
          title: 'Email Inquiry',
          description: 'For detailed questions or documentation. We respond within 24 hours.',
          value: 'shruti.chelawat@astrology.com',
          action: 'Send Email',
          actionUrl: 'mailto:shruti.chelawat@astrology.com',
          isPrimary: false,
        },
      ] as ContactMethod[],
    },
    hi: {
      heading: 'संपर्क के कई तरीके',
      subheading: 'अपनी पसंदीदा संचार विधि चुनें',
      methods: [
        {
          id: 'whatsapp',
          icon: 'ChatBubbleLeftRightIcon',
          title: 'व्हाट्सएप परामर्श',
          description: 'तत्काल बुकिंग और त्वरित प्रतिक्रिया। सहज संचार के लिए हमारा प्राथमिक परामर्श चैनल।',
          value: '+91 90799 64007',
          action: 'व्हाट्सएप चैट शुरू करें',
          actionUrl: 'https://wa.me/919079964007',
          isPrimary: true,
        },
        {
          id: 'phone',
          icon: 'PhoneIcon',
          title: 'फोन कॉल',
          description: 'विस्तृत चर्चा के लिए सीधा वॉयस परामर्श। व्यावसायिक घंटों के दौरान उपलब्ध।',
          value: '+91 90799 64007',
          action: 'अभी कॉल करें',
          actionUrl: 'tel:+919079964007',
          isPrimary: false,
        },
        {
          id: 'email',
          icon: 'EnvelopeIcon',
          title: 'ईमेल पूछताछ',
          description: 'विस्तृत प्रश्नों या दस्तावेज़ीकरण के लिए। हम 24 घंटे के भीतर जवाब देते हैं।',
          value: 'shruti.chelawat@astrology.com',
          action: 'ईमेल भेजें',
          actionUrl: 'mailto:shruti.chelawat@astrology.com',
          isPrimary: false,
        },
      ] as ContactMethod[],
    },
  };

  const text = content[currentLanguage];

  return (
    <section className="py-12 lg:py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl font-semibold text-primary mb-4">
              {text.heading}
            </h2>
            <p className="font-body text-lg text-text-secondary max-w-2xl mx-auto">
              {text.subheading}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {text.methods.map((method) => (
              <div
                key={method.id}
                className={`bg-card rounded-xl p-6 lg:p-8 shadow-soft hover:shadow-elevated transition-all duration-300 ${
                  method.isPrimary ? 'ring-2 ring-primary' : ''
                }`}
              >
                {method.isPrimary && (
                  <div className="inline-block bg-primary text-primary-foreground text-xs font-cta font-semibold px-3 py-1 rounded-full mb-4">
                    {currentLanguage === 'en' ? 'Recommended' : 'अनुशंसित'}
                  </div>
                )}

                <div
                  className={`inline-flex items-center justify-center w-14 h-14 rounded-full mb-6 ${
                    method.isPrimary ? 'bg-whatsapp' : 'bg-muted'
                  }`}
                >
                  <Icon
                    name={method.icon as any}
                    size={28}
                    className={method.isPrimary ? 'text-whatsapp-foreground' : 'text-primary'}
                  />
                </div>

                <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-3">
                  {method.title}
                </h3>

                <p className="font-body text-text-secondary mb-4 min-h-[60px]">
                  {method.description}
                </p>

                <p className="font-body text-primary font-semibold mb-6">{method.value}</p>

                <motion.a
                  href={method.actionUrl}
                  target={method.id === 'whatsapp' ? '_blank' : undefined}
                  rel={method.id === 'whatsapp' ? 'noopener noreferrer' : undefined}
                  className={`block w-full text-center px-6 py-3 rounded-lg font-cta font-semibold transition-all duration-300 ${
                    method.isPrimary
                      ? 'bg-whatsapp text-whatsapp-foreground hover:bg-opacity-90 shadow-soft hover:shadow-elevated'
                      : 'bg-muted text-primary hover:bg-primary hover:text-primary-foreground'
                  }`}
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  {method.action}
                </motion.a>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactMethods;