import React from 'react';
import Icon from '@/components/ui/AppIcon';

interface PreparationItem {
  id: string;
  icon: string;
  title: string;
  description: string;
}

interface ConsultationPreparationProps {
  currentLanguage: 'en' | 'hi';
}

const ConsultationPreparation = ({ currentLanguage }: ConsultationPreparationProps) => {
  const content = {
    en: {
      heading: 'Prepare for Your Consultation',
      subheading: 'What to have ready before your session',
      items: [
        {
          id: 'birth-details',
          icon: 'CalendarDaysIcon',
          title: 'Birth Details',
          description: 'Exact date, time, and place of birth for accurate chart preparation',
        },
        {
          id: 'questions',
          icon: 'QuestionMarkCircleIcon',
          title: 'Specific Questions',
          description: 'List of areas you want guidance on (career, relationships, health, etc.)',
        },
        {
          id: 'quiet-space',
          icon: 'HomeIcon',
          title: 'Quiet Environment',
          description: 'Find a peaceful space where you can focus without interruptions',
        },
        {
          id: 'open-mind',
          icon: 'SparklesIcon',
          title: 'Open Mindset',
          description: 'Approach with curiosity and willingness to receive honest guidance',
        },
      ] as PreparationItem[],
    },
    hi: {
      heading: 'अपने परामर्श की तैयारी करें',
      subheading: 'अपने सत्र से पहले क्या तैयार रखें',
      items: [
        {
          id: 'birth-details',
          icon: 'CalendarDaysIcon',
          title: 'जन्म विवरण',
          description: 'सटीक चार्ट तैयारी के लिए जन्म की सही तारीख, समय और स्थान',
        },
        {
          id: 'questions',
          icon: 'QuestionMarkCircleIcon',
          title: 'विशिष्ट प्रश्न',
          description: 'उन क्षेत्रों की सूची जिन पर आप मार्गदर्शन चाहते हैं (करियर, रिश्ते, स्वास्थ्य, आदि)',
        },
        {
          id: 'quiet-space',
          icon: 'HomeIcon',
          title: 'शांत वातावरण',
          description: 'एक शांतिपूर्ण स्थान खोजें जहां आप बिना किसी रुकावट के ध्यान केंद्रित कर सकें',
        },
        {
          id: 'open-mind',
          icon: 'SparklesIcon',
          title: 'खुली मानसिकता',
          description: 'जिज्ञासा और ईमानदार मार्गदर्शन प्राप्त करने की इच्छा के साथ संपर्क करें',
        },
      ] as PreparationItem[],
    },
  };

  const text = content[currentLanguage];

  return (
    <section className="py-12 lg:py-20 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="font-headline text-3xl lg:text-4xl font-semibold text-primary mb-4">
              {text.heading}
            </h2>
            <p className="font-body text-lg text-text-secondary max-w-2xl mx-auto">
              {text.subheading}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
            {text.items.map((item) => (
              <div
                key={item.id}
                className="bg-card rounded-xl p-6 lg:p-8 shadow-soft hover:shadow-elevated transition-all duration-300"
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="inline-flex items-center justify-center w-12 h-12 bg-primary rounded-full">
                      <Icon name={item.icon as any} size={24} className="text-primary-foreground" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-headline text-xl lg:text-2xl font-semibold text-text-primary mb-2">
                      {item.title}
                    </h3>
                    <p className="font-body text-text-secondary">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ConsultationPreparation;