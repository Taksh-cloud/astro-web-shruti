'use client';

import React, { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface FAQItem {
  id: string;
  question: string;
  questionHi: string;
  answer: string;
  answerHi: string;
  keywords: string[];
  category: string;
}

const FAQChatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isHydrated, setIsHydrated] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hi'>('en');
  const [messages, setMessages] = useState<Message[]>([]);
  const [showQuickOptions, setShowQuickOptions] = useState(true);

  useEffect(() => {
    setIsHydrated(true);
    const savedLanguage = localStorage.getItem('language') as 'en' | 'hi' | null;
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: Message = {
        id: 'welcome',
        text: currentLanguage === 'hi' ?'नमस्ते! मैं आपकी सहायता के लिए यहां हूं। आप सेवाओं, मूल्य निर्धारण, बुकिंग या मेरे दृष्टिकोण के बारे में पूछ सकते हैं।' :'Namaste! I\'m here to help you. You can ask about services, pricing, booking, or my approach.',
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, currentLanguage]);

  const faqData: FAQItem[] = [
    // Brand Identity & Basic Info
    {
      id: 'about',
      question: 'Who is Shruti Chelawat?',
      questionHi: 'श्रुति चेलावत कौन हैं?',
      answer: 'I am Shruti Chelawat, a certified Vedic astrologer based in Udaipur, India. I practice Nakshatra-based Vedic astrology with a grounded, practical, and solution-oriented approach. My focus is on clarity, responsibility, and real-life application rather than superstition. I have 4 years of certified practice plus additional years of study.',
      answerHi: 'मैं श्रुति चेलावत हूं, उदयपुर, भारत में स्थित एक प्रमाणित वैदिक ज्योतिषी। मैं नक्षत्र-आधारित वैदिक ज्योतिष का अभ्यास करती हूं जो व्यावहारिक और समाधान-उन्मुख है। मेरा ध्यान स्पष्टता, जिम्मेदारी और वास्तविक जीवन अनुप्रयोग पर है। मेरे पास 4 वर्षों का प्रमाणित अभ्यास और अतिरिक्त अध्ययन वर्ष हैं।',
      keywords: ['who', 'about', 'shruti', 'chelawat', 'astrologer', 'कौन', 'के बारे में', 'श्रुति'],
      category: 'about',
    },
    {
      id: 'location',
      question: 'Where are you located?',
      questionHi: 'आप कहां स्थित हैं?',
      answer: 'I am based in Udaipur, India. However, all my consultations are conducted online via Google Meet, so I can connect with clients anywhere in the world.',
      answerHi: 'मैं उदयपुर, भारत में स्थित हूं। हालांकि, मेरे सभी परामर्श गूगल मीट के माध्यम से ऑनलाइन आयोजित किए जाते हैं, इसलिए मैं दुनिया में कहीं भी ग्राहकों से जुड़ सकती हूं।',
      keywords: ['location', 'where', 'based', 'udaipur', 'स्थान', 'कहां', 'उदयपुर'],
      category: 'about',
    },
    {
      id: 'languages',
      question: 'What languages do you speak?',
      questionHi: 'आप कौन सी भाषाएं बोलती हैं?',
      answer: 'I conduct consultations in both English and Hindi. You can choose your preferred language when booking your session.',
      answerHi: 'मैं अंग्रेजी और हिंदी दोनों में परामर्श आयोजित करती हूं। आप अपना सत्र बुक करते समय अपनी पसंदीदा भाषा चुन सकते हैं।',
      keywords: ['language', 'english', 'hindi', 'speak', 'भाषा', 'अंग्रेजी', 'हिंदी'],
      category: 'about',
    },
    
    // Pricing & Service
    {
      id: 'pricing',
      question: 'What are your consultation prices?',
      questionHi: 'आपके परामर्श की कीमतें क्या हैं?',
      answer: 'My Kundli / Birth Chart Reading is ₹999 for a comprehensive 1-hour session via Google Meet. This single session covers 2 areas of life from: Personality, Career & Finances, Relationships & Marriage, Life Events & Challenges, or Spirituality & Life Purpose. There are no separate paid services—everything is discussed in one session.',
      answerHi: 'मेरी कुंडली / जन्म कुंडली रीडिंग गूगल मीट के माध्यम से एक व्यापक 1-घंटे के सत्र के लिए ₹999 है। यह एकल सत्र जीवन के 2 क्षेत्रों को कवर करता है: व्यक्तित्व, करियर और वित्त, संबंध और विवाह, जीवन की घटनाएं और चुनौतियां, या आध्यात्मिकता और जीवन उद्देश्य। कोई अलग भुगतान सेवाएं नहीं हैं—सब कुछ एक सत्र में चर्चा की जाती है।',
      keywords: ['price', 'cost', 'fee', 'pricing', 'charge', 'payment', '999', 'कीमत', 'शुल्क', 'मूल्य'],
      category: 'pricing',
    },
    {
      id: 'kundli-reading',
      question: 'What does the Kundli reading include?',
      questionHi: 'कुंडली रीडिंग में क्या शामिल है?',
      answer: 'The Kundli reading covers 2 areas of your choice: 1) Personality & Self-Understanding (core traits, emotional patterns, temperament), 2) Career & Finances (career directions, growth timing, financial stability), 3) Relationships & Marriage (patterns, compatibility, timing, family dynamics), 4) Life Events & Challenges (major phases, health tendencies, obstacles/doshas, remedies), 5) Spirituality & Life Purpose (dharma, inner growth, spiritual alignment). All insights are discussed in the same 1-hour session.',
      answerHi: 'कुंडली रीडिंग आपकी पसंद के 2 क्षेत्रों को कवर करती है: 1) व्यक्तित्व और आत्म-समझ (मुख्य लक्षण, भावनात्मक पैटर्न, स्वभाव), 2) करियर और वित्त (करियर दिशाएं, विकास समय, वित्तीय स्थिरता), 3) संबंध और विवाह (पैटर्न, संगतता, समय, पारिवारिक गतिशीलता), 4) जीवन की घटनाएं और चुनौतियां (प्रमुख चरण, स्वास्थ्य प्रवृत्तियां, बाधाएं/दोष, उपाय), 5) आध्यात्मिकता और जीवन उद्देश्य (धर्म, आंतरिक विकास, आध्यात्मिक संरेखण)। सभी अंतर्दृष्टि एक ही 1-घंटे के सत्र में चर्चा की जाती हैं।',
      keywords: ['kundli', 'reading', 'include', 'cover', 'what', 'birth chart', 'कुंडली', 'रीडिंग', 'शामिल'],
      category: 'services',
    },
    {
      id: 'session-duration',
      question: 'How long is the consultation?',
      questionHi: 'परामर्श कितने समय का है?',
      answer: 'Each consultation is 1 hour long, conducted via Google Meet (online only). This gives us adequate time to discuss your 2 chosen life areas thoroughly.',
      answerHi: 'प्रत्येक परामर्श 1 घंटे का होता है, गूगल मीट के माध्यम से आयोजित (केवल ऑनलाइन)। यह हमें आपके 2 चुने हुए जीवन क्षेत्रों पर पूरी तरह से चर्चा करने के लिए पर्याप्त समय देता है।',
      keywords: ['duration', 'how long', 'time', 'session', 'hour', 'समय', 'अवधि', 'घंटा'],
      category: 'services',
    },
    
    // Booking Process
    {
      id: 'booking',
      question: 'How do I book a consultation?',
      questionHi: 'मैं परामर्श कैसे बुक करूं?',
      answer: 'Booking is WhatsApp-only. Steps: 1) Message on WhatsApp: +91 90799 64007, 2) Share your birth details (full name, date of birth, time of birth, place of birth), 3) Mention your main areas of concern (optional), 4) Confirm the session. I will then send you the Google Meet link and payment details.',
      answerHi: 'बुकिंग केवल व्हाट्सएप के माध्यम से है। चरण: 1) व्हाट्सएप पर संदेश: +91 90799 64007, 2) अपनी जन्म विवरण साझा करें (पूरा नाम, जन्म तिथि, जन्म समय, जन्म स्थान), 3) अपनी मुख्य चिंताओं का उल्लेख करें (वैकल्पिक), 4) सत्र की पुष्टि करें। मैं फिर आपको गूगल मीट लिंक और भुगतान विवरण भेजूंगी।',
      keywords: ['book', 'booking', 'appointment', 'schedule', 'how to book', 'बुक', 'नियुक्ति', 'कैसे'],
      category: 'booking',
    },
    {
      id: 'whatsapp',
      question: 'What is your WhatsApp number?',
      questionHi: 'आपका व्हाट्सएप नंबर क्या है?',
      answer: 'My WhatsApp number is +91 90799 64007. This is the only way to book consultations. Please message me with your birth details to get started!',
      answerHi: 'मेरा व्हाट्सएप नंबर +91 90799 64007 है। यह परामर्श बुक करने का एकमात्र तरीका है। कृपया शुरू करने के लिए मुझे अपनी जन्म विवरण के साथ संदेश भेजें!',
      keywords: ['whatsapp', 'contact', 'number', 'phone', '90799', '64007', 'व्हाट्सएप', 'संपर्क', 'नंबर'],
      category: 'booking',
    },
    {
      id: 'birth-details',
      question: 'What information do you need for consultation?',
      questionHi: 'परामर्श के लिए आपको किस जानकारी की आवश्यकता है?',
      answer: 'I need: 1) Full name, 2) Date of birth, 3) Time of birth (as accurate as possible), 4) Place of birth, 5) Main areas of concern (optional). If you don\'t know your exact birth time, an approximate time can be discussed.',
      answerHi: 'मुझे चाहिए: 1) पूरा नाम, 2) जन्म तिथि, 3) जन्म समय (जितना सटीक हो सके), 4) जन्म स्थान, 5) मुख्य चिंता के क्षेत्र (वैकल्पिक)। यदि आप अपना सटीक जन्म समय नहीं जानते हैं, तो अनुमानित समय पर चर्चा की जा सकती है।',
      keywords: ['information', 'details', 'birth', 'need', 'require', 'जानकारी', 'विवरण', 'जन्म'],
      category: 'booking',
    },
    {
      id: 'online-only',
      question: 'Do you offer in-person consultations?',
      questionHi: 'क्या आप व्यक्तिगत परामर्श प्रदान करती हैं?',
      answer: 'No, all my consultations are conducted online only via Google Meet. This allows me to connect with clients from anywhere in the world.',
      answerHi: 'नहीं, मेरे सभी परामर्श केवल गूगल मीट के माध्यम से ऑनलाइन आयोजित किए जाते हैं। यह मुझे दुनिया में कहीं से भी ग्राहकों से जुड़ने की अनुमति देता है।',
      keywords: ['in-person', 'offline', 'physical', 'meet', 'व्यक्तिगत', 'ऑफलाइन'],
      category: 'booking',
    },
    
    // Astrology Approach
    {
      id: 'approach',
      question: 'What is your approach to astrology?',
      questionHi: 'ज्योतिष के प्रति आपका दृष्टिकोण क्या है?',
      answer: 'I follow Nakshatra-based Vedic astrology. My readings are precise, structured, and grounded in traditional Vedic principles. I focus on real-life decision-making with a calm, nurturing, and honest approach. My guidance adapts to the situation—sometimes gentle, sometimes balanced, sometimes direct, because truth can be uncomfortable but necessary. I focus on clarity, responsibility, and practical application rather than superstition.',
      answerHi: 'मैं नक्षत्र-आधारित वैदिक ज्योतिष का पालन करती हूं। मेरी रीडिंग सटीक, संरचित और पारंपरिक वैदिक सिद्धांतों में आधारित हैं। मैं शांत, पोषण और ईमानदार दृष्टिकोण के साथ वास्तविक जीवन निर्णय लेने पर ध्यान केंद्रित करती हूं। मेरा मार्गदर्शन स्थिति के अनुसार अनुकूलित होता है—कभी कोमल, कभी संतुलित, कभी प्रत्यक्ष, क्योंकि सत्य असहज हो सकता है लेकिन आवश्यक है।',
      keywords: ['approach', 'methodology', 'vedic', 'nakshatra', 'how', 'philosophy', 'दृष्टिकोण', 'पद्धति', 'वैदिक', 'नक्षत्र'],
      category: 'approach',
    },
    {
      id: 'experience',
      question: 'What is your experience and certification?',
      questionHi: 'आपका अनुभव और प्रमाणन क्या है?',
      answer: 'I have 4 years of certified astrology practice, plus additional years of study and learning. I am certified from a recognized astrology institution. My credentials are presented as professional background to ensure you receive quality guidance.',
      answerHi: 'मेरे पास 4 वर्षों का प्रमाणित ज्योतिष अभ्यास है, साथ ही अध्ययन और सीखने के अतिरिक्त वर्ष। मैं एक मान्यता प्राप्त ज्योतिष संस्थान से प्रमाणित हूं। मेरी साख पेशेवर पृष्ठभूमि के रूप में प्रस्तुत की गई है ताकि आपको गुणवत्ता मार्गदर्शन मिले।',
      keywords: ['experience', 'certification', 'certified', 'qualified', 'years', 'अनुभव', 'प्रमाणन', 'योग्यता'],
      category: 'approach',
    },
    
    // Remedies
    {
      id: 'remedies',
      question: 'Do you suggest remedies?',
      questionHi: 'क्या आप उपाय सुझाती हैं?',
      answer: 'Yes, but only if genuinely required. Remedies may include simple mantras, lifestyle guidance, or practical steps. There is no pressure to buy gemstones or perform costly rituals. Following remedies is always your choice. I believe in accessible, ethical solutions.',
      answerHi: 'हां, लेकिन केवल तभी जब वास्तव में आवश्यक हो। उपायों में सरल मंत्र, जीवनशैली मार्गदर्शन, या व्यावहारिक कदम शामिल हो सकते हैं। रत्न खरीदने या महंगे अनुष्ठान करने का कोई दबाव नहीं है। उपायों का पालन करना हमेशा आपकी पसंद है। मैं सुलभ, नैतिक समाधानों में विश्वास करती हूं।',
      keywords: ['remedies', 'solutions', 'mantras', 'gemstones', 'rituals', 'उपाय', 'समाधान', 'मंत्र'],
      category: 'approach',
    },
    
    // Privacy & Confidentiality
    {
      id: 'privacy',
      question: 'Is my information kept confidential?',
      questionHi: 'क्या मेरी जानकारी गोपनीय रखी जाती है?',
      answer: 'Absolutely. All personal details are kept confidential. Birth details are used only for the consultation. No data is shared with third parties. Sessions are not recorded by me. Client information is not stored beyond consultation needs. Privacy and respect are core values of my practice.',
      answerHi: 'बिल्कुल। सभी व्यक्तिगत विवरण गोपनीय रखे जाते हैं। जन्म विवरण केवल परामर्श के लिए उपयोग किए जाते हैं। कोई डेटा तीसरे पक्ष के साथ साझा नहीं किया जाता है। सत्र मेरे द्वारा रिकॉर्ड नहीं किए जाते हैं। ग्राहक जानकारी परामर्श आवश्यकताओं से परे संग्रहीत नहीं की जाती है। गोपनीयता और सम्मान मेरे अभ्यास के मूल मूल्य हैं।',
      keywords: ['privacy', 'confidential', 'private', 'secure', 'data', 'गोपनीयता', 'गोपनीय', 'सुरक्षित'],
      category: 'privacy',
    },
    
    // Disclaimer
    {
      id: 'disclaimer',
      question: 'Can astrology guarantee results?',
      questionHi: 'क्या ज्योतिष परिणामों की गारंटी दे सकता है?',
      answer: 'No. Astrology is a guidance tool, not a replacement for medical advice, legal advice, or financial/professional services. No outcomes are guaranteed. Astrology provides insight and perspective to support better decision-making, but the choices and actions are always yours.',
      answerHi: 'नहीं। ज्योतिष एक मार्गदर्शन उपकरण है, चिकित्सा सलाह, कानूनी सलाह, या वित्तीय/पेशेवर सेवाओं का प्रतिस्थापन नहीं। कोई परिणाम की गारंटी नहीं है। ज्योतिष बेहतर निर्णय लेने का समर्थन करने के लिए अंतर्दृष्टि और दृष्टिकोण प्रदान करता है, लेकिन विकल्प और कार्य हमेशा आपके हैं।',
      keywords: ['guarantee', 'results', 'promise', 'medical', 'legal', 'गारंटी', 'परिणाम', 'वादा'],
      category: 'disclaimer',
    },
    
    // General Questions
    {
      id: 'comparison',
      question: 'Are you better than other astrologers?',
      questionHi: 'क्या आप अन्य ज्योतिषियों से बेहतर हैं?',
      answer: 'I do not compare myself with other astrologers. Every astrologer has their own valid approach. I focus on providing clarity, responsibility, and practical guidance based on Nakshatra-based Vedic astrology. I invite you to experience my approach and see if it resonates with you.',
      answerHi: 'मैं अपनी तुलना अन्य ज्योतिषियों से नहीं करती। प्रत्येक ज्योतिषी का अपना वैध दृष्टिकोण होता है। मैं नक्षत्र-आधारित वैदिक ज्योतिष के आधार पर स्पष्टता, जिम्मेदारी और व्यावहारिक मार्गदर्शन प्रदान करने पर ध्यान केंद्रित करती हूं। मैं आपको मेरे दृष्टिकोण का अनुभव करने और देखने के लिए आमंत्रित करती हूं कि क्या यह आपके साथ प्रतिध्वनित होता है।',
      keywords: ['better', 'best', 'compare', 'other', 'astrologers', 'बेहतर', 'सर्वश्रेष्ठ', 'तुलना'],
      category: 'about',
    },
    {
      id: 'email-booking',
      question: 'Can I book via email or contact form?',
      questionHi: 'क्या मैं ईमेल या संपर्क फॉर्म के माध्यम से बुक कर सकता हूं?',
      answer: 'No, booking is WhatsApp-only. Please message me on WhatsApp at +91 90799 64007 to book your consultation. There are no email bookings or contact forms.',
      answerHi: 'नहीं, बुकिंग केवल व्हाट्सएप के माध्यम से है। कृपया अपना परामर्श बुक करने के लिए मुझे व्हाट्सएप पर +91 90799 64007 पर संदेश भेजें। कोई ईमेल बुकिंग या संपर्क फॉर्म नहीं हैं।',
      keywords: ['email', 'contact form', 'booking method', 'ईमेल', 'संपर्क फॉर्म'],
      category: 'booking',
    },
    {
      id: 'marriage-prediction',
      question: 'Can you predict my exact marriage date?',
      questionHi: 'क्या आप मेरी सटीक विवाह तिथि की भविष्यवाणी कर सकती हैं?',
      answer: 'I do not make exact date predictions for marriage, death, or success. Astrology provides timing trends and favorable periods, but exact dates cannot be guaranteed. For detailed questions about your specific situation, please book a consultation via WhatsApp: +91 90799 64007.',
      answerHi: 'मैं विवाह, मृत्यु या सफलता के लिए सटीक तिथि भविष्यवाणी नहीं करती। ज्योतिष समय प्रवृत्तियों और अनुकूल अवधियों को प्रदान करता है, लेकिन सटीक तिथियों की गारंटी नहीं दी जा सकती। आपकी विशिष्ट स्थिति के बारे में विस्तृत प्रश्नों के लिए, कृपया व्हाट्सएप के माध्यम से परामर्श बुक करें: +91 90799 64007।',
      keywords: ['marriage date', 'exact date', 'predict', 'when', 'विवाह तिथि', 'सटीक तिथि', 'भविष्यवाणी'],
      category: 'disclaimer',
    },
  ];

  const quickOptions = [
    { id: 'pricing', label: 'Pricing', labelHi: 'मूल्य निर्धारण' },
    { id: 'booking', label: 'How to Book', labelHi: 'कैसे बुक करें' },
    { id: 'kundli-reading', label: 'What\'s Included', labelHi: 'क्या शामिल है' },
    { id: 'approach', label: 'My Approach', labelHi: 'मेरा दृष्टिकोण' },
  ];

  const findAnswer = (query: string): FAQItem | null => {
    const lowerQuery = query.toLowerCase();
    return faqData.find((faq) =>
      faq.keywords.some((keyword) => lowerQuery.includes(keyword.toLowerCase()))
    ) || null;
  };

  const handleQuickOption = (optionId: string) => {
    const faq = faqData.find((item) => item.id === optionId);
    if (faq) {
      const userMessage: Message = {
        id: `user-${Date.now()}`,
        text: currentLanguage === 'hi' ? faq.questionHi : faq.question,
        sender: 'user',
        timestamp: new Date(),
      };
      const botMessage: Message = {
        id: `bot-${Date.now()}`,
        text: currentLanguage === 'hi' ? faq.answerHi : faq.answer,
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, userMessage, botMessage]);
      setShowQuickOptions(false);
    }
  };

  const handleLanguageToggle = () => {
    const newLang = currentLanguage === 'en' ? 'hi' : 'en';
    setCurrentLanguage(newLang);
    if (isHydrated) {
      localStorage.setItem('language', newLang);
    }
    // Reset messages with new language
    const welcomeMessage: Message = {
      id: 'welcome',
      text: newLang === 'hi' ?'नमस्ते! मैं आपकी सहायता के लिए यहां हूं। आप सेवाओं, मूल्य निर्धारण, बुकिंग या मेरे दृष्टिकोण के बारे में पूछ सकते हैं।' :'Namaste! I\'m here to help you. You can ask about services, pricing, booking, or my approach.',
      sender: 'bot',
      timestamp: new Date(),
    };
    setMessages([welcomeMessage]);
    setShowQuickOptions(true);
  };

  const handleReset = () => {
    const welcomeMessage: Message = {
      id: 'welcome',
      text: currentLanguage === 'hi' ?'नमस्ते! मैं आपकी सहायता के लिए यहां हूं। आप सेवाओं, मूल्य निर्धारण, बुकिंग या मेरे दृष्टिकोण के बारे में पूछ सकते हैं।' :'Namaste! I\'m here to help you. You can ask about services, pricing, booking, or my approach.',
      sender: 'bot',
      timestamp: new Date(),
    };
    setMessages([welcomeMessage]);
    setShowQuickOptions(true);
  };

  const handleWhatsAppRedirect = () => {
    window.open('https://wa.me/919079964007', '_blank');
  };

  if (!isHydrated) return null;

  return (
    <>
      {/* Floating Chat Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 bg-primary text-primary-foreground p-4 rounded-full shadow-elevated hover:shadow-floating transition-all duration-300 hover:scale-110 animate-pulse-gentle"
          aria-label="Open chatbot"
        >
          <Icon name="ChatBubbleLeftRightIcon" size={28} />
        </button>
      )}

      {/* Chatbot Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)] bg-card rounded-xl shadow-elevated border border-border overflow-hidden flex flex-col" style={{ height: '600px', maxHeight: 'calc(100vh - 3rem)' }}>
          {/* Header */}
          <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Icon name="SparklesIcon" size={24} />
              <div>
                <h3 className="font-headline text-lg font-semibold">
                  {currentLanguage === 'hi' ? 'श्रुति का सहायक' : 'Shruti\'s Assistant'}
                </h3>
                <p className="text-xs opacity-90">
                  {currentLanguage === 'hi' ? 'तुरंत उत्तर प्राप्त करें' : 'Get instant answers'}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleLanguageToggle}
                className="p-2 hover:bg-primary-foreground hover:bg-opacity-10 rounded-lg transition-colors"
                aria-label="Toggle language"
              >
                <Icon name="LanguageIcon" size={20} />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-primary-foreground hover:bg-opacity-10 rounded-lg transition-colors"
                aria-label="Close chatbot"
              >
                <Icon name="XMarkIcon" size={20} />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.sender === 'user' ?'bg-primary text-primary-foreground' :'bg-card text-text-primary border border-border'
                  }`}
                >
                  <p className="font-body text-sm leading-relaxed">{message.text}</p>
                </div>
              </div>
            ))}

            {/* Quick Options */}
            {showQuickOptions && (
              <div className="space-y-2">
                <p className="font-body text-sm text-text-secondary text-center">
                  {currentLanguage === 'hi' ? 'एक विषय चुनें:' : 'Choose a topic:'}
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {quickOptions.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => handleQuickOption(option.id)}
                      className="p-3 bg-card border border-border rounded-lg hover:bg-primary hover:text-primary-foreground transition-all duration-300 font-cta text-sm font-medium"
                    >
                      {currentLanguage === 'hi' ? option.labelHi : option.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="p-4 bg-card border-t border-border space-y-2">
            <button
              onClick={handleWhatsAppRedirect}
              className="w-full px-4 py-3 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 flex items-center justify-center space-x-2"
            >
              <Icon name="ChatBubbleLeftRightIcon" size={20} />
              <span>{currentLanguage === 'hi' ? 'व्हाट्सएप पर बुक करें' : 'Book on WhatsApp'}</span>
            </button>
            <button
              onClick={handleReset}
              className="w-full px-4 py-2 bg-muted text-text-primary font-body text-sm rounded-lg hover:bg-opacity-70 transition-all duration-300"
            >
              {currentLanguage === 'hi' ? 'नई बातचीत शुरू करें' : 'Start New Conversation'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default FAQChatbot;