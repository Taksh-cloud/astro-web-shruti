'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';
import Image from 'next/image';


interface HeaderProps {
  className?: string;
}

const Header = ({ className = '' }: HeaderProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const navigationItems = [
    { label: 'Home', href: '/homepage' },
    { label: 'About', href: '/about' },
    { label: 'Services', href: '/services' },
    { label: 'Approach', href: '/astrology-approach' },
    { label: 'Contact', href: '/contact' },
  ];

  const moreItems = [
    { label: 'FAQ', href: '/faq' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 bg-card transition-shadow duration-300 ${
          isScrolled ? 'shadow-soft' : ''
        } ${className}`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link href="/homepage" className="flex items-center space-x-3 group">
              <div className="relative w-10 h-10 lg:w-12 lg:h-12">
                <Image
                  src="/assets/images/WhatsApp_Image_2025-12-31_at_5.21.24_PM-1767293064387.jpeg"
                  alt="Shruti Chelawat Astrology Logo"
                  fill
                  sizes="(max-width: 1024px) 40px, 48px"
                  className="object-contain transition-transform duration-300 group-hover:scale-105 rounded-full"
                  priority
                />
              </div>
              <div className="flex flex-col">
                <span className="font-headline text-lg lg:text-xl font-semibold text-primary leading-tight">
                  Shruti Chelawat
                </span>
                <span className="font-body text-xs lg:text-sm text-text-secondary leading-tight">
                  Astrology
                </span>
                <span className="font-body text-[10px] lg:text-xs text-accent italic leading-tight">
                  Nakshatra-based
                </span>
              </div>
            </Link>

            <nav className="hidden lg:flex items-center space-x-1">
              {navigationItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="px-4 py-2 font-body font-medium text-text-primary hover:text-primary hover:bg-muted rounded-md transition-all duration-300"
                >
                  {item.label}
                </Link>
              ))}
              
              <div className="relative group">
                <button className="px-4 py-2 font-body font-medium text-text-primary hover:text-primary hover:bg-muted rounded-md transition-all duration-300 flex items-center space-x-1">
                  <span>More</span>
                  <Icon name="ChevronDownIcon" size={16} className="transition-transform duration-300 group-hover:rotate-180" />
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-card shadow-elevated rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 overflow-hidden">
                  {moreItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="block px-4 py-3 font-body text-text-primary hover:bg-muted hover:text-primary transition-colors duration-300"
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              </div>
            </nav>

            <div className="hidden lg:flex items-center space-x-4">
              <a
                href="https://wa.me/1234567890"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2.5 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 flex items-center space-x-2 shadow-soft hover:shadow-elevated"
              >
                <Icon name="ChatBubbleLeftRightIcon" size={20} />
                <span>Book Now</span>
              </a>
            </div>

            <button
              onClick={handleMobileMenuToggle}
              className="lg:hidden p-2 text-text-primary hover:text-primary transition-colors duration-300"
              aria-label="Toggle mobile menu"
            >
              <Icon name={isMobileMenuOpen ? 'XMarkIcon' : 'Bars3Icon'} size={24} />
            </button>
          </div>
        </div>
      </header>

      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-background"
            onClick={closeMobileMenu}
          />
          <nav className="absolute top-16 left-0 right-0 bg-card shadow-elevated max-h-[calc(100vh-4rem)] overflow-y-auto">
            <div className="py-4">
              {navigationItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={closeMobileMenu}
                  className="block px-6 py-3 font-body font-medium text-text-primary hover:bg-muted hover:text-primary transition-colors duration-300"
                >
                  {item.label}
                </Link>
              ))}
              
              <div className="border-t border-border my-2" />
              
              {moreItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={closeMobileMenu}
                  className="block px-6 py-3 font-body font-medium text-text-primary hover:bg-muted hover:text-primary transition-colors duration-300"
                >
                  {item.label}
                </Link>
              ))}
              
              <div className="px-6 py-4">
                <a
                  href="https://wa.me/1234567890"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full px-6 py-3 bg-whatsapp text-whatsapp-foreground font-cta font-semibold rounded-lg hover:bg-opacity-90 transition-all duration-300 text-center shadow-soft"
                  onClick={closeMobileMenu}
                >
                  <div className="flex items-center justify-center space-x-2">
                    <Icon name="ChatBubbleLeftRightIcon" size={20} />
                    <span>Book Consultation</span>
                  </div>
                </a>
              </div>
            </div>
          </nav>
        </div>
      )}
    </>
  );
};

export default Header;